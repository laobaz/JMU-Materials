package keshe.collegepackage;

import keshe.template.Default_template;
import keshe.template.Output_list;
import keshe.template.connection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.sql.*;

public class select extends JFrame {
    keshe.template.connection c = new connection();
    Connection connection = c.getConnect();        //���������ݿ�

    JTable jTable=null;

    JButton jButton_Certain, jButton_Back;

    select() {
        new Default_template(this);
        setSize(600,400);
        init();
    }

    private void init() {

        jButton_Back = new JButton("������һ��");
        JPanel pnorth = new JPanel();       //����JPanel��Ÿ�����ť��JLabel
        pnorth.setLayout(new FlowLayout());

        pnorth.add(jButton_Back);
        add(pnorth, BorderLayout.NORTH);


        String sql="{call college_select()}";
        Output_list outputList=new Output_list();
        jTable=outputList.Output(sql);
        jTable.setPreferredScrollableViewportSize(new Dimension(500, 200));
        add(new JScrollPane(jTable), BorderLayout.SOUTH);


        jButton_Back.addActionListener(e -> {
            new college().setVisible(true);//������һ������
            try {
                connection.close();

            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            dispose();
        });

    }
}
