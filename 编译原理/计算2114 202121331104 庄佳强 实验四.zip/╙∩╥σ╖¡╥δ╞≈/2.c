int a,b;
a=10;
c=b+a;
