#pragma once
#include"init.h"

void input() {
    string input_str;
    bool mark = false;
    while (getline(cin, input_str)) {
        if (!(input_str[0] >= 'A' && input_str[0] <= 'Z')) {
            break;
        }
        if (!mark) {
            //����ĵ�һ�����ս�����Ϊ�ķ��Ŀ�ʼ��
            G_start = input_str[0];
            mark = true;
        }
        int i = 0;
        string tmp = "";
        while (input_str[i] != ':') {
            tmp += input_str[i++];
        }
        i += 3;//����::=
        production pro(tmp);
        while (true) {
            tmp = "";
            while (input_str[i] != ' ') {
                tmp += input_str[i];
                i++;
                if (i >= input_str.length()) {
                    break;
                }
            }
            pro.push(tmp);
            if (i < input_str.size()) {
                i++;
            }
            else {
                break;
            }
        }
        productions.push_back(pro);
    }

}


void eliminateDLeftRecusive() {
    string flag_E = "";
    vector<string> temp;    //���Ҫ���� E'->�Ų���ʽ�� �� E
    vector<production>::iterator it = productions.begin();
    while (it!= productions.end()) {
        flag_E = (*it).left;
        vector<production>::iterator it2 = it;
        int flagdi = 0;
        //�ж��Ƿ����ֱ����ݹ�
        while (it2 != productions.end() && (*it2).left == flag_E)
        {
            if ((*it2).left == (*it2).right[0])  // E->Ea
            {
                flagdi = 1;
                it2++;
                continue;
            }
            if (flagdi == 1 && (*it2).left != (*it2).right[0])    //E->b
            {
                flagdi = 2;
                break;
            }
            it2++;
        }

        //����ֱ����ݹ�
        if (flagdi == 2)
        {
            temp.push_back(flag_E);
            while (it != productions.end() && (*it).left == flag_E)
            {
                string tmp = (*it).left + '\'';
                if ((*it).left == (*it).right[0]) {   //E->Ea
                    // ��� E'->aE'
                    (*it).left = tmp;
                    (*it).right.erase((*it).right.begin());
                    (*it).push(tmp);
                }
                else {
                    //E->b ��� E->bE'
                    (*it).push(tmp);
                }
                it++;
            }
        }
        else {
            it++;
        }

    }

    for (int i = 0; i < temp.size(); i++) {
        string str = temp[i] + '\'';
        production p1(str);
        p1.push("��");
        productions.push_back(p1);
    }
}

void printProductions() {
    //����ʽ���
    int j = 1;
    for (int i = 0; i < productions.size(); i++) {
        productions[i].print();
        productions[i].index = j;
        j++;
    }
}

void calVN() {

    for (auto it :productions) {
        if (nonterminal.count(it.left) <= 1) {
            nonterminal.insert(it.left);
        }
        for (int i = 0; i < it.right.size(); i++) {
            if (it.right[i][0] >= 'A' && it.right[i][0] <= 'Z') {
                if (nonterminal.count(it.right[i]) < 1) {
                    nonterminal.insert(it.right[i]);
                }
            }
        }
    }
}

void calVT() {
    for (auto it : productions) {
        for (int i = 0; i < it.right.size(); i++) {
            if (nonterminal.count(it.right[i]) < 1 && Finalization.count(it.right[i]) < 1) {
                Finalization.insert(it.right[i]);
            }
        }
    }
}

void printVNT() {
    cout << "���ս����";
    for (auto it : nonterminal) {
        cout << it << " ";
    }
    cout << endl;
    cout << "�ս����";
    for (auto it : Finalization) {
        cout << it << " ";
    }
    cout << endl;
}

void initFcollections() {
    for (auto it : nonterminal) {
        first_follow f1(it);
        if (it == G_start) {
            //�ķ���ʼ�� #����FOLLOW��
            f1.insert2("#");
        }
        fcollections.push_back(f1);
    }
}

void calFIRST() {
    bool is_change = true;  // ���ÿ��ɨ��׼�Ƿ����FIRST����
    while (is_change)
    {
        is_change = false;
        for (int i = 0; i < productions.size(); i++)
        {
            int k = 0;
            //����fcollections[k].vn = productions[i].left ��Ϊ��ǰ�����ķ��ս��
            for (k = 0; k < fcollections.size(); k++)
            {
                if (fcollections[k].vn == productions[i].left)
                {
                    break;
                }
            }

            bool have_e = false;    //����ܷ�һֱ�Ƴ���
            for (int ri = 0; ri < productions[i].right.size(); ri++) {
                // �����ú�ѡʽ���Ҳ�
                have_e = false;
                //�Ƿ��ս��  E->A���� FIRST[E] += ( FIRST[A] - {��} );
                if (productions[i].right[ri][0] >= 'A' && productions[i].right[ri][0] <= 'Z') {
                    //��fcollections[h].vn = productions[i].right[ri] ���Ҳ�Ҫ�����ķ��ս�� A
                    int h = 0;
                    for (; h < fcollections.size(); h++) {
                        if (fcollections[h].vn == productions[i].right[ri]) {
                            break;
                        }
                    }

                    //�ж�FIRST[A]�ǿ�
                    if (!(fcollections[h].vfirst.empty())) {
                        //�ж�FIRST[A]���Ƿ������FIRST[E]����Ԫ��
                        for (auto it : fcollections[h].vfirst) {
                            if (it != "��") {
                                //����FIRST[E]����
                                if (fcollections[k].vfirst.count(it) < 1) {
                                    is_change = true;
                                }
                                fcollections[k].insert1(it);
                            }
                        }
                    }
                    else {
                        //FIRST[A]Ϊ��
                        //��������
                        break;
                    }

                    if (fcollections[h].vfirst.count("��")) {
                        //�� ���� FIRST[A] ���������Ҳ�
                        have_e = true;
                    }
                    else {
                        // ��������ѭ��
                        break;
                    }
                }
                //���ս�� �� ��
                else {
                    // E->a���� FIRST[E] += {a};
                    if (fcollections[k].vfirst.count(productions[i].right[ri]) < 1) {
                        is_change = true;
                    }
                    fcollections[k].insert1(productions[i].right[ri]);   //����FIRST����
                    //�ս�� ����ѭ��
                    break;
                }

            }

            if (have_e) {
                //��һֱ�Ƴ���
                // FIRST[E] += {��}
                fcollections[k].insert1("��");
            }

        }

    }

}

void calFOLLOW() {
    bool is_change = true;  // ���ÿ��ɨ�����Ƿ����FOLLOW����
    while (is_change) {
        is_change = false;
        for (int i = 0; i < productions.size(); i++)
        {
            for (int j = 0; j < productions[i].right.size(); j++) {
                //�ж��Ƿ�Ϊ���ս��
                if (productions[i].right[j][0] >= 'A' && productions[i].right[j][0] <= 'Z')
                {
                    //1.��ʽΪ A->aF  follow(A)���뵽follow(F)
                    if (j + 1 == productions[i].right.size()) {

                        int k = 0, m = 0, fg = 0;
                        //����fcollections[k].vn=A 
                        //   fcollections[m].vn=F
                        for (int nn = 0; nn < fcollections.size(); nn++)
                        {
                            if (fcollections[nn].vn == productions[i].left)
                            {
                                k = nn;
                                fg++;
                            }
                            if (fcollections[nn].vn == productions[i].right[j])
                            {
                                m = nn;
                                fg++;
                            }
                            if (fg == 2) {
                                break;
                            }
                        }

                        //�ж�FOLLOW[A]�Ƿ�Ϊ��
                        if (!(fcollections[k].vfollow.empty())) {
                            //�ж�FOLLOW[A]���Ƿ�����Ԫ��
                            for (auto it : fcollections[k].vfollow) {
                                if (fcollections[m].vfollow.count(it) < 1) {
                                    fcollections[m].insert2(it);    //����FOLLOW����
                                    is_change = true;
                                }
                            }
                        }
                    }

                    //2.��ʽΪ A->aFB FIRST(B)-�� ���뵽follow(F)
                    else if (productions[i].right[j + 1][0] >= 'A' && productions[i].right[j + 1][0] <= 'Z')
                    {
                        int k = 0, m = 0, fg = 0;
                        //����fcollections[k].vn=F 
                        //   fcollections[m].vn=B
                        for (int nn = 0; nn < fcollections.size(); nn++)
                        {
                            if (fcollections[nn].vn == productions[i].right[j])
                            {
                                k = nn;
                                fg++;
                            }
                            if (fcollections[nn].vn == productions[i].right[j + 1])
                            {
                                m = nn;
                                fg++;
                            }
                            if (fg == 2) {
                                break;
                            }
                        }

                        int flag_e = 0;
                        for (auto it : fcollections[m].vfirst) {
                            if (it == "��") {
                                flag_e = 1;
                            }
                            if (it != "��")   //��ȥ��
                            {
                                if (fcollections[k].vfollow.count(it) < 1) {
                                    fcollections[k].insert2(it);    //����FOLLOW����
                                    is_change = true;
                                }
                            }
                        }

                        // 2.2 B->...->�� follow(A)���뵽follow(F)
                        if (flag_e) {
                            // fcollections[k].vn=F 
                            // ����fcollections[m].vn=A
                            for (m = 0; m < fcollections.size(); m++)
                            {
                                if (fcollections[m].vn == productions[i].left)
                                {
                                    break;
                                }
                            }
                            //�ж�FOLLOW[A]�Ƿ�Ϊ��
                            if (!(fcollections[m].vfollow.empty()))
                            {
                                //�ж�FOLLOW[A]���Ƿ�����Ԫ��
                                for (auto it : fcollections[m].vfollow)
                                {
                                    if (fcollections[k].vfollow.count(it) < 1)
                                    {
                                        fcollections[k].insert2(it);    //����FOLLOW����
                                        is_change = true;
                                    }
                                }
                            }
                        }




                    }

                    //3.��ʽΪ A->aFb {b}���뵽follow(F)
                    else
                    {
                        int k = 0;
                        //����fcollections[k].vn=F
                        for (k = 0; k < fcollections.size(); k++)
                        {
                            if (fcollections[k].vn == productions[i].right[j])
                            {
                                break;
                            }
                        }
                        //�ж��Ƿ�Ҫ����follow����
                        if (fcollections[k].vfollow.count(productions[i].right[j + 1]) < 1) {
                            fcollections[k].insert2(productions[i].right[j + 1]);    //����FOLLOW����
                            is_change = true;
                        }
                    }

                }
            }
        }
    }
}

void calRightFIRST() {
    for (int i = 0; i < productions.size(); i++) {
        //��������ʽ���Ҳ�
        bool have_e = false;
        for (auto t : productions[i].right) {
            have_e = false;
            if (isVN(t)) {
                //�Ƿ��ս��
                //��λfcollections[j].vn = t
                int j = 0;
                for (; j < fcollections.size(); j++) {
                    if (fcollections[j].vn == t) {
                        break;
                    }
                }
                for (auto u : fcollections[j].vfirst) {
                    if (u == "��") {
                        have_e = true;
                    }
                    else {
                        productions[i].insert(u);
                    }
                }
                if (have_e == false) {
                    break;
                }

            }
            else {
                //���ս��
                productions[i].insert(t);
                break;
            }
        }

        if (have_e) {
            productions[i].insert("��");
        }
    }
}

void printFirstFollow() {
    for (int i = 0; i < fcollections.size(); i++) {
        fcollections[i].print();
    }
}

void initAnalysisTable() {
    for (auto it : nonterminal) {
        analysis_table at(it);
        at.initmap();
        analysis_tables.push_back(at);
    }
}

bool isVN(string str) {
    return (nonterminal.count(str) > 0);
}

string getpro(int j) {
    string res = "";
    res += productions[j].left;
    res += "->";
    for (auto it : productions[j].right) {
        res += it;
        res += " ";
    }
    return res;
}

void createAnalysisTable() {
    for (int i = 0; i < productions.size(); i++) {
        // ����һ������ʽ A->ri
        string A = productions[i].left;
        int h = 0, k = 0;
        //��λanalysis_tables[h].vn=A;
        //fcollections[k].vn = A;
        for (; h < analysis_tables.size(); h++) {
            if (analysis_tables[h].vn == A) {
                break;
            }
        }
        for (; k < fcollections.size(); k++) {
            if (fcollections[k].vn == A) {
                break;
            }
        }

        if (productions[i].rfirst.count("��")) {
            // ĩβ�ɵ����ţ����FOLLOW[A]={c}, ��M[A,c]����˲���ʽ
            for (auto jj : fcollections[k].vfollow) {
                string s1 = getpro(i);
                analysis_tables[h].insert(jj, s1);
                analysis_tables[h].atindex.insert(pair<string, int>(jj, productions[i].index));
            }
        }
        for (auto t : productions[i].rfirst) {
            if (t != "��") {
                string s1 = getpro(i);
                analysis_tables[h].insert(t, s1);
                analysis_tables[h].atindex.insert(pair<string, int>(t, productions[i].index));
            }
        }
    }
}

void printAnalysisTable() {
    //��ӡ��ͷ
    cout << "�﷨���������£�" << endl;
    cout << setw(4) << left << "  ";
    cout << "|";
    for (auto it : Finalization) {
        if (it != "��") {
            cout << setw(15) << left << it;
        }
    }
    cout <<  "#" << endl;

    cout << endl;
    for (int i = 0; i < analysis_tables.size(); i++) {
        analysis_tables[i].printrow();
    }

    cout << endl;
}

bool isLL1() {
    bool is_cross = false;  //����Ƿ��м����ཻ

    for (int i = 0; i < productions.size(); i++) {
        string A = productions[i].left;
        int index_e = -1;   //��¼FIRST[ri] = {��}�ĺ�ѡʽ
        for (int j = i; j < productions.size(); j++) {
            if (productions[j].left != A) {
                continue;
            }
            if (productions[j].rfirst.count("��")) {
                index_e = j;
                break;
            }
        }
        if (index_e != -1) {
            //�к�ѡʽΪ�ţ�Ҫ�������ѡʽFIRST �� FOLLOW[A] = ��
            for (int k = 0; k < productions.size(); k++) {
                if (productions[k].left == A && k != index_e) {
                    //��fcollections[mm].vn = A
                    int mm = 0;
                    for (; mm < fcollections.size(); mm++) {
                        if (fcollections[mm].vn == A) {
                            break;
                        }
                    }
                    for (auto af : fcollections[mm].vfollow) {
                        if (productions[k].rfirst.count(af)) {
                            // �н���
                            is_cross = true;
                            // ָ������
                            string f1 = getpro(k);
                            cout << "ERROR: �����ǿ�" << endl;
                            return (!is_cross);
                        }
                    }

                }
            }
        }
        for (int j = i + 1; j < productions.size(); j++) {
            if (productions[j].left != A || j == index_e) {
                continue;
            }

            //�ж�productions[i].vfirst��productions[j].vfirst�Ľ���
            for (auto it : productions[i].rfirst) {
                for (auto jt : productions[j].rfirst) {
                    if (it == jt) {
                        // �н���
                        is_cross = true;
                        string f1 = getpro(i);
                        string f2 = getpro(j);
                        cout << "ERROR: �����ǿ�" << endl;
                        return(!is_cross);
                    }
                }
            }
        }
    }
    return (!is_cross);
}

void judgeG() {
    if (isLL1()) {
        cout << "���ķ���LL(1)�ķ���" << endl;
        analysisIstr();
    }
    else {
        cout << "���ķ�����LL(1)�ķ�������" << endl;
    }
}

void inputIstr() {
    cout << "��������������ִ�(��#��β)�� ";
    cin >> wait_ananly;
    cout << "��ʼ��������" << endl;
}

string getStackStr() {
    stack<string> s;//����ջ
    vector<string> str;
    string res = "";
    s = GAnalasis;
    while (!s.empty()) {
        str.push_back(s.top());
        s.pop();
    }
    for (int i = str.size() - 1; i >= 0; i--) {
        res += str[i];
    }
    return res;
}

void analysisIstr() {
    inputIstr();
    //ѹ����ֹ���ź��ķ��Ŀ�ʼ����
    GAnalasis.push("#");
    GAnalasis.push(G_start);
    int i = 0, steps = 0;
    cout << wait_ananly << " �ķ����������£�" << endl;
    cout << setw(16) << left << "���̼���";
    cout << setw(20) << left << "�﷨����ջ";
    cout << setw(30) << left << "ʣ��δƥ����ִ�" << endl;
    for (int p = 0; p < 10; p++)
        cout << "�������� ";
    cout << endl;
    while (i < wait_ananly.length()) {
        steps++;
        cout << setw(16) << left << steps;
        string tmp = getStackStr();
        cout << setw(20) << left << tmp;
        string tmp2 = "";
        for (int j = i; j < wait_ananly.length(); j++) {
            tmp2 += wait_ananly[j];
        }
        cout << setw(30) << left << tmp2 << endl;
        char cur_c = wait_ananly[i];   //��ǰָʾ�ַ�
        //ȡջ��Ԫ��
        if (GAnalasis.empty()) {
            cout << "ջΪ�գ�����" << endl;
            return;
        }

        string top_str = GAnalasis.top(); //ջ������
        if (top_str == "id") {
            //id���͵����ж�
            if ((cur_c >= 'a' && cur_c <= 'z') || (cur_c >= '0' && cur_c <= '9')) {
                //ƥ��ɹ�
                i++;
                //ջ��Ԫ�س�ջ
                if (GAnalasis.empty()) {
                    cout << "ERROR��ջΪ�գ���ջ����ʧ��" << endl;
                    return;
                }
                GAnalasis.pop();
                cout << "ok~  ";
                cout << "�ַ�" << cur_c << "ƥ��ɹ�" << endl;
            }
        }
        else if (isVN(top_str)) {
            //���ս��
            //��Ԥ�������
            string tp = "";
            if (Finalization.count("id") > 0) {
                if ((cur_c >= 'a' && cur_c <= 'z') || (cur_c >= '0' && cur_c <= '9')) {
                    tp += "id";
                }
                else {
                    tp += cur_c;
                }
            }
            else {
                tp += cur_c;
            }
            //��analysis_tables[h].vn == top_str
            int h = 0;
            for (; h < analysis_tables.size(); h++) {
                if (analysis_tables[h].vn == top_str) {
                    break;
                }
            }
            if (analysis_tables[h].atlist.find(tp)->second == " ") {
                //��������Ӧλ��Ϊ�գ�
                //ERROR
                cout << "ERROR!" << endl;
                cout << "ƥ��ʧ�ܣ��ô����Ǹ����ķ��ľ��ӣ�" << endl;
                return;
            }
            else {
                //ջ��Ԫ�س�ջ
                if (GAnalasis.empty()) {
                    cout << "ERROR��ջΪ�գ���ջ����ʧ��" << endl;
                    return;
                }
                GAnalasis.pop();
                //������Ӧ����ʽ�����
                if (analysis_tables[h].atindex.count(tp) < 1) {
                    //��Ӧ�﷨��������Ϊ��
                    cout << "ERROR����Ӧ�﷨��������Ϊ�գ�����ʧ�ܣ�����" << endl;
                    return;
                }
                int k = analysis_tables[h].atindex.find(tp)->second;
                int pp = 0;
                //��productions[pp].index == k
                //ƥ���Ӧ���ķ�����ʽ
                for (; pp < productions.size(); pp++) {
                    if (productions[pp].index == k) {
                        break;
                    }
                }
                if (productions[pp].right[0] == "��") {
                    //�Ƴ��Ų���ʽ��ֱ�ӹ�������ѹջ

                    productions[pp].print();
                }
                else {
                    for (int l = productions[pp].right.size() - 1; l >= 0; l--) {
                        GAnalasis.push(productions[pp].right[l]);
                    }

                    productions[pp].print();
                }

            }
        }
        else {
            //�ս��
            if (cur_c == top_str[0]) {
                //ƥ��ɹ�
                i++;
                //ջ��Ԫ�س�ջ
                if (GAnalasis.empty()) {
                    cout << "ERROR��ջΪ�գ���ջ����ʧ��" << endl;
                    return;
                }
                GAnalasis.pop();
                cout <<"ok~  ";
                cout << "�ַ�" << cur_c << "ƥ��ɹ�" << endl;
            }
            else {
                //�����ս������ͬ ����
                cout << "ERROR��ƥ��ʧ��" << endl;
                return;
            }
        }
    }
    cout << wait_ananly << " �Ǹ����ķ��ľ��ӣ�����" << endl;
}