
#include <iostream>
#include <thread>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>  
#include <string>  
#include <sstream>  

#include <unordered_set>
#include <unordered_map>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "framing/Rectangle.h"
#include "core/utils/subUtils.hpp"
#include <uuid/uuid.h>


/////////////////临时测试//
struct Object
{
    cv::Rect_<float> rect;
    int label;
    float prob;
    uuid_t uuid;
    int trackID;
};
struct AnniwoTrackRecord
{
    Object detresult; //
    std::chrono::system_clock::time_point startPoint;  //stayStart时间
    cv::Mat img;
};

static  std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  > trackStayMap;
//////////////////

static int log_suffix_cnt=1;
bool isFirstimeInitFramer=true;
bool istodoInitTracks=true;

std::vector<std::string> rtmpStrs;
std::vector<int> rtmpIds;

shapes::Rectangle videogpuObj;

void doGetFrame()
{
    int i=0;
    while(i < 5000)
    // while(true)
    {
            // sleep(1);//unsigned int seconds
            static int useconds=200*1000;
            usleep(useconds);
            i++;
           ///////////////////////////Main logic

            //:
            int nowMinute=getCurMinuteDaytimeXB();
            // bool tidayUpNow=(i %= 400 );
            bool tidayUpNow=false;
            if(istodoInitTracks || tidayUpNow)
            {
                ANNIWOLOG(INFO) << "detect: enter istodoInitTracks==True" ;

                if(isFirstimeInitFramer)
                {
                    ANNIWOLOG(INFO) << "detect: enter isFirstimeInitFramer" ;
                    videogpuObj.init_framer(rtmpStrs,rtmpIds);
                    isFirstimeInitFramer = false;
                }
                else
                {
                    ANNIWOLOG(INFO) << "detect: calling stop2uninitialize_framing" ;
                    videogpuObj.stop2uninitialize_framing();
                    ANNIWOLOG(INFO) << "detect: calling re_init_framer" ;
                    videogpuObj.re_init_framer(rtmpStrs, rtmpIds);
                }
                ANNIWOLOG(INFO) <<"detect: calling start_framing";
                videogpuObj.start_framing();

                istodoInitTracks = false;
            }

            ANNIWOLOG(INFO) <<"detect(): calling consume_frame";

            std::pair< int,cv::Mat> out_tuple = videogpuObj.consume_frame();
            int camId = out_tuple.first;
            cv::Mat img = out_tuple.second.clone();


            ///////////////////////////////////////临时测试


            // std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  >::iterator got_id_func_cap = trackStayMap.find(camId);

            // if (got_id_func_cap == trackStayMap.end())
            // {
            //     ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck WARN: trackStayMap,camID:" <<camId;
            // }
            // else
            // {
            //     std::unordered_map<int, AnniwoTrackRecord>& track_stay_map =got_id_func_cap->second;
            //     //整图计时，虚拟一个tranckid:0
            //     int virtualtrackID=0;
            //     Object virtualobj; //虚拟一个空obj
            //     std::unordered_map<int, AnniwoTrackRecord>::iterator got_id_func_cap2 = track_stay_map.find(virtualtrackID);
            //     if (got_id_func_cap2 == track_stay_map.end())
            //     {
            //         //map中未记录该track_id
            //         ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck not found in track_stay_map,new add trackID:"<<virtualtrackID<<"camID:" <<camId;
            //         cv::Mat tmpMat =   img.clone();
            //         AnniwoTrackRecord tmpRecord{virtualobj,std::chrono::system_clock::now(),std::move(tmpMat)};
            //         std::pair<int, AnniwoTrackRecord> tmpPair{virtualtrackID,std::move(tmpRecord)};
            //         track_stay_map.insert(std::move(tmpPair) );
            //         ANNIWOLOG(INFO) << "DEBUG ZxyAbsence.startOrcheck not found in track_stay_map,added success"<<virtualtrackID<<"camID:" <<camId;

            //     }
            //     else 
            //     {
            //         got_id_func_cap2->second.startPoint=std::chrono::system_clock::now();
            //         got_id_func_cap2->second.img=img.clone();
            //     }
            // }


            ///////////////////////////////////////临时测试 end

            ANNIWOLOG(INFO) <<"detect():  consume_frame get camID:"<<camId;

            std::stringstream buffer;  

            buffer <<camId<<"_img_"<< i%rtmpIds.size() <<".jpg";  
            // buffer <<camId<<"_img_"<<i<<".jpg";  

            std::string text(buffer.str());

            std::string imgPath(text);
            ANNIWOLOG(INFO) <<"framingtest():  imgPath:"<<imgPath<<","<<camId;

            // cv::imwrite(imgPath,img);

    }


    //////////////////////临时测试
    // std::vector<int> camIDs{21,22,23};
    // for(auto& camID:camIDs)
    // {
    //     std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  >::iterator got_id_func_cap = trackStayMap.find(camID);

    //     if (got_id_func_cap == trackStayMap.end())
    //     {
    //         ANNIWOLOG(INFO) << "ZxyAbsence.stop WARN: trackStayMap,camID:" <<camID;
    //     }
    //     else
    //     {
    //         std::unordered_map<int, AnniwoTrackRecord>& track_stay_map =got_id_func_cap->second;
    //         //整图计时，虚拟一个tranckid:0
    //         int virtualtrackID=0;
    //         Object virtualobj; //虚拟一个空obj
    //         std::unordered_map<int, AnniwoTrackRecord>::iterator got_id_func_cap2 = track_stay_map.find(virtualtrackID);
    //         if (got_id_func_cap2 == track_stay_map.end())
    //         {
    //             //map中未记录该track_id,无需重置
    //         }
    //         else
    //         {   
    //             ANNIWOLOG(INFO) << "ZxyAbsence.stop WARN: erease trackStayMap,camID:" <<camID;
    //             track_stay_map.erase(virtualtrackID);
    //         }
    //     }
    // }

    ///////////////////////////
}


int main(int argc, char** argv)
{


    bool isTrackReseted=false;

    std::unique_ptr<g3::LogWorker> logworker {g3::LogWorker::createLogWorker()};

    g3::initializeLogging(logworker.get());


    // rtmpStrs.emplace_back(std::string("rtsp://admin:sx123456@192.168.1.66:554/Streaming/Channels/101"));
    rtmpStrs.emplace_back(std::string("rtsp://admin:HON123well!@192.168.1.101:554/media/1/0"));

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.39:6935/rtp/34020000001320000040?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    rtmpIds.emplace_back(21);

    rtmpStrs.emplace_back(std::string("rtsp://admin:HON123well!@192.168.1.100:554/media/1/0"));
    // rtmpStrs.emplace_back(std::string("rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/101"));
    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.39:6935/rtp/34020000001320000093?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    rtmpIds.emplace_back(22);

    rtmpStrs.emplace_back(std::string("rtsp://admin:HON123well!@192.168.1.101:554/media/1/1"));
    // rtmpStrs.emplace_back(std::string("rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/101"));
    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.39:6935/rtp/34020000001320000074?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    
    rtmpIds.emplace_back(23);

    rtmpStrs.emplace_back(std::string("rtsp://admin:HON123well!@192.168.1.100:554/media/1/1"));
    // rtmpStrs.emplace_back(std::string("rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/101"));
    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.39:6935/rtp/34020000001320000093?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    rtmpIds.emplace_back(24);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001024?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(24);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001025?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(25);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001026?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(26);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001027?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(27);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001028?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(28);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001029?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(29);


    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001070?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(70);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001031?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(31);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.252:935/rtp/34020000001320001044?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(44);



    //"rtmp://192.168.1.4:6935/rtp/34020000001320000034?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"
    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.4:6935/rtp/34020000001320000034?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.4:935/rtp/34020000001320000061?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(23);

    // rtmpStrs.emplace_back(std::string("rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/102"));
    // rtmpIds.emplace_back(5);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.4:6935/rtp/34020000001320000010?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(64);

    // rtmpStrs.emplace_back(std::string("rtmp://192.168.1.4:6935/rtp/34020000001320000011?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"));
    // rtmpIds.emplace_back(72);


/////////////////////////////////////////////临时测试
    // std::unordered_map<int, AnniwoTrackRecord > emptymp;
    // trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(21,emptymp) );
    // trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(22,emptymp) );
    // trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(23,emptymp) );
    // trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(24,emptymp) );
/////////////////////////////////////////////////////


while(true)
{
    doGetFrame();

//测试re_init
    {
        ANNIWOLOG(INFO) << "detect: calling stop2uninitialize_framing" ;
        videogpuObj.stop2uninitialize_framing();
        ANNIWOLOG(INFO) << "detect: calling re_init_framer" ;
        videogpuObj.re_init_framer(rtmpStrs, rtmpIds);
    }
    ANNIWOLOG(INFO) <<"detect: calling start_framing";
    videogpuObj.start_framing();

    doGetFrame();


//测试re_init,again
    {
        ANNIWOLOG(INFO) << "detect: calling stop2uninitialize_framing" ;
        videogpuObj.stop2uninitialize_framing();
        ANNIWOLOG(INFO) << "detect: calling re_init_framer" ;
        videogpuObj.re_init_framer(rtmpStrs, rtmpIds);
    }
    ANNIWOLOG(INFO) <<"detect: calling start_framing";
    videogpuObj.start_framing();

    doGetFrame();
}






}


