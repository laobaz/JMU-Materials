import cv2
import time
import copy

import videogpu
VidFramingGpu_obj = videogpu.PyVidFramingGpu()
print(dir(VidFramingGpu_obj))

''''rtsp://admin:root1234@192.168.1.65:554/h264/ch1/main/av_stream': 5,
 'rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream': 23,
  'rtsp://admin:sx123456@192.168.1.197:554/h264/ch1/main/av_stream': 28,
   'rtsp://admin:sx123456@192.168.1.196:554/h264/ch1/main/av_stream': 29,
    'rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0': 31
    "rtsp://admin:sx123456@192.168.1.68:554/h264/ch1/main/av_stream"：43'''

# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream",
# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/101",
# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/101?transportmode=multicast",
# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/102",
# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:1554/h264/ch1/main/av_stream",

# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream",
#                         b"rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.68:554/h264/ch1/main/av_stream",
#                         b"rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0"],
#                      [23,5,28,29,43,31])


'''rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/103
rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/103
rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/103
rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0
'''

'''
rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/103
rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/103
rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/103
rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0

'''

# VidFramingGpu_obj.init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/103",
#                             b"rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/103",
#                             b"rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/101",
#                             b"rtmp://192.168.1.4:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b",
#                             b"rtmp://192.168.1.4:6935/rtp/34020000001320000001?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"],
#                      [64,65,197,650,639])

# VidFramingGpu_obj.init_framer([
#                             b"rtmp://192.168.1.4:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b",
#                             b"rtmp://192.168.1.4:6935/rtp/34020000001320000001?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"],
#                      [650,639])


# VidFramingGpu_obj.init_framer([
#                      b"rtmp://115.171.216.89:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"
#                       ],
#                      [639])


# VidFramingGpu_obj.init_framer([
#                      b"rtmp://115.171.216.89:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"
#                       ],
#                      [650])

# VidFramingGpu_obj.init_framer([
#                      b"rtmp://115.171.216.89:6935/rtp/34020000001320000013?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"
#                       ],
#                      [639])

VidFramingGpu_obj.init_framer([
                     b"rtmp://115.171.216.89:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b",
                     b"rtmp://115.171.216.89:6935/rtp/34020000001320000013?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b" ],
                     [650,639])

# VidFramingGpu_obj.init_framer([
#                             b"rtmp://192.168.1.4:6935/rtp/34020000001320000012?token=fb5ddbec-e736-4be4-8a8c-5140b44cfd7b"],
#                      [650])

#rtsp://username:password@<address>:<port>/Streaming/tracks/<id>
#rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/101  
#rtsp://admin:Admin123@192.168.1.64:554/Streaming/Channels/101?transportmode=multicast
#rtsp://admin:Admin123@192.168.1.64:1554/h264/ch1/main/av_stream

VidFramingGpu_obj.start_framing()

time.sleep(1)


numbs=[1,2,3,4,5]
lcnt = 0
while(lcnt < 1500):
# while(True):
    for label in numbs:
        time.sleep(0.1)
        out_tuple = VidFramingGpu_obj.consume_frame()

        camID = copy.deepcopy(out_tuple[0])
        img = out_tuple[1]

        curtime=time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime())
        print("curtime:{} Got:CamID:{}".format(curtime,camID))

        saveName='{}_{}_{}.png'.format(str(camID),"current",label)
        print('{} Save to: {}'.format(curtime,saveName))

        bbox_mess = '%s' % (curtime)

        cv2.putText(img, bbox_mess, (69, 152), cv2.FONT_HERSHEY_SIMPLEX,
                    2, (0, 0, 255), 3, lineType=cv2.LINE_AA)

        cv2.imwrite(saveName,img)

        lcnt+=1

#############################TEST re-initialize#######################
# print("Calling stop2uninitialize_framing")
# VidFramingGpu_obj.stop2uninitialize_framing()
# print("Calling re_init_framer")
# VidFramingGpu_obj.re_init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream",
#                         b"rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0"],
#                      [23,5,28,29,31])

# VidFramingGpu_obj.start_framing()

# time.sleep(1)


# numbs=[1,2,3,4,5]
# lcnt = 0
# while(lcnt < 500):
#     for label in numbs:
#         time.sleep(0.5)
#         out_tuple = VidFramingGpu_obj.consume_frame()

#         camID = copy.deepcopy(out_tuple[0])
#         img = out_tuple[1]

#         curtime=time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime())
#         saveName='{}_{}_{}.png'.format(str(camID),"current",label)
#         print('{} Save to: {}'.format(curtime,saveName))

#         bbox_mess = '%s' % (curtime)

#         cv2.putText(img, bbox_mess, (69, 152), cv2.FONT_HERSHEY_SIMPLEX,
#                     2, (0, 0, 255), 3, lineType=cv2.LINE_AA)

#         cv2.imwrite(saveName,img)

#         lcnt+=1



# #############################TEST re-initialize#######################
# print("Calling stop2uninitialize_framing")
# VidFramingGpu_obj.stop2uninitialize_framing()
# print("Calling re_init_framer")
# VidFramingGpu_obj.re_init_framer([b"rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream",
#                         b"rtsp://admin:root1234@192.168.1.65:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.197:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.196:554/Streaming/Channels/101",
#                         b"rtsp://admin:sx123456@192.168.1.66:554/cam/realmonitor?channel=1&subtype=0"],
#                      [23,5,28,29,31])

# VidFramingGpu_obj.start_framing()

# time.sleep(1)


# numbs=[1,2,3,4,5]
# lcnt = 0
# while(lcnt < 500):
#     for label in numbs:
#         time.sleep(0.5)
#         out_tuple = VidFramingGpu_obj.consume_frame()

#         camID = copy.deepcopy(out_tuple[0])
#         img = out_tuple[1]

#         curtime=time.strftime("%Y-%m-%d_%H_%M_%S", time.localtime())
#         saveName='{}_{}_{}.png'.format(str(camID),"current",label)
#         print('{} Save to: {}'.format(curtime,saveName))

#         bbox_mess = '%s' % (curtime)

#         cv2.putText(img, bbox_mess, (69, 152), cv2.FONT_HERSHEY_SIMPLEX,
#                     2, (0, 0, 255), 3, lineType=cv2.LINE_AA)

#         cv2.imwrite(saveName,img)

#         lcnt+=1