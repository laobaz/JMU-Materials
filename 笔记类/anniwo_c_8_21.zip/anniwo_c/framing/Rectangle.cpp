#include "video_decode.h"
#include <iostream>
#include <thread>
#include <iostream>
#include <ctime>
#include <sstream>
#include <vector>
#include <utility>  // std::pair, std::make_pair
#include <string>    // std::string
#include <cstdlib>
#include <ctime>
#include <map>

// #include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
// #include <stdlib.h>

// #define random(x) rand()%(x)

#include <semaphore.h>
#include <mutex>

#include <opencv2/opencv.hpp>

#include "Rectangle.h"
#include <assert.h>

#include <g3log/g3log.hpp>
#include <g3log/logworker.hpp>
#include <g3log/std2_make_unique.hpp>
#include <g3log/logmessage.hpp>






namespace shapes {

std::vector<int> g_stream_ids;
std::vector<std::string> g_stream_list;
std::vector<VideoDecode*> g_video_dec_pointer_list;
std::vector<std::thread*> g_openthread_id_list;
 

std::map< int,cv::Mat>  g_frames;
static long callcnt=0;



// static sem_t g_semaphore_framing, g_semaphore_detecting;
static sem_t  g_semaphore_detecting;

static std::mutex mtx;

static std::mutex mtx4Open;

typedef struct {
	std::string link;
	int id;
	bool bTryMultiple;
} linkID_struct;




bool MonitorController::m_bMonitorRunning=true;

// inline void replaceall(std::string& name)
// {
// 	std::string::size_type startpos = 0;
// 	while (startpos!= std::string::npos)
// 	{
// 		startpos = name.find('.');   //找到'.'的位置
// 		if( startpos != std::string::npos ) //std::string::npos表示没有找到该字符
// 		{
// 		name.replace(startpos,1,"_"); //实施替换，注意后面一定要用""引起来，表示字符串
// 		}

// 		startpos = name.find(':');   //找到'.'的位置
// 		if( startpos != std::string::npos ) //std::string::npos表示没有找到该字符
// 		{
// 		name.replace(startpos,1,"_"); //实施替换，注意后面一定要用""引起来，表示字符串
// 		}

// 		startpos = name.find('/');   //找到'.'的位置
// 		if( startpos != std::string::npos ) //std::string::npos表示没有找到该字符
// 		{
// 		name.replace(startpos,1,"_"); //实施替换，注意后面一定要用""引起来，表示字符串
// 		}
// 	}
// }

static long lCurTime;
static long lcallbackTime = 0;
inline long getCurrentTime()	//ms
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

void data_callback(int err, int width, int height, unsigned char* data, int intRtsp)
{
	if (err == NO_ERROR && data != NULL)
	{
		// time_t now_time;
		// now_time = time(NULL);
		// //转为字符串
		// std::stringstream ss;
		// ss<<intRtsp<<"_"<<now_time<<".png"<<std::endl;
		// std::cout<<"save to:"<<ss.str()<<std::endl;

		// cv::imwrite(ss.str(), image);

		// std::cout<<timetoStr()<<"data_callback:"<<intRtsp<<"  waiting sem!"<<std::endl;
		
		// sem_wait(&g_semaphore_framing);

		bool isDoUpdate=false;
		
		std::unique_lock<std::mutex> uniqueLock(mtx, std::defer_lock);

		cv::Mat orig(height, width, CV_8UC3, (void*)data);
		cv::Mat image;
		image = orig.clone();

		
		// if(uniqueLock.try_lock())
		// ANNIWOLOGF(INFO,  "--------[%s] intRtsp:[%d] waiting lock...------------\n", timetoStr().c_str(),intRtsp);

		uniqueLock.lock();
			// std::cout<<timetoStr()<<intRtsp<<"  entered lock!queue size:"<<g_frames.size()<<std::endl;
			// int i=0;
			// for (auto it = g_frames.begin(); it != g_frames.end();i++,it++)
			// {
			// 	//一个摄像头只取一张最新的图片,发现并删除之前老的
			// 	if(intRtsp == g_stream_ids[i])
			// 	{
			// 		isDoUpdate=true;
			// 		g_frames.erase(it);
			// 		break;
			// 	}
			// }
			ANNIWOCHECK(image.data != NULL);
			size_t len = image.rows*image.cols*image.elemSize();
			ANNIWOCHECK(len != 0);

			std::map<int, cv::Mat>::iterator iter;  
			iter = g_frames.find(intRtsp); 
			if(iter != g_frames.end())  
			{
				isDoUpdate=true;
				g_frames[intRtsp]=image;
			}
			else  
			{
				g_frames.insert(std::make_pair(intRtsp,image));
			}


		uniqueLock.unlock();

		// ANNIWOLOGF(INFO,  "--------[%s] intRtsp:[%d] out lock...------------\n", timetoStr().c_str(),intRtsp);



		//10s 打印一次
		lCurTime = getCurrentTime();
		if ( lcallbackTime == 0 || lCurTime - lcallbackTime >= 10000 ){
			ANNIWOLOGF(INFO,  "---------%s sntRtsp:[%d] pushed back one image!queue size:%d isDoUpdate:%d------------tid:%s\n", timetoStr().c_str(), intRtsp, g_frames.size(),isDoUpdate,getThreadIdOfString(std::this_thread::get_id()).c_str() );
			// std::cout<<timetoStr()<<intRtsp<<"out lock!push back one image!queue size:"<<g_frames.size()<<"isDoUpdate:"<<isDoUpdate << std::endl;
			lcallbackTime=lCurTime;
		}
		//只有不是更新的情况下才能给detecting增加1,因为队列数目才实际由增加。consume的时候会实际减少队列数目.
		if(!isDoUpdate)
			sem_post(&g_semaphore_detecting);
		
	}
	else
	{
		ANNIWOLOGF(INFO,  "!!!!!!!!!!!!!!!!!!!!!! %s intRtsp:%d decode err %d!!!!!!!!!!!!!!!!!!!!!!tid:%s\n", timetoStr().c_str(), intRtsp, err,getThreadIdOfString(std::this_thread::get_id()).c_str());
	}
}


void* openFunc(void* param)
{
	//todo:为什么struct这里不能直接赋值？会报std::bad_alloc
	// linkID_struct  infoLinkId= *((linkID_struct*)param);

	linkID_struct  infoLinkId;
	linkID_struct*  tmp_ptr = (linkID_struct*)param;
	infoLinkId.link =   tmp_ptr->link;
	infoLinkId.id = tmp_ptr->id;
	bool bTryMultiple = tmp_ptr->bTryMultiple; //使用！

	//release inside this func
	delete tmp_ptr;
	param=NULL;

	linkID_struct*  pinfoLinkId = &infoLinkId;

	// static int MAX_RETRY_CNT=50;

	// for(int re_try_cnt=0;re_try_cnt<MAX_RETRY_CNT;re_try_cnt++)
	while(MonitorController::m_bMonitorRunning)//当需要退出时候为false
	{
		VideoDecode* video_dec0 = new VideoDecode();
		//10s超时应对远程连接较慢的问题
		if (video_dec0->Open(pinfoLinkId->link.c_str(),pinfoLinkId->id, 10) == NO_ERROR)
		{
			if (video_dec0->DecodeThreadBegin(data_callback, VideoDecode::BGR) == NO_ERROR)
			{
				std::unique_lock<std::mutex> uniqueLock(mtx4Open, std::defer_lock);

				ANNIWOLOGF(INFO, "%s decode camID %d begin\n",timetoStr().c_str(),pinfoLinkId->id);

				uniqueLock.lock();
					g_video_dec_pointer_list.push_back(video_dec0);
				uniqueLock.unlock();
				
				ANNIWOLOGF(INFO, "%s put camID %d to queue for monitor\n",timetoStr().c_str(),pinfoLinkId->id);
				break;

			}else
			{
				ANNIWOLOGF(INFO, "%s FATAL camID:%d DecodeThreadBegin error!tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,getThreadIdOfString(std::this_thread::get_id()).c_str());
				delete video_dec0;
				video_dec0=NULL;
				if(bTryMultiple)
				{
					/* wait 50 ms */
					SelectuSleep(50 * 1000);
					//todo:重试sleep的话可能在stop_uninitialized时候导致线程不能及时退出！
					// ANNIWOLOGF(INFO, "%s camID:%d  DecodeThreadBegin error retry Open Sleep %d sec...tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,0,getThreadIdOfString(std::this_thread::get_id()).c_str());
					ANNIWOLOGF(INFO, "%s camID:%d  DecodeThreadBegin error retry Open Sleep %d ms ...tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,50,getThreadIdOfString(std::this_thread::get_id()).c_str());
				}else
				{
					break;
				}

			}
		}else
		{
			ANNIWOLOGF(INFO, "%s FATAL camID:%d Open error!tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,getThreadIdOfString(std::this_thread::get_id()).c_str());
			delete video_dec0;
			video_dec0=NULL;
			if(bTryMultiple)
			{
				/* wait 50 ms */
				SelectuSleep(50 * 1000);

				//todo:重试sleep的话可能在stop_uninitialized时候导致线程不能及时退出！
				ANNIWOLOGF(INFO, "%s camID:%d Open error retry Open Sleep  %d ms ...tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,50,getThreadIdOfString(std::this_thread::get_id()).c_str());
			}else
			{
				break;
			}


		}

	}
	// else
	// {
	if(MonitorController::m_bMonitorRunning)
	{
		ANNIWOLOGF(INFO, "%s MonitorRunning. OpenFunc quit.camID: %d!tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,getThreadIdOfString(std::this_thread::get_id()).c_str());
	}else
	{
		ANNIWOLOGF(INFO, "%s  m_bMonitorRunning is false therefore OpenFunc quit.camID: %d!tid:%s\n",timetoStr().c_str(),pinfoLinkId->id,getThreadIdOfString(std::this_thread::get_id()).c_str());
	}
	// }

	return NULL;
}


void open_i_threadable(const std::string& link, int id, bool bTryMultiple)
{

	if((!MonitorController::m_bMonitorRunning))
		return;

	linkID_struct* infoLinkId = new linkID_struct;
	infoLinkId->id=id;
	infoLinkId->link=link;
	infoLinkId->bTryMultiple=bTryMultiple;
	//release infoLinkId inside this func
	std::thread* threadOpen = new std::thread(openFunc, (void*)(infoLinkId));
	ANNIWOLOGF(INFO, "%s  m_bMonitorRunning is true queue a open thread.camID: %d!tid:%s\n",timetoStr().c_str(),id,getThreadIdOfString(threadOpen->get_id()).c_str());

	g_openthread_id_list.push_back(threadOpen);
}

// void open_i(const std::string& link, int id)
// {
// 	linkID_struct* infoLinkId = new linkID_struct;
// 	infoLinkId->id=id;
// 	infoLinkId->link=link;
// 	//release inside this func
// 	void* ret= openFunc((void*)(infoLinkId));
// }


void MonitorController::stop_all_open_threads()
{
	if(MonitorController::m_bMonitorRunning)
	{
		ANNIWOLOGF(INFO, "%s MonitorController::stop_all_open_threads: Error m_bMonitorRunning is true !\n",timetoStr().c_str());
		return;
	}

	//todo:假如open线程卡住了又恢复的话可能会导致某一个摄像头多个线程取帧
	for (auto it = g_openthread_id_list.begin(); it != g_openthread_id_list.end();)
	{
		std::thread* tid = *it;
		if (tid && tid->joinable())		//异步open线程
		{
			std::string itsID = getThreadIdOfString(tid->get_id());
			ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: try to join a open thread:tid:%s !\n",timetoStr().c_str(), itsID.c_str());
			tid->join();
			ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: joined a open thread:tid:%s !\n",timetoStr().c_str(),itsID.c_str());

			it = g_openthread_id_list.erase(it);
			delete tid;
			tid=NULL;

		}else
		{
			ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: deleted non-joinable!\n",timetoStr().c_str());

			it = g_openthread_id_list.erase(it);
			if(tid)
			{
				delete tid;
			}
			tid=NULL;
		}
	}


}


void MonitorController::stop_all_decode_threads()
{
	if(MonitorController::m_bMonitorRunning)
	{
		ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: Error m_bMonitorRunning is true !\n",timetoStr().c_str());
		return;
	}

	ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: waiting lock... !\n",timetoStr().c_str());

	std::unique_lock<std::mutex> uniqueLock(mtx4Open, std::defer_lock);
	uniqueLock.lock();
	ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: Got lock... pointer_list: %lu !\n",timetoStr().c_str(),g_video_dec_pointer_list.size());

	for (auto it = g_video_dec_pointer_list.begin(); it != g_video_dec_pointer_list.end();)
	{
		VideoDecode* video_dec0 = *it;
		if(video_dec0)
		{

			int iRtspId = video_dec0->getIntRtspId();
			ANNIWOLOGF(INFO, "%s info stop_all_decode_threads: Closing VideoDecode pointer:%d !\n",timetoStr().c_str(),iRtspId);
			video_dec0->Close();
			it = g_video_dec_pointer_list.erase(it);

			delete video_dec0;
			video_dec0=NULL;
			ANNIWOLOGF(INFO, "%s info stop_all_decode_threads: Closed VideoDecode pointer:%d !\n",timetoStr().c_str(),iRtspId);
		}
		else
		{
			ANNIWOLOGF(INFO, "%s FATAL ERROR!!! stop_all_decode_threads VideoDecode pointer NULL,ignored!\n",timetoStr().c_str());
			it = g_video_dec_pointer_list.erase(it);
			// delete video_dec0;
			video_dec0=NULL;
		}
	}
	uniqueLock.unlock();


	ANNIWOLOGF(INFO, "%s MonitorController::stop_all_decode_threads: finished function... !\n",timetoStr().c_str());


}

void* MonitorController::monitorThreadFunc(void* param)
{
	bool isError=false;
	while(!isError && MonitorController::m_bMonitorRunning)
	{
		std::unique_lock<std::mutex> uniqueLock(mtx4Open, std::defer_lock);
		// ANNIWOLOGF(INFO, "info monitorThreadFunc:waiting lock... %d\n",MonitorController::m_bMonitorRunning);
		uniqueLock.lock();
		for (auto it = g_video_dec_pointer_list.begin(); it != g_video_dec_pointer_list.end();)
		{
			VideoDecode* video_dec0 = *it;
			if(video_dec0)
			{
				if(video_dec0->isFinished())
				{
					std::string strlink = video_dec0->getStrRtsp();
					int iRtspId = video_dec0->getIntRtspId();
					bool bPlsReOpen = true;  //无条件无限重试连接!
					ANNIWOLOGF(INFO, "%s info monitorThreadFunc: Close VideoDecode pointer:%d !\n",timetoStr().c_str(),iRtspId);
					video_dec0->Close();
					it=g_video_dec_pointer_list.erase(it);

					delete video_dec0;
					video_dec0=NULL;
					

					if(bPlsReOpen)
					{
						ANNIWOLOGF(INFO, "%s info monitorThreadFunc: try to re-open %d VideoDecode !\n",timetoStr().c_str(),iRtspId);
						open_i_threadable(strlink,iRtspId,true);//trigger multiple time connection
					}

				}else
				{
					++it;
				}
			}
			else
			{
				isError=true;
				ANNIWOLOGF(INFO, "%s FATAL monitorThreadFunc VideoDecode pointer NULL,quit thread loop !\n",timetoStr().c_str());

			}
		}
		uniqueLock.unlock();


		sleep(2);
	}

	ANNIWOLOGF(INFO, "%s info monitorThreadFunc:  monitorThreadFunc quiting!\n",timetoStr().c_str());

	return NULL;
}


int MonitorController::start_dec_monitor()
{
	if (m_trdMonitorDec.joinable())
		return OPEN_THREAD_EXIST_ERROR;
	MonitorController::m_bMonitorRunning=true;
	m_trdMonitorDec = std::thread(MonitorController::monitorThreadFunc, (void*)0);
	return NO_ERROR;
}

void MonitorController::stop_monitorAndAllThreads()
{
	ANNIWOLOGF(INFO, "%s MonitorController::stop_monitorAndAllThreads entered!\n",timetoStr().c_str());

	MonitorController::m_bMonitorRunning=false;
	if (m_trdMonitorDec.joinable())	
	{
		ANNIWOLOGF(INFO, "%s MonitorController::stop_monitorAndAllThreads try to join the monitor thread!\n",timetoStr().c_str());
		m_trdMonitorDec.join();
	}	
	
	ANNIWOLOGF(INFO, "%s MonitorController::monitor thread joined!\n",timetoStr().c_str());

	//因为open线程会往decode队列里边加入线程，所以必须先停止并回收
	stop_all_open_threads();

	ANNIWOLOGF(INFO, "%s MonitorController::all open threads stopped!\n",timetoStr().c_str());


	stop_all_decode_threads();

	ANNIWOLOGF(INFO, "%s MonitorController::all decoder threads stopped!\n",timetoStr().c_str());


	while(g_video_dec_pointer_list.size() > 0 || g_openthread_id_list.size() > 0)
	{
		ANNIWOLOGF(INFO, "%s WARNING:MonitorController::stop_monitorAndAllThreads g_video_dec_pointer_list NOT empty,again!!!\n",timetoStr().c_str());
		if(g_openthread_id_list.size() > 0)
		{
			ANNIWOLOGF(INFO, "%s WARNING:MonitorController::stop_monitorAndAllThreads g_openthread_id_list NOT empty,again!!!\n",timetoStr().c_str());
		}
		
		sleep(2);
		//因为open线程会往decode队列里边加入线程，所以必须先停止并回收
		stop_all_open_threads();

		stop_all_decode_threads();
	}
	MonitorController::m_bMonitorRunning=true;

}

///////////////////////////////////////////////////////////////////////////

    // Default constructor
    Rectangle::Rectangle () { m_pMonitorController=NULL; }

    // Destructor
    Rectangle::~Rectangle () {}

    // This is an debug function!!!!!!!!
    int Rectangle::getArea () {
        VideoDecode* video_dec0 = new VideoDecode();
        if (video_dec0->Open("rtsp://admin:Admin123@192.168.1.64:554/h264/ch1/main/av_stream",23, 3) == NO_ERROR)
        {
            if (video_dec0->DecodeThreadBegin(data_callback, VideoDecode::BGR) == NO_ERROR)
            {
                ANNIWOLOGF(INFO, "%s decode 5.96 begin\n",timetoStr().c_str());
            }
        }

		VideoDecode* video_dec1 = new VideoDecode();
        if (video_dec1->Open("rtsp://admin:root1234@192.168.1.65:554/h264/ch1/main/av_stream",5, 3) == NO_ERROR)
        {
            if (video_dec1->DecodeThreadBegin(data_callback, VideoDecode::BGR) == NO_ERROR)
            {
                ANNIWOLOGF(INFO, "%s decode 5.96 begin\n",timetoStr().c_str());
            }
        }
        return 0;

    }


	int Rectangle::start_framing() 
	{
		srand((int)time(0)); 
		if(!m_pMonitorController)
		{
			ANNIWOLOGF(INFO, "%s ANNIWO::start_framing: m_pMonitorController is null !\n",timetoStr().c_str() );
			return -1;
		}

		for(int i=0; i < (int)g_stream_list.size();i++)
		{
			// open_i(g_stream_list[i],g_stream_ids[i]);
			open_i_threadable(g_stream_list[i],g_stream_ids[i],true);
		}

		m_pMonitorController->start_dec_monitor();

		return 0;
	}

	int Rectangle::stop2uninitialize_framing() 
	{
		if(!m_pMonitorController)
		{
			ANNIWOLOGF(INFO, "%s  ANNIWO::stop2uninitialize_framing: m_pMonitorController is null !\n",timetoStr().c_str());
			return -1;
		}
		m_pMonitorController->stop_monitorAndAllThreads();

		delete m_pMonitorController;
		m_pMonitorController=NULL;
		
		g_stream_list.clear();
		g_stream_ids.clear();

		
		if(g_video_dec_pointer_list.size() > 0 || g_openthread_id_list.size() > 0)
		{
			ANNIWOLOGF(INFO, "%s -------FATAL! ANNIWO::stop2uninitialize_framing: g_video_dec_pointer_list/g_openthread_id_list !-----\n",timetoStr().c_str());
		}
 

	

		return 0;

	}




	std::pair< int,cv::Mat> Rectangle::consume_frame() 
	{ 

		std::map<int, cv::Mat>::iterator itera;

		if(callcnt % 1000 == 0)
		{
			ANNIWOLOGF(INFO, "%s  consume_frame wait sem.queue size:%d\n",timetoStr().c_str(), g_frames.size());
		}

		sem_wait(&g_semaphore_detecting);
		std::unique_lock<std::mutex> uniqueLock(mtx, std::defer_lock);

		uniqueLock.lock();

		if(callcnt % 1000 == 0)
		{
			ANNIWOLOGF(INFO, "%s  consume_frame Got lock.queue size:%d\n",timetoStr().c_str(), g_frames.size());
		}

		int idsIndex = callcnt%(int)g_stream_ids.size();
		int camID = 0;

		int loopcnt=0;
		while( g_frames.size() )
		{
			camID = g_stream_ids[idsIndex];

			itera = g_frames.find(camID);  
		
			if(itera != g_frames.end()) 
			{
				//HIT
				break;
			}
			else
			{
				//re-try next camID
				idsIndex++;
				callcnt++;
				idsIndex%=(int)g_stream_ids.size();
			}

			if(callcnt % 1000 == 0 || loopcnt > 1000)
			{
				ANNIWOLOGF(INFO, "%s  consume_frame:loopcnt:%d\n",timetoStr().c_str(),loopcnt);
			}
			loopcnt++;
		}

		ANNIWOCHECK(camID > 0);


		std::pair<int,cv::Mat> ret;
		ret.first=itera->first;
		ret.second=itera->second;
		
		g_frames.erase(itera);
		
		uniqueLock.unlock();

		if(callcnt % 1000 == 0)
		{
			ANNIWOLOGF(INFO, "%s:  %d  out lock.consume one image.queue size:%d\n",timetoStr().c_str(), ret.first, g_frames.size() );
		}

		// sem_post(&g_semaphore_framing);
		callcnt++;

		ANNIWOCHECK(ret.second.data !=NULL);
		size_t len = ret.second.rows*ret.second.cols*ret.second.elemSize();
		ANNIWOCHECK(len != 0);


		return ret; 
	}

	int  Rectangle::re_init_framer(std::vector<std::string> stream_links, std::vector<int> stream_ids) 
	{ 
		ANNIWOLOGF(INFO, "%s ANNIWO::re_init_framer: function enterred !\n",timetoStr().c_str());

		if(m_pMonitorController)
		{
			ANNIWOLOGF(INFO, "%s ANNIWO::re_init_framer: m_pMonitorController is NOT null !\n",timetoStr().c_str());
			return -1;
		}
		//  boost::python::list ret; 
		for (int i = 0; i < (int)stream_links.size(); ++i) 
		{
			
			g_stream_list.push_back(stream_links[i]);
			// Print it using printf
			ANNIWOLOGF(INFO, "%s re_init_framer:  %s\n", timetoStr().c_str(), stream_links[i].c_str());

		}
		
		for (int i = 0; i < (int)stream_ids.size(); ++i) 
		{
			int streamid = stream_ids[i];
			g_stream_ids.push_back(streamid);

			ANNIWOLOGF(INFO, "%s re_init_framer:  %d\n", timetoStr().c_str(),  streamid);

		}


		// 永不终止读取帧
		// sem_init(&g_semaphore_framing, 0, 40);
		sem_init(&g_semaphore_detecting, 0, 0);
		g_frames.clear();
		callcnt=0;


		m_pMonitorController=new MonitorController();

		
		return 0;
   } 


	int  Rectangle::init_framer(std::vector<std::string> stream_links, std::vector<int> stream_ids) 
	{ 
		if(m_pMonitorController)
		{
			ANNIWOLOGF(INFO, "%s ANNIWO::init_framer: m_pMonitorController is NOT null !\n",timetoStr().c_str());
			return -1;
		}
		
		ANNIWOCHECK( stream_links.size() == stream_ids.size() );
		for (int i = 0; i < (int)stream_links.size(); ++i) 
		{
			
			g_stream_list.push_back(stream_links[i]);

			int streamid = stream_ids[i];
			g_stream_ids.push_back(streamid);

			// Print it using printf
			ANNIWOLOGF(INFO, "%s init_framer camId:%d %s\n", timetoStr().c_str(), streamid, stream_links[i].c_str());

		}
		


		//40*500ms=20s,20秒无检测则终止取帧
		// sem_init(&g_semaphore_framing, 0, 40);
		sem_init(&g_semaphore_detecting, 0, 0);
		g_frames.clear();
		callcnt=0;


		m_pMonitorController=new MonitorController();

		
		return 0;
   } 

}