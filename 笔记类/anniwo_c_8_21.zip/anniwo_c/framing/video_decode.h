#ifndef __VIDEO_DECODE_H__
#define __VIDEO_DECODE_H__


#include <g3log/g3log.hpp>
#include <g3log/logworker.hpp>
#include <g3log/std2_make_unique.hpp>
#include <g3log/logmessage.hpp>
#include "../LogRotateAnniwo.h"


#include <iostream>
#include <thread>
#include "err.h"

#include <ctime>
#include <sys/time.h>
#include <unistd.h>
#include <string>
#include <sstream>

#include <mutex>
#include <condition_variable>

#ifdef __cplusplus
extern "C"{
#include "libavformat/avformat.h"
#include "libavdevice/avdevice.h"
#include "libswscale/swscale.h"
#include "libavutil/avutil.h"
#include "libavutil/imgutils.h"
#include "libavutil/time.h"
#include "libswresample/swresample.h"
#include "libavfilter/avfilter.h"
}
#endif


#define SelectuSleep(n) struct timeval timeout_unique;\
	timeout_unique.tv_sec = 0;\
    timeout_unique.tv_usec = n;\
	select(0, NULL, NULL, NULL, &timeout_unique);

typedef void(*__pDataCallBack)(int err, int width, int height, unsigned char* data, int intRtsp);



//////////utils///////////////////////////////////////////////////////////////
typedef unsigned long long ULL;

inline std::string getThreadIdOfString(const std::thread::id & id)
{
    std::stringstream sin;
    sin << id;
    return sin.str();
}

// ULL getThreadIdOfULL(const std::thread::id & id)
// {
//     return std::stoull(getThreadIdOfString(id));
// }

inline std::string timetoStr()
{
    char tmp[64];
    time_t t = time(NULL);
    tm *_tm = localtime(&t);
    int year  = _tm->tm_year+1900;
    int month = _tm->tm_mon+1;
    int date  = _tm->tm_mday;
    int hh = _tm->tm_hour;
    int mm = _tm->tm_min;
    int ss = _tm->tm_sec;
    sprintf(tmp,"%04d-%02d-%02d %02d:%02d:%02d ",year,month,date,hh,mm,ss);
    return std::string(tmp);
}


//curMinutetime = datetime.datetime.now().hour * 60 + datetime.datetime.now().minute
inline int getCurMinuteDaytimeXB()
{
    time_t t;
    struct tm * timeinfo;
    time(&t);
    timeinfo = localtime(&t);

    //    int tm_sec;         /* 秒，范围从 0 到 59*/
    //    int tm_min;         /* 分，范围从 0 到 59*/
    //    int tm_hour;        /* 小时，范围从 0 到 23 */

    return timeinfo->tm_hour*60+timeinfo->tm_min;

}

//////////////////////////////////////////////////////////////////////////////////



typedef struct MyAVPacketList {
    AVPacket pkt;
    struct MyAVPacketList *next;
    int serial;
} MyAVPacketList;

typedef struct PacketQueue {
    MyAVPacketList *first_pkt, *last_pkt;
    int nb_packets;
    int size;
    int64_t duration;
    int abort_request;
    int serial;
    std::mutex *mutex;
    std::condition_variable *cond;
} PacketQueue;




class VideoDecode
{
public:
	VideoDecode();
	~VideoDecode();

public:
	typedef enum
	{
		GPU = 0,
		CPU = 1,
	}DECODE_MODE;

	typedef enum
	{
		RGB = 0,
		BGR = 1,
	}RETURN_DATA_TYPE;

public:
	int Open(const std::string rtsp_addr,int rtsp_id, int timeout); //timeout: s
	void SetMode(DECODE_MODE eMode);		//GPU 0, CPU 1
	bool Close();
	int DecodeThreadBegin(__pDataCallBack data_func, RETURN_DATA_TYPE eType = RGB);

public:
	void* DecodeThreadProc();
	void* Read_thread();

	bool isFfmpegApiTimeout()
	{
		return ( time(NULL) - mlasttime > 3600);//大于1小时
	}

	bool isFinished() //线程循环退出
	{
		return m_bFinished;
	}

	std::string getStrRtsp()
	{
		return m_strRtsp;
	}

	int  getIntRtspId()
	{
		return m_intRtspId;
	}
	

private:
	int rtsp_open(const std::string rtsp_addr, int timeout = 3);
	bool global_init();

	void print_stream_info(AVFormatContext* ctx, unsigned int stream_id);
	int gen_codec_param();

private:
	int packet_queue_put_private(PacketQueue *q, AVPacket *pkt);
	int packet_queue_put(PacketQueue *q, AVPacket *pkt);
	int packet_queue_put_nullpacket(PacketQueue *q, int stream_index);
	int packet_queue_init(PacketQueue *q);
	void packet_queue_flush(PacketQueue *q);
	void packet_queue_destroy(PacketQueue *q);
	void packet_queue_abort(PacketQueue *q);
	void packet_queue_start(PacketQueue *q);
	int packet_queue_get(PacketQueue *q, AVPacket *pkt, int block, int *serial);

private:

	DECODE_MODE m_eDecodeMode;
	__pDataCallBack m_data_cbfunc;
	RETURN_DATA_TYPE m_e_data_type;
	
	int m_nOpenTimeOut; //open等所有的超时时间
	
	std::thread m_trdDecode; //解码线程

	std::thread m_trdContinueReadRtsp;//读取线程

	bool m_bDecodeRunning;
	bool m_bOpened;

	bool m_bFinished;
	std::string m_strRtsp;
	int m_intRtspId;



	AVFormatContext *m_ctx;
	unsigned int m_video_stream_id;
	PacketQueue videoq;

	bool m_bdetailed_debug;
	int  m_camId;

	//控制av_find_stream_info, av_read_frame等超时卡住的情况
	time_t mlasttime;
	
};


#endif //__VIDEO_DECODE_H__
