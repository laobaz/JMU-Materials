#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <vector>
#include <utility>  // std::pair, std::make_pair
#include <string>    // std::string
#include <opencv2/opencv.hpp>
#include <thread>




namespace shapes {
    class MonitorController
    {
        public:
            int start_dec_monitor();
            void stop_monitorAndAllThreads();
            static void* monitorThreadFunc(void* param);
            static bool m_bMonitorRunning;
        private:
            std::thread m_trdMonitorDec;
            void stop_all_decode_threads();
            void stop_all_open_threads();
        
    };

    class Rectangle {
        public:
            Rectangle();
            ~Rectangle();
            int getArea();
            int  init_framer(std::vector<std::string> stream_links, std::vector<int> stream_ids);
            int  re_init_framer(std::vector<std::string> stream_links, std::vector<int> stream_ids);
            std::pair< int,cv::Mat>  consume_frame();
            int start_framing();
	        int stop2uninitialize_framing();

        private:
            MonitorController* m_pMonitorController;
    };
}

#endif