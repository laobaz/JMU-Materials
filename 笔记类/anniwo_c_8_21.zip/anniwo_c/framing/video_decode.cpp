#include "video_decode.h"


#include "libavutil/avstring.h"
#include "libavutil/eval.h"
#include "libavutil/mathematics.h"
#include "libavutil/pixdesc.h"
#include "libavutil/imgutils.h"
#include "libavutil/dict.h"
#include "libavutil/parseutils.h"
#include "libavutil/samplefmt.h"
#include "libavutil/avassert.h"
#include "libavutil/time.h"
#include "libavformat/avformat.h"
#include "libavdevice/avdevice.h"
#include "libswscale/swscale.h"
#include "libavutil/opt.h"
#include "libavcodec/avfft.h"
#include "libavcodec/avcodec.h"
#include "libswresample/swresample.h"

#include <sys/time.h>



#include <cstdlib>
#include <cstring>

#define MIN_FRAMES 25
#define MAX_QUEUE_SIZE (15 * 1024 * 1024)



static const int tidyuptimeS= 1438; //23:58
static const int tidyuptimeE= 1440; //24:00

static AVPacket flush_pkt;


int VideoDecode::packet_queue_put_private(PacketQueue *q, AVPacket *pkt)
{
    MyAVPacketList *pkt1;

	if(m_bdetailed_debug)
	{
		ANNIWOLOGF(INFO,  "put_private. m_camId:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,q->abort_request, q->nb_packets);
	}

    if (q->abort_request)
       return -1;

    pkt1 = (MyAVPacketList*)av_malloc(sizeof(MyAVPacketList));
    if (!pkt1)
        return -1;
    pkt1->pkt = *pkt;
    pkt1->next = NULL;
    if (pkt == &flush_pkt)
        q->serial++;
    pkt1->serial = q->serial;

    if (!q->last_pkt)
        q->first_pkt = pkt1;
    else
        q->last_pkt->next = pkt1;
    q->last_pkt = pkt1;
    q->nb_packets++;
    q->size += pkt1->pkt.size + sizeof(*pkt1);
    q->duration += pkt1->pkt.duration;
    
	if (q->abort_request)
	{
       return -1;
	}else
	{
		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "put try to notify. camID:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,q->abort_request, q->nb_packets);
		}
		q->cond->notify_one();
		return 0;
	}
}

int VideoDecode::packet_queue_put(PacketQueue *q, AVPacket *pkt)
{
    int ret;

    if (q->abort_request)
       return -1;

	{
		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "put try to get lock.camID:%d  q->abort_request: %d videoq.nb_packets:%d\n",m_camId,q->abort_request, q->nb_packets);
		}
		std::unique_lock<std::mutex> locker(*(q->mutex));
		ret = packet_queue_put_private(q, pkt);
	}


    if (pkt != &flush_pkt && ret < 0)
        av_packet_unref(pkt);

    return ret;
}

int VideoDecode::packet_queue_put_nullpacket(PacketQueue *q, int stream_index)
{
    AVPacket pkt1, *pkt = &pkt1;
    av_init_packet(pkt);
    pkt->data = NULL;
    pkt->size = 0;
    pkt->stream_index = stream_index;
    return packet_queue_put(q, pkt);
}

/* packet queue handling */
int VideoDecode::packet_queue_init(PacketQueue *q)
{
    memset(q, 0, sizeof(PacketQueue));
    q->mutex = new std::mutex;
    if (!q->mutex) {
        ANNIWOLOGF(INFO,  "packet_queue_init:CreateMutex failed!\n" );
        return AVERROR(ENOMEM);
    }
    q->cond = new std::condition_variable;
    if (!q->cond) {
        ANNIWOLOGF(INFO,  "packet_queue_init:CreateCond failed!\n");
        return AVERROR(ENOMEM);
    }
    q->abort_request = 1;
	
    return 0;
}

void VideoDecode::packet_queue_flush(PacketQueue *q)
{
    MyAVPacketList *pkt, *pkt1;

	{
		std::unique_lock<std::mutex> locker(*(q->mutex));
		for (pkt = q->first_pkt; pkt; pkt = pkt1) {
			pkt1 = pkt->next;
			av_packet_unref(&pkt->pkt);
			av_freep(&pkt);
		}
		q->last_pkt = NULL;
		q->first_pkt = NULL;
		q->nb_packets = 0;
		q->size = 0;
		q->duration = 0;
    }
}

void VideoDecode::packet_queue_destroy(PacketQueue *q)
{
    packet_queue_flush(q);
    delete q->mutex;
    delete q->cond;
}

void VideoDecode::packet_queue_abort(PacketQueue *q)
{
	{
		std::unique_lock<std::mutex> locker(*(q->mutex));

		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "inside packet_queue_abort. m_camId:%d  m_bDecodeRunning:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning,videoq.abort_request, videoq.nb_packets);
		}

		q->abort_request = 1;

		q->cond->notify_one();

    }
}

void VideoDecode::packet_queue_start(PacketQueue *q)
{
	{
		std::unique_lock<std::mutex> locker(*(q->mutex));
		q->abort_request = 0;
		packet_queue_put_private(q, &flush_pkt);
    }
}

/* return < 0 if aborted, 0 if no packet and > 0 if packet.  */
int VideoDecode::packet_queue_get(PacketQueue *q, AVPacket *pkt, int block, int *serial)
{
    MyAVPacketList *pkt1;
    int ret;

	{
		std::unique_lock<std::mutex> locker(*(q->mutex));

		for (;;) {
			if (q->abort_request) {
				ret = -1;
				break;
			}

			pkt1 = q->first_pkt;
			if (pkt1) {
				q->first_pkt = pkt1->next;
				if (!q->first_pkt)
					q->last_pkt = NULL;
				q->nb_packets--;
				q->size -= pkt1->pkt.size + sizeof(*pkt1);
				q->duration -= pkt1->pkt.duration;
				*pkt = pkt1->pkt;
				if (serial)
					*serial = pkt1->serial;
				av_free(pkt1);
				ret = 1;
				break;
			} else if (!block) {
				ret = 0;
				break;
			} else {
				q->cond->wait(locker);
			}
		}
    }
    return ret;
}









long getCurrentTime()	//ms
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}
bool IsEqual(float a, float b)
{
	return fabs(a-b) < 1e-6;
}



VideoDecode::VideoDecode()
{
	global_init();



	m_bOpened = false;
	m_bDecodeRunning = false;

	// m_eDecodeMode = VideoDecode::GPU;
	m_eDecodeMode = VideoDecode::CPU;
	m_data_cbfunc = NULL;

	m_strRtsp = "";
	m_intRtspId = -1;
	m_bFinished=false;
}

VideoDecode::~VideoDecode()
{

}

void* DecodeThreadFunc(void* param)
{
	if (!param)
	{
		return NULL;
	}

	VideoDecode* pVideoDecode = (VideoDecode*)param;
	if (!pVideoDecode)
	{
		return NULL;
	}

	return pVideoDecode->DecodeThreadProc();
}



void VideoDecode::print_stream_info(AVFormatContext* ctx, unsigned int stream_id)
{
	//duration
	int64_t duration = ctx->duration / AV_TIME_BASE;
	//fps
	int fps_num = ctx->streams[stream_id]->r_frame_rate.num;
	int fps_den = ctx->streams[stream_id]->r_frame_rate.den;
	double fps = 0.0;
	if (fps_den > 0)
	{
		fps = fps_num / fps_den;
	}
	av_log(NULL, AV_LOG_INFO, "duration:%ld,\nfps:%f,\n", duration, fps);
}


//todo:这个超时有问题，比如对多个线程则不行！！！
static int interrupt_cb(void *param)
{
	VideoDecode* pThisVideoDecObj = (VideoDecode*)param;
    
    if ( pThisVideoDecObj->isFfmpegApiTimeout() )
	{
        ANNIWOLOGF(INFO, "interrupt_cb:camID:%d\n", pThisVideoDecObj->getIntRtspId());
		return 1;//这个就是超时的返回
    }
    return 0;
}

void* threadread_func(void* param)
{
	if (!param)
	{
		return NULL;
	}

	VideoDecode* pVideoDecode = (VideoDecode*)param;
	if (!pVideoDecode)
	{
		return NULL;
	}

	return pVideoDecode->Read_thread();
}

void* VideoDecode::Read_thread()
{
	bool bIsFindLost = false;
	int ret,nCapCount,err;
	long lCurTime,lCurTimex;
	long lLogReadTime=getCurrentTime();

	long lcallbackTime = 0;


	AVPacket pkt;

	int iseof=0;

	while (m_bDecodeRunning){

		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "read loop camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
		}

		if(videoq.nb_packets > 5*MIN_FRAMES)
		{
			/* wait 10 ms */
			SelectuSleep(10 * 1000);

			continue;//No need to read more when queue get max size!
		}


		mlasttime=time(NULL);
		ret = av_read_frame(m_ctx, &pkt);
		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "called read.camID:%d  ret:%d m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,ret,m_bDecodeRunning, videoq.nb_packets);
		}


        if (ret < 0) {
            if ((ret == AVERROR_EOF || avio_feof(m_ctx->pb)) && !iseof) {
                if (m_video_stream_id >= 0)
				{
					if(m_bdetailed_debug)
					{
						ANNIWOLOGF(INFO,  "calling put_nullpacket.camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
					}
                    packet_queue_put_nullpacket(&videoq, m_video_stream_id);
				}
                iseof = 1;
            }
            if (m_ctx->pb && m_ctx->pb->error)
			{
				ANNIWOLOGF(INFO,  "m_intRtspId:%d av_read_frame ret %d, errno:%d \n", m_intRtspId,ret,errno);
				m_bFinished=true;//公有属性,callback里边会检查
                break;
			}

			/* wait 10 ms */
			SelectuSleep(10 * 1000);

            continue;
        } else {
            iseof = 0;
        }



		if (pkt.stream_index != m_video_stream_id || pkt.size < 1)
		{
			if(m_bdetailed_debug)
			{
				ANNIWOLOGF(INFO,  "calling av_packet_unref 1.camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
			}
			av_packet_unref(&pkt);
			goto discard_packet_read;
		}

		static const int MIN_I_FRAME_SIZE = 8096;
		if (pkt.lost_packet > 1){
			bIsFindLost = true;
			ANNIWOLOGF(INFO,  "read frame lost %d packet\n", pkt.lost_packet);
		}
		else if (pkt.flags == 1 && pkt.size > MIN_I_FRAME_SIZE)
		{
			bIsFindLost = false;
		}

		if (bIsFindLost)
		{
			if(m_bdetailed_debug)
			{
				ANNIWOLOGF(INFO,  "calling av_packet_unref 2. camID:%d m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
			}
			av_packet_unref(&pkt);
			goto discard_packet_read;
		}

		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "calling queue_put. camID:%d m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
		}
		ret = packet_queue_put(&videoq,&pkt);
		if(ret !=0 )
		{
			if(videoq.abort_request)
			{
				ANNIWOLOGF(INFO,  "packet_queue_put failed abort request!:%d \n",m_intRtspId);
			}else
			{
				ANNIWOLOGF(INFO,  "packet_queue_put failed:%d \n",m_intRtspId);
			}
		}

		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "called queue_put.camID:%d  m_bDecodeRunning: %d videoq.nb_packets%d:\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
		}




discard_packet_read:
		nCapCount++;
		
		lCurTime = getCurrentTime();

		if (lCurTime - lLogReadTime >= 20000 && nCapCount > 0){
			// ANNIWOLOGF(INFO,  "------------[%d] lCurTime:%ld  lLogReadTime:%ld lcallbackTime:%ld-----------\n", m_intRtspId, lCurTime , lLogReadTime,lcallbackTime);
			float fCur10FrameRate = nCapCount / ((lCurTime - lLogReadTime) / 1000.0);
			ANNIWOLOGF(INFO,  "------------[%d] last 10s pkt read rate %.2f pack/s ret:%d \n", m_intRtspId, fCur10FrameRate,ret);

			nCapCount = 0;
			lLogReadTime = lCurTime;
		}


		// SelectuSleep(2 * 1000); 本身读取太慢，不需要再sleep了。
	}
	m_bFinished=true;

	ANNIWOLOGF(INFO,  "--[%d] read thread quit with m_bDecodeRunning: %d \n", m_intRtspId, m_bDecodeRunning);

	     


	return 0;
}



void* VideoDecode::DecodeThreadProc()
{
	this->print_stream_info(m_ctx, m_video_stream_id);

	av_init_packet(&flush_pkt);
	flush_pkt.data = (uint8_t *)&flush_pkt;

	AVCodecParameters *codecpar = NULL;
	AVCodec *codec = NULL;
	AVCodecContext *codec_ctx = NULL; 

	codecpar = m_ctx->streams[m_video_stream_id]->codecpar;
	{

#ifdef __aarch64__   
		if(codecpar->codec_id == AV_CODEC_ID_H264 )
		{
			//指定解码器
			codec = avcodec_find_decoder_by_name("h264_nvv4l2dec");
		}else if(codecpar->codec_id == AV_CODEC_ID_H265)
		{
			//指定解码器
			codec = avcodec_find_decoder_by_name("hevc_nvv4l2dec");
		}else
		{
			ANNIWOLOGF(INFO,  "codecpar codec_id :%d! \n",codecpar->codec_id);
			ANNIWOCHECK(false);
		}
		

#else
		//软解码
		codec = avcodec_find_decoder(codecpar->codec_id);
#endif

		if (!codec) {
			fprintf(stderr, "Codec not found\n");
			ANNIWOCHECK(false);

		}
		ANNIWOLOGF(INFO,  "decoding with id:%d! \n",codecpar->codec_id);
		

	}

	if (NULL == codec){
		ANNIWOLOGF(INFO,  "mode = %d, codecpar->codec_id = %d, avcodec_find_decoder failed\n", m_eDecodeMode, codecpar->codec_id);
		m_data_cbfunc(DECODE_FIND_DECODER_ERROR, 0, 0, NULL, m_intRtspId);
		return NULL;
	}

	if (packet_queue_init(&videoq) < 0 )
	{
		ANNIWOLOGF(INFO,  "packet_queue_init failed!\n");
		m_data_cbfunc(DECODE_ALLOC_BUF_FAIL, 0, 0, NULL, m_intRtspId);
		return NULL;
	}

	codec_ctx = avcodec_alloc_context3(codec);
	if (NULL == codec_ctx){
		ANNIWOLOGF(INFO,  "avcodec_alloc_context3 failed\n");
		m_data_cbfunc(DECODE_ALLOC_CTX_ERROR, 0, 0, NULL, m_intRtspId);
		return NULL;
	}

	//time_base 不需要赋值
	//codec_ctx->time_base = codecpar->sample_aspect_ratio;
	//codec_id不需要赋值
	//codec_ctx->codec_id = codecpar->codec_id;
	//硬解码指定
	//软编码需要赋值
	//https://stackoverflow.com/questions/23067722/swscaler-warning-deprecated-pixel-format-used
	
	AVPixelFormat pixFormat;

#ifdef __aarch64__   
	switch (codecpar->format) {
		case AV_PIX_FMT_YUVJ420P :
			pixFormat = AV_PIX_FMT_YUV420P;
			break;
		default:
			ANNIWOLOGF(INFO,  "not YUVJ420P codecpar->format is:%d! \n",codecpar->format);
			pixFormat = AV_PIX_FMT_YUV420P;
			break;
	}
#else
	switch (codecpar->format) {
		case AV_PIX_FMT_YUVJ420P :
			pixFormat = AV_PIX_FMT_YUV420P;
			break;
		case AV_PIX_FMT_YUVJ422P  :
			pixFormat = AV_PIX_FMT_YUV422P;
			break;
		case AV_PIX_FMT_YUVJ444P   :
			pixFormat = AV_PIX_FMT_YUV444P;
			break;
		case AV_PIX_FMT_YUVJ440P :
			pixFormat = AV_PIX_FMT_YUV440P;
			break;
		default:
			pixFormat = AVPixelFormat(codecpar->format);
			break;
	}
#endif



	//事实上codecpar包含了大部分解码器相关的信息，这里是直接从AVCodecParameters复制到AVCodecContext
    avcodec_parameters_to_context(codec_ctx, codecpar);

	codec_ctx->pix_fmt = pixFormat;

	codec_ctx->thread_count = 8; //设置解码线程数目
//	codec_ctx->thread_type  = FF_THREAD_FRAME; //设置解码type
	codec_ctx->thread_type  = FF_THREAD_SLICE; //设置解码type
	
	// codec_ctx->skip_frame =  AVDISCARD_NONKEY; //仅仅保留关键帧，忽略P,B帧，加快解码速度---达不到一秒一帧
	// codec_ctx->skip_frame =  AVDISCARD_NONINTRA; //忽略丢弃所有非内帧 加快解码速度 ---达不到一秒一帧
	codec_ctx->skip_frame =  AVDISCARD_BIDIR; //丢弃所有的双向帧：忽略B帧 加快解码速度 
	
	
	


	int err = avcodec_open2(codec_ctx, codec, NULL);
	if (err < 0){
		ANNIWOLOGF(INFO,  "avcodec_open2 failed\n");
		avcodec_close(codec_ctx);
		avcodec_free_context(&codec_ctx);
		av_freep(&codec_ctx);
		m_data_cbfunc(DECODE_CODEC_OPEN2_FAIL, 0, 0, NULL, m_intRtspId);
		return NULL;
	}

	//视频流中解码的frame
	AVFrame *frame = av_frame_alloc();


	//sws frame
	AVFrame *frame_bgr = av_frame_alloc();
	/**
	 * AV_PIX_FMT_BGRA 对应opencv中的CV_8UC4,
	 * AV_PIX_FMT_BGR24对应opencv中的CV_8UC3
	 */
	AVPixelFormat format = (m_e_data_type == RGB) ? AV_PIX_FMT_RGB24 : AV_PIX_FMT_BGR24;
	int align = 1;
	ANNIWOLOGF(INFO, "width:%d,\nheight:%d,\n", codec_ctx->width, codec_ctx->height);
	int buffer_size = av_image_get_buffer_size(format, codec_ctx->width, codec_ctx->height, align);
	unsigned char *buffer = (unsigned char*) av_malloc(buffer_size);
	if (NULL == buffer){
		ANNIWOLOGF(INFO,  "allocate buffer failed!\n");
		avcodec_close(codec_ctx);
		avcodec_free_context(&codec_ctx);
		av_freep(&codec_ctx);

		av_frame_unref(frame);
		av_frame_unref(frame_bgr);
		av_freep(&frame);
		av_freep(&frame_bgr);

		m_data_cbfunc(DECODE_ALLOC_BUF_FAIL, 0, 0, NULL, m_intRtspId);
		return NULL;
	}
	av_image_fill_arrays(frame_bgr->data, frame_bgr->linesize, buffer, format, codec_ctx->width, codec_ctx->height, align);

	//初始化图像pixer format进行转换的context
	struct SwsContext * sws_ctx;
	int dest_width = codec_ctx->width;
	int dest_height = codec_ctx->height;
	ANNIWOLOGF(INFO, "src_codec_id:%d,\ncodec_id:%d,\n", codecpar->codec_id, codec_ctx->codec_id);
	ANNIWOLOGF(INFO, "src_pix_format:%d,\ncodec_pix_format:%d,\ndest_pix_format:%d,\n", codecpar->format, codec_ctx->pix_fmt, format);


	sws_ctx = sws_getContext(codec_ctx->width,
			codec_ctx->height,
			codec_ctx->pix_fmt,
			dest_width,
			dest_height,
			format,
			SWS_POINT,
			NULL, NULL,NULL);			
	
	// change the range of input data by first reading the current color space and then setting it's range as yuvj.
	int dummy[4];
	int srcRange, dstRange;
	int brightness, contrast, saturation;
	sws_getColorspaceDetails(sws_ctx, (int**)&dummy, &srcRange, (int**)&dummy, &dstRange, &brightness, &contrast, &saturation);
	const int* coefs = sws_getCoefficients(SWS_CS_DEFAULT);
	srcRange = 1; // this marks that values are according to yuvj
	sws_setColorspaceDetails(sws_ctx, coefs, srcRange, coefs, dstRange,
								brightness, contrast, saturation);



	//开始解码

	bool bIsFindLost = false;
	int ret = AVERROR(EAGAIN);

	long lCurTime;
	long lcallbackTime = getCurrentTime();
	long lLogTime= getCurrentTime();

	long lSpendTime;
	long exetractFrameCnt=0;



        
    packet_queue_start(&videoq);

	//读取线程开始
	m_trdContinueReadRtsp = std::thread(threadread_func, this);

	SelectuSleep(5 * 1000);
	
	int pkt_serial = -1;
	int packet_pending=0;
	AVPacket savepkt;
	AVPacket pkt;

	
	//解码线程
	while (m_bDecodeRunning)
	{

		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "decode outer loop camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
		}

		while(m_bDecodeRunning)//取一帧,通过goto跳出
		{

			if(m_bdetailed_debug)
			{
				ANNIWOLOGF(INFO,  "decode inner loop camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
			}

			//videoq.serial仅仅在flush之后才会变化,是用于控制flush的.
			if (videoq.serial == pkt_serial) {
				do {

					if(m_bdetailed_debug)
					{
						ANNIWOLOGF(INFO,  "decode receive frame loop camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
					}

					if (videoq.abort_request)
					{
						m_bDecodeRunning=false;
						goto loop_end;
					}


					if(m_bdetailed_debug)
					{
						ANNIWOLOGF(INFO,  "decode call receive_frame camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
					}
					ret = avcodec_receive_frame(codec_ctx, frame);
					if (ret >= 0) {
							frame->pts = frame->pkt_dts;
					}

					if (ret == AVERROR_EOF) {

						if(m_bdetailed_debug)
						{
							ANNIWOLOGF(INFO,  "decode call flush_buffers camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
						}

						// d->finished = pkt_serial;
						avcodec_flush_buffers(codec_ctx);

						m_data_cbfunc(DECODE_RECEIVCE_FRAME_ERROR, 0, 0, NULL, m_intRtspId);
						ANNIWOLOGF(INFO,  "camId:%d EOF avcodec_receive_frame ret %d \n", m_intRtspId, ret);
						m_bFinished=true;
						goto loop_end;
					}
					if (ret >= 0)
					{
						//got frame
						// ANNIWOLOGF(INFO,  "got frame! avcodec_receive_frame ret %d \n", ret);
						goto got_frame_ok;
					}

					if(ret == AVERROR_INVALIDDATA)
					{
						ANNIWOLOGF(INFO,  "%d invalid data receive ret %d \n", m_intRtspId, ret);
					}

				} while (ret != AVERROR(EAGAIN));
			}

			do {

				if(m_bdetailed_debug)
				{
					ANNIWOLOGF(INFO,  "decode queue_get loop camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
				}

				//此修改无效				
				// if(videoq.nb_packets > MIN_FRAMES)
				// {
				// 	codec_ctx->skip_frame = AVDISCARD_ALL; //直接丢弃过时排队的包,最快速吃包
				// }else 
				// {
				// 	codec_ctx->skip_frame = AVDISCARD_BIDIR;//恢复正常
				// }

				if (packet_pending) {
					if(m_bdetailed_debug)
					{
						ANNIWOLOGF(INFO,  "decode call move_ref  camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
					}
					av_packet_move_ref(&pkt, &savepkt);
					packet_pending = 0;
				} else {
					if(m_bdetailed_debug)
					{
						ANNIWOLOGF(INFO,  "decode call queue_get  camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
					}
					if (packet_queue_get(&videoq, &pkt, 1, &pkt_serial) < 0)
					{
						m_data_cbfunc(DECODE_RECEIVCE_FRAME_ERROR, 0, 0, NULL, m_intRtspId);
						if(videoq.abort_request)
						{
							m_bDecodeRunning = false;
							ANNIWOLOGF(INFO,  "packet_queue_get failed abort request!:%d \n",m_intRtspId);
						}else
						{
							m_bDecodeRunning = false;
							ANNIWOLOGF(INFO,  "packet_queue_get failed:%d \n",m_intRtspId);
						}
						goto loop_end;
					}

				}
			} while (videoq.serial != pkt_serial);

			if (pkt.data == flush_pkt.data) {
				if(m_bdetailed_debug)
				{
					ANNIWOLOGF(INFO,  "decode call flush_buffers again  camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
				}
				avcodec_flush_buffers(codec_ctx);
			} else 
			{
				if(m_bdetailed_debug)
				{
					ANNIWOLOGF(INFO,  "decode call send_packet  camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
				}
				ret  = avcodec_send_packet(codec_ctx, &pkt);
				if (ret == AVERROR(EAGAIN)) {
					ANNIWOLOGF(INFO, "Receive_frame and send_packet both returned EAGAIN, which is an API violation.\n");
					packet_pending = 1;
					av_packet_move_ref(&savepkt, &pkt);
				}

				if(ret == AVERROR_INVALIDDATA)
				{
					ANNIWOLOGF(INFO,  "%d invalid data send ret %d \n", m_intRtspId, ret);
				}
				
				av_packet_unref(&pkt);
			}
		}



got_frame_ok:
		//软解码
		//400ms 解码一次
		lCurTime = getCurrentTime();
		if ( lcallbackTime == 0 || lCurTime - lcallbackTime >= 400 ){

			lCurTime = getCurrentTime();

			if(frame->linesize == 0 || frame->height == 0)
			{
				ANNIWOLOGF(INFO,  "m_camId:%d DecodeThreadProc...empty frame\n",m_camId);
				continue;
			}else
			{
				// ANNIWOLOGF(INFO,  "DecodeThreadProc...Got frame\n");
			}



			memset(buffer, 0, buffer_size);//frame_bgr

			if(m_bdetailed_debug)
			{
				ANNIWOLOGF(INFO,  "decode call sws_scale  camID:%d  m_bDecodeRunning: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning, videoq.nb_packets);
			}
			sws_scale(sws_ctx, frame->data,
					frame->linesize, 0, frame->height, frame_bgr->data,
					frame_bgr->linesize);
			m_data_cbfunc(NO_ERROR, frame->width, frame->height, frame_bgr->data[0], m_intRtspId);
			lcallbackTime=lCurTime;
			
			av_frame_unref(frame);
			//[swscaler @ 0x7f9230178f80] bad dst image pointers
			// av_frame_unref(frame_bgr);
		}else
		{
			av_frame_unref(frame);

			lCurTime = getCurrentTime();

			goto loop_end;
		}

		exetractFrameCnt++;


		// av_frame_unref(frame);  //不需要,同frame_bgr?
		// av_packet_unref(&savepkt);//不需要，因为queue和前面的代码会管理。
		// av_packet_unref(&pkt);  //不需要，因为queue和前面的代码会管理。

		//todo:为什么这里出不来？？ ok 了
		if (lCurTime - lLogTime >= 10000 && exetractFrameCnt > 0){
			// ANNIWOLOGF(INFO,  "------------[%d] lCurTime:%ld  lLogTime:%ld lcallbackTime:%ld-----------\n", m_intRtspId, lCurTime , lLogTime,lcallbackTime);
			float fCur10FrameRate = exetractFrameCnt / ((lCurTime - lLogTime) / 1000.0);
			ANNIWOLOGF(INFO,  "------------[%d] last 10s extract frame rate %.2f frame/s------------\n", m_intRtspId, fCur10FrameRate);
			ANNIWOLOGF(INFO,  "------------[%d] pkg queue size:%d------------\n", m_intRtspId, videoq.nb_packets);


			exetractFrameCnt = 0;
			lLogTime = lCurTime;
		}

loop_end:
		SelectuSleep(2 * 1000);
		if(m_bdetailed_debug)
		{
			ANNIWOLOGF(INFO,  "loop_end. m_camId:%d  m_bDecodeRunning:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning,videoq.abort_request, videoq.nb_packets);
		}

	}

	m_bDecodeRunning = false;


	if(m_bdetailed_debug)
	{
		ANNIWOLOGF(INFO,  "out loop. m_camId:%d  m_bDecodeRunning:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning,videoq.abort_request, videoq.nb_packets);
	}

    packet_queue_abort(&videoq);

	if(m_bdetailed_debug)
	{
		ANNIWOLOGF(INFO,  "after packet_queue_abort. m_camId:%d  m_bDecodeRunning:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning,videoq.abort_request, videoq.nb_packets);
	}

	packet_queue_flush(&videoq);

	sws_freeContext(sws_ctx);
	av_frame_unref(frame);
	av_frame_unref(frame_bgr);
	av_freep(&frame);
	av_freep(&frame_bgr);
	av_freep(&buffer);
	avcodec_close(codec_ctx);
	avcodec_free_context(&codec_ctx);
	av_freep(&codec_ctx);


	if(m_bdetailed_debug)
	{
		ANNIWOLOGF(INFO,  "after av_freep. m_camId:%d  m_bDecodeRunning:%d q->abort_request: %d videoq.nb_packets:%d\n",m_camId,m_bDecodeRunning,videoq.abort_request, videoq.nb_packets);
	}

	m_bFinished=true;

	return 0;
}

bool VideoDecode::global_init()
{
	static bool bIsInit = false;
	if (!bIsInit)
	{
		avdevice_register_all();
		avformat_network_init();
		av_log_set_level(AV_LOG_INFO);

	 	m_bdetailed_debug = -1;
	    m_camId = -1;

		bIsInit = true;
	}

	return true;
}

int VideoDecode::rtsp_open(const std::string rtsp_addr, int timeout /*= 3*/)
{
	if (m_bOpened)
		return RTSP_ALREADY_OPEN;

	long lStart = getCurrentTime();
	ANNIWOLOGF(INFO, "m_camId:%d Open Begin: %s\n",m_camId, rtsp_addr.c_str());
	m_ctx = avformat_alloc_context();
	if (!m_ctx)
	{
		return ALLOCTE_CTX_ERROR;
	}

    m_ctx->interrupt_callback.callback = interrupt_cb;//--------注册回调函数
    m_ctx->interrupt_callback.opaque = this;

	//设置opts参数
	AVDictionary *fmt_opts = NULL;
	std::string ustimeout = "-1";
	if (timeout > 0)
		ustimeout = std::to_string(timeout * 1000 * 1000); //us -> s
	av_dict_set(&fmt_opts, "stimeout", ustimeout.c_str(), 0);  //设置超时断开连接时间(us)
	av_dict_set(&fmt_opts, "rtsp_transport", "tcp", 0);
	// av_dict_set(&fmt_opts, "rtsp_transport", "udp", 0);

    av_dict_set(&fmt_opts, "buffer_size", "2048000000", 0); //设置缓存大小，1080p可将值调大
    // av_dict_set(&fmt_opts, "buffer_size", "204800", 0); //设置缓存大小，1080p可将值调大
    
	av_dict_set(&fmt_opts, "stimeout", "5000000", 0); //设置超时断开连接时间，单位微秒
    av_dict_set(&fmt_opts, "max_delay", "500000", 0); //设置最大时延

	// 打开输入流时，修改探针probesize的大小
	int BYTES_PER_FRAME = 4497095;
	m_ctx->probesize = BYTES_PER_FRAME * 8;
	// m_ctx->pb = avio;


	long lStartCon = getCurrentTime();
	ANNIWOLOGF(INFO, "m_camId%d connect begin: %s\n", m_camId, rtsp_addr.c_str());
	mlasttime=time(NULL);
	int err = avformat_open_input(&m_ctx, rtsp_addr.c_str(), NULL, &fmt_opts);
	ANNIWOLOGF(INFO, "m_camId:%d spendtime %ld ms\n", m_camId, getCurrentTime() - lStartCon);
	// ANNIWOLOGF(INFO, "Debug:here0\n");

	if (err < 0)
	{
		ANNIWOLOGF(INFO, "m_camId:%d err < 0: %s\n", m_camId, rtsp_addr.c_str());
		avformat_close_input(&m_ctx);
		avformat_free_context(m_ctx);
		av_dict_free(&fmt_opts);
		return OPEN_RTSP_ERROR;
	}

	ANNIWOLOGF(INFO, "m_camId:%d find_stream begin\n", m_camId);
	mlasttime=time(NULL);
	err = avformat_find_stream_info(m_ctx, NULL);
	ANNIWOLOGF(INFO, "m_camId:%d find_stream end: ret %d\n",m_camId, err);
	

	if (err < 0)
	{
		ANNIWOLOGF(INFO, "m_camId:%d  avformat_find_stream_info err < 0: %s\n", m_camId, rtsp_addr.c_str());
		avformat_close_input(&m_ctx);
		avformat_free_context(m_ctx);
		av_dict_free(&fmt_opts);
		return RTSP_STREAM_ERROR;
	}
	// ANNIWOLOGF(INFO, "Debug:here3\n");

	// Dump information about file onto standard error
    // av_dump_format(m_ctx, 0, rtsp_addr.c_str(), 0);

	//选出分辨率最大的的video stream
	bool has_video_stream = false;
	int max_video_resolution = 0;

	// AVCodecContext *codec_ctx_fromstream=NULL;

	for (unsigned int i = 0; i < m_ctx->nb_streams; i++)
	{
		AVStream *st = m_ctx->streams[i];
		if(!st->codecpar)
		{
			ANNIWOLOGF(INFO, "m_camId:%d Info::st->codecpar is NULL!!!!!: %s\n", m_camId, rtsp_addr.c_str());
			continue;
		}
		
		if (st->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
		{
			ANNIWOLOGF(INFO, "m_camId:%d Info::found code type video: %s\n",m_camId, rtsp_addr.c_str());

			if ((st->disposition & AV_DISPOSITION_ATTACHED_PIC) &&
					(st->discard < AVDISCARD_ALL))
			{
				//audio cover stream
			}
			else
			{
				int resolution = st->codecpar->width * st->codecpar->height;
				if (resolution > max_video_resolution &&
						st->codecpar->codec_id != AV_CODEC_ID_NONE)
				{
					has_video_stream = true;
					max_video_resolution = resolution;
					m_video_stream_id = i;

					// codec_ctx_fromstream = stream->codec;

				}
			}
		}
	}

	//若没有video_stream, 返回错误
	if (!has_video_stream)
	{
		ANNIWOLOGF(INFO, "m_camId:%d open:NO video stream found!!!  %s\n",m_camId,  rtsp_addr.c_str());
		av_dict_free(&fmt_opts);
		avformat_close_input(&m_ctx);
		avformat_free_context(m_ctx);
		return RTSP_NO_VIDEO_STREAM_ERROR;
	}

	ANNIWOLOGF(INFO, "m_camId:%d open %ld ms %s\n", m_camId, getCurrentTime() - lStart, rtsp_addr.c_str());
	m_bOpened = true;
	return NO_ERROR;
}


int VideoDecode::Open(const std::string rtsp_addr, int rtsp_id, int timeout /*= 3*/)
{
	m_strRtsp = rtsp_addr;
	m_intRtspId = rtsp_id;
	m_nOpenTimeOut = timeout;

	m_bdetailed_debug = false; 
	m_camId=m_intRtspId;

	return this->rtsp_open(rtsp_addr, timeout);
}

void VideoDecode::SetMode(DECODE_MODE eMode)
{
	m_eDecodeMode = eMode;
	return;
}

int VideoDecode::DecodeThreadBegin(__pDataCallBack data_func, RETURN_DATA_TYPE eType /*= RGB*/)
{
	if (!m_bOpened)
		return RTSP_NO_OPEN;

	m_data_cbfunc = data_func;
	m_e_data_type = eType;
	m_bDecodeRunning = true;
	if (m_trdDecode.joinable())		//已经创建该线程
		return DECODE_THREAD_EXIST;

	m_bdetailed_debug = false; 
	m_camId=m_intRtspId;

	m_trdDecode = std::thread(DecodeThreadFunc, this);

	return NO_ERROR;
}

bool VideoDecode::Close()
{
	m_bDecodeRunning = false;
	m_bOpened = false;

    int nowMinute=getCurMinuteDaytimeXB();

	if(nowMinute>tidyuptimeS && nowMinute<tidyuptimeE)
	{
		if(m_bdetailed_debug)//已经做过设置
		{
			//do nothing
		}else
		{
			//需要做重清并设置标志
			m_bdetailed_debug = true; 
			m_camId=m_intRtspId;
		}
	}


	ANNIWOLOGF(INFO, "%s VideoDecode Close entered.%d\n",timetoStr().c_str(),m_intRtspId);

	packet_queue_abort(&videoq);
	ANNIWOLOGF(INFO, "%s VideoDecode queue abort ok.%d\n",timetoStr().c_str(),m_intRtspId);

    packet_queue_flush(&videoq);
	ANNIWOLOGF(INFO, "%s VideoDecode queue flush ok.%d\n",timetoStr().c_str(),m_intRtspId);

	/* wait 10 ms */
	SelectuSleep(20 * 1000);


	if (m_trdContinueReadRtsp.joinable())		//读取线程
	{
		m_bDecodeRunning = false;

		packet_queue_abort(&videoq);
	    packet_queue_flush(&videoq);

		ANNIWOLOGF(INFO, "%s VideoDecode joining read thread %d\n",timetoStr().c_str(),m_intRtspId);
		m_trdContinueReadRtsp.join();
		ANNIWOLOGF(INFO, "%s VideoDecode joined read thread ok %d\n",timetoStr().c_str(),m_intRtspId);

	}

	if (m_trdDecode.joinable())		//解码线程,因为其有free context操作
	{
		m_bDecodeRunning = false;
		packet_queue_abort(&videoq);
    	packet_queue_flush(&videoq);

		ANNIWOLOGF(INFO, "%s VideoDecode joining decode thread %d\n",timetoStr().c_str(),m_intRtspId);
		m_trdDecode.join();
		ANNIWOLOGF(INFO, "%s VideoDecode joined decode thread ok %d\n",timetoStr().c_str(),m_intRtspId);


	}



	

	//必须两个线程成功停止之后才能销毁，因内部有mutex和cond
	packet_queue_destroy(&videoq);
	ANNIWOLOGF(INFO, "%s VideoDecode queue destroy ok %d\n",timetoStr().c_str(),m_intRtspId);



	//释放内存
	avformat_close_input(&m_ctx);
	avformat_free_context(m_ctx);

    


	return true;
}

