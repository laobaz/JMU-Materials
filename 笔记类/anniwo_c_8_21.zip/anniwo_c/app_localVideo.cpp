#include "crow_all.h"


#include "core/personbase/basePerson.hpp"
#include "core/safeErea/safeArea.hpp"
#include "core/window/window.hpp"
#include "core/smoke/SmokePhone.hpp"
#include "core/firesmog/firesmog.hpp"
#include "core/helmet/helmet.hpp"
#include "core/xunjian/xunjian.hpp"
#include "core/uptruck/uptruck.hpp"
#include "core/zhuangxieyou/zhuangxieyou.hpp"

#ifdef __aarch64__   
#else
    #include "core/convery/convery.hpp"
#endif

#include "core/chepai/chepai.hpp"
#include "core/mask/Mask.hpp"


#include "core/common/yolo/yolo_common.hpp"


#include "framing/Rectangle.h"
#include "core/utils/utils_intersection.hpp"

#include "core/utils/utils_intersection.hpp"
#include "core/utils/rapidjson/document.h"
#include "core/utils/rapidjson/writer.h"
#include "core/utils/rapidjson/stringbuffer.h"
#include "core/utils/cycrptUtil.hpp"
#include "core/utils/subUtils.hpp"
#include "core/utils/ini.h"



#include "ThreadPool.h"



#include <iostream>
#include <thread>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>  
#include <string>  
#include <sstream>  

#include <unordered_set>
#include <unordered_map>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>


const std::string VERSION=std::string(__DATE__)+std::string(" ")+std::string(__TIME__);

    bool isVideoEnd5=false;
    bool isVideoEnd23=false;
    bool isVideoEnd64=false;

std::mutex mtx4GlobalVariables;
std::mutex mtx4SubmitThread; //Notice:submitThread只能单线程执行，多线程需要上锁。


bool istodoInitTracks=false; //engineStart时候需要重新初始化
bool isFirstimeInitFramer=true;//首次初始化framer
bool tidayUpNow=false;//凌晨整理时间到了,看现在是否做重清 
bool tidiedOnce=false; //控制不重复做凌晨整理

std::vector<std::string> rtmpStrs;
std::vector<int> rtmpIds;



safeEreaDetection* safeEreaDetect = NULL;
WindowDetection* windowDetect = NULL;
FireDetection* fireDetect = NULL;
HelmetDetection* helmetDetect = NULL;

SmokePhoneDetection* smokePhoneDetect = NULL;

#ifdef __aarch64__
void* converyDetect = NULL;
#else
ConveryDetection* converyDetect = NULL;
#endif

BasePersonDetection* basePersonDetect = NULL;

XunjianDetection* xunjianDetect = NULL;
ZxyDetection* zxyDetect = NULL;
ChepaiDetection* chepaiDetect = NULL;
MaskDetection* maskDetect = NULL;
UptruckDetection* uptruckDetect= NULL;




static std::unordered_set<std::string> person_base_functions={"safeErea" ,"helmet" ,"phone" ,"smoke" , "convery", "chepai","mask","uptruck"};
const static std::unordered_set<std::string> all_conf_functions = { "fire","smoke","helmet","safeErea","window","convery","uptruck","phone", "xunjian",
                                                                    "absence","zhuangxieyou","face","chepai","mask"};



ThreadPool *pool=nullptr;
ThreadPool *poolpersonbase=nullptr;


//map(map)不能直接初始化
std::unordered_map<std::string,std::unordered_map<int, std::future<void>>  > tasks;

std::unordered_map<int, std::future<void>>  pGroupTasks;


/////////////////////json 配置信息///////////////////////////////////////////////////////

static ANNIWO_JSON_CONF_CLASS globalJsonConfObj;
static ANNIWO_JSON_CONF_CLASS globalJsonConfObjNotApplied;

//////////ini 配置信息
struct ANNIWO_INI_CONF_CLASS globalINICONFObj;

static std::string currentInJsonAll;

/////////////////////配置信息结束///////////////////////////////////////////////////////






std::thread* threadDetect=NULL;

static const int tidyuptimeS= 1438; //23:58
static const int tidyuptimeE= 1440; //24:00
static int log_suffix_cnt=1;

class ExampleLogHandler : public crow::ILogHandler {
    public:
        void log(std::string /*message*/, crow::LogLevel /*level*/) override {
//            cerr << "ExampleLogHandler -> " << message;
        }
};

struct ExampleMiddleware 
{
    std::string message;

    ExampleMiddleware() 
    {
        message = "foo";
    }

    void setMessage(std::string newMsg)
    {
        message = newMsg;
    }

    struct context
    {
    };

    void before_handle(crow::request& /*req*/, crow::response& /*res*/, context& /*ctx*/)
    {
        CROW_LOG_DEBUG << " - MESSAGE: " << message;
    }

    void after_handle(crow::request& /*req*/, crow::response& /*res*/, context& /*ctx*/)
    {
        // no-op

    }
};




class PERSONBASE_DET {
public:
        PERSONBASE_DET(const std::unordered_map<int, std::vector<std::string> >& id_func_mapIn, const std::unordered_set<std::string>&  person_base_functionsIn)
        :id_func_map(id_func_mapIn),mPerson_base_functions(person_base_functionsIn)
        {
            
            for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) {
                int camId= iter->first ;
                for(auto& f : iter->second)
                {
                    std::unordered_set<std::string>::const_iterator got_person_base_functions = this->mPerson_base_functions.find(f);

                    if (got_person_base_functions == this->mPerson_base_functions.end())
                    {
                        continue;
                    }
                    else
                    {
                        objCntArray.insert(std::pair<int, int >(camId,-1) );
                        std::vector<Object> results;
                        det_results.insert(std::pair<int, std::vector<Object> >(camId,results)) ;

                        break;
                    }
                }
            }
        }

        //多线程调用
        void do_detect(int camId, int instanceID, cv::Mat img)  {
            if(objCntArray[camId] == -1)
            {
                det_results[camId].clear();
                objCntArray[camId] = 0;
                //针对一个摄像头进行预检测，检测人.检测结果送入各个相关功能后续检测。
                //do person detection
                ANNIWOLOG(INFO) <<"PERSONBASE_DET:do person base detection.camId: "<<camId ;
                objCntArray[camId]  = basePersonDetect->detect( camId,instanceID,img,this->det_results[camId] );
                ANNIWOLOG(INFO) <<"PERSONBASE_DET:do person base detection exited.camId: "<<camId ;

            }
    }

    bool hasperson(int camId) {return objCntArray[camId] >= 0; }
    void clearResults(int camId) 
    {
        std::unordered_map<int, std::vector<Object> >::iterator got_det = this->det_results.find(camId);

        if (got_det == this->det_results.end())
        {
            return;
        }
        else
        {
            got_det->second.clear();
            std::unordered_map<int, int>::iterator got_ObjCnt = this->objCntArray.find(camId);
            if (got_ObjCnt == this->objCntArray.end())
            {
                ANNIWOLOG(INFO) <<"PERSONBASE_DET:FATAL!!!! NOT IN objCntArray "<<camId;
                return;
            }else
            {
                got_ObjCnt->second=-1;
            }

        }

    }

    const std::unordered_set<std::string>&  mPerson_base_functions;
    const std::unordered_map<int, std::vector<std::string> >& id_func_map;

    std::unordered_map<int, std::vector<Object> > det_results ;
    std::unordered_map<int, int> objCntArray ;

};
static PERSONBASE_DET* personbase_detObjPtr=nullptr;


inline void resetIntervalRecord(const std::string& f, int camId)
{
        //时间间隔记录
    //camId,{func,interval}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoTimeLog >  >::iterator got_intervalIter =  globalJsonConfObj.interval_conf_map.find(camId);
    if (got_intervalIter == globalJsonConfObj.interval_conf_map.end())
    {
        ANNIWOLOG(INFO) << "resetIntervalRecord:not found in interval_conf_map,camId:" <<camId;
    }
    else
    {
        std::unordered_map<std::string, AnniwoTimeLog >& intervalFuncMap  = got_intervalIter->second;
        std::unordered_map<std::string, AnniwoTimeLog >::iterator gotIntervalFuncMapIter = intervalFuncMap.find(f);
        if (gotIntervalFuncMapIter == intervalFuncMap.end())
        {
            ANNIWOLOG(INFO) << "resetIntervalRecord:not found in intervalFuncMap,camId:" <<camId<<" func:"<<f;
        }
        else
        {
            AnniwoTimeLog& vecValues =  gotIntervalFuncMapIter->second;
            const double confInterval = vecValues.configInterval;
            auto& prevTP = vecValues.lastTP;


			prevTP=std::chrono::steady_clock::time_point{}; //设置为最小时间，下次必然到期保证被提交
            ANNIWOLOG(INFO) << "resetIntervalRecord - camId:" <<camId<<" func:"<<f;

        }
    }
}

inline bool isTimeIntervalOK(const std::string& f, int camId,bool bRecord=true)
{
    //进行时间段判断
    //valid peroids_hour_map 
    //valid peroids_week_map
    //camId,{func,Vector<Polygon>}
    //camId,{func,Vector<std::string>}
    // std::unordered_map<int,std::unordered_map<std::string, std::vector<std::string>>  >  validperoids_week_map;
    // std::unordered_map<int,std::unordered_map<std::string, std::vector<Polygon>>  >  validperoids_hour_map;
    std::unordered_map<int,std::unordered_map<std::string, std::vector<std::string> >  >::iterator got_intervalIterWM =  globalJsonConfObj.validperoids_week_map.find(camId);
    if (got_intervalIterWM == globalJsonConfObj.validperoids_week_map.end())
    {
        ANNIWOLOG(INFO) << "not found in validperoids_week_map,camId:" <<camId;
    }
    else
    {
        std::unordered_map<std::string, std::vector<std::string> >& intervalFuncMap  = got_intervalIterWM->second;
        std::unordered_map<std::string, std::vector<std::string> >::iterator gotIntervalFuncMapIter = intervalFuncMap.find(f);
        if (gotIntervalFuncMapIter == intervalFuncMap.end())
        {
            ANNIWOLOG(INFO) << "not found in validperoids_week_map,camId:" <<camId<<" func:"<<f;
        }
        else
        {
            bool isInCurWeek=false;
            int curWeek = getCurWeekDayXB();
            int weekDayArrIndex=0;

            std::vector<std::string>& vecValues =  gotIntervalFuncMapIter->second;
            for(auto& sstr:vecValues )
            {
                int iweek = sstr[0] - '0';

                if(curWeek == iweek)
                {
                    isInCurWeek=true;
                    weekDayArrIndex++;
                    break;
                }else
                {
                    weekDayArrIndex++;
                    continue;
                }
            }
            weekDayArrIndex-=1;//超了1.

            std::stringstream buffer;  
            for(int i=0; i < vecValues.size(); i++)
            {
                const std::string& pt=vecValues[i];
                buffer << pt<<" ";  
            }
            std::string vecValuestr(buffer.str());

            if(isInCurWeek)
            {


                ANNIWOLOG(INFO) << "It is in validperoids_week_map,camId:" <<camId<<" func:"<<f<<"curweek:"<<curWeek<<"configweek:"<<vecValuestr<<std::endl;

    
                std::unordered_map<int,std::unordered_map<std::string, std::vector<Polygon>> >::iterator got_intervalIter =  globalJsonConfObj.validperoids_hour_map.find(camId);
                if (got_intervalIter == globalJsonConfObj.validperoids_hour_map.end())
                {
                    ANNIWOLOG(INFO) << "not found in validperoids_hour_map,camId:" <<camId;
                }
                else
                {
                    std::unordered_map<std::string, std::vector<Polygon>>& intervalFuncMap  = got_intervalIter->second;
                    std::unordered_map<std::string, std::vector<Polygon>>::iterator gotIntervalFuncMapIter = intervalFuncMap.find(f);
                    if (gotIntervalFuncMapIter == intervalFuncMap.end())
                    {
                        ANNIWOLOG(INFO) << "not found in validperoids_hour_map,camId:" <<camId<<" func:"<<f;
                    }
                    else
                    {
                        bool isValidPeriod=false;
                        int curDayTime=getCurMinuteDaytimeXB();

                        std::vector<Polygon>& hourvecValues =  gotIntervalFuncMapIter->second;
                        //注意，与week设置有对应关系.
                        Polygon configHours= hourvecValues[weekDayArrIndex];
                        for(int i=0; i < configHours.size(); i++)
                        {
                            const cv::Point& pt=configHours.pt[i];
                            //start time;end time
                            if(curDayTime >= pt.x && curDayTime < pt.y)
                            {
                                ANNIWOLOG(INFO) << "It is in validperoids_hour_map,camId:" <<camId<<" func:"<<f<<"curDaytime:"<<curDayTime<<"configDaytime:"<<pt.x<<","<<pt.y<<std::endl;  
                                isValidPeriod=true;
                                break;
                            }else
                            {
                                continue;
                            }
                        }
                        if(!isValidPeriod)
                        {

                            std::stringstream buffer;  
                            for(int i=0; i < configHours.size(); i++)
                            {
                                const cv::Point& pt=configHours.pt[i];
                                buffer << pt.x<<","<<pt.y<<" ";  
                            }
                            std::string text(buffer.str());

                            ANNIWOLOG(INFO) << "It is NOT in validperoids_hour_map,camId:" <<camId<<" func:"<<f<<"curDaytime:"<<curDayTime<<"configDaytime:"<<text<<std::endl;  
                            return false;
                        }
                        

                    }
                }
            }else
            {
                ANNIWOLOG(INFO) << "not in validperoids_week_map,camId:" <<camId<<" func:"<<f<<"curweek:"<<curWeek<<"configweek:"<<vecValuestr<<std::endl;
            }


        }
    }




    //进行时间间隔判断
    //camId,{func,interval}
    auto postprocess_start = std::chrono::steady_clock::now();
    std::unordered_map<int,std::unordered_map<std::string, AnniwoTimeLog >  >::iterator got_intervalIter =  globalJsonConfObj.interval_conf_map.find(camId);
    if (got_intervalIter == globalJsonConfObj.interval_conf_map.end())
    {
        ANNIWOLOG(INFO) << "not found in interval_conf_map,camId:" <<camId;
    }
    else
    {
        std::unordered_map<std::string, AnniwoTimeLog >& intervalFuncMap  = got_intervalIter->second;
        std::unordered_map<std::string, AnniwoTimeLog >::iterator gotIntervalFuncMapIter = intervalFuncMap.find(f);
        if (gotIntervalFuncMapIter == intervalFuncMap.end())
        {
            ANNIWOLOG(INFO) << "not found in intervalFuncMap,camId:" <<camId<<" func:"<<f;
        }
        else
        {
            AnniwoTimeLog& vecValues =  gotIntervalFuncMapIter->second;
            const double confInterval = vecValues.configInterval;
            auto& prevTP = vecValues.lastTP;

            auto postprocess_end = std::chrono::steady_clock::now();
            std::chrono::duration<float> postprocess_diff = postprocess_end - prevTP;

            double intervalCnter = confInterval - static_cast<double>(postprocess_diff.count() * 1000); //ms

            if(intervalCnter <= 0.0)
            {
                ANNIWOLOG(INFO) << "Interval OK. camId:" <<camId<<"func:"<<f<<" interval:"<< intervalCnter ;
                if(bRecord)
                {
                    prevTP=std::chrono::steady_clock::now();
                }
            }else
            {
                ANNIWOLOG(INFO) << "IGNORE camId:" <<camId<<"func:"<<f<<" because interval:"<< intervalCnter ;
                return false;
            }

        }
    }
    
    return true;
}

//return:
//true: submit success
//false: submit failed
static bool submitThread(const std::string& f, int camId, cv::Mat img, PERSONBASE_DET& personbaseDetObj)
{
    bool submitSuccess=false;
    if(istodoInitTracks)
    {
        ANNIWOLOG(INFO) <<"submitThread: istodoInitTracks is true. Abort...";
        return submitSuccess;
    }

    std::unique_lock<std::mutex> uniqueLockSubmit(mtx4SubmitThread, std::defer_lock);
    ANNIWOLOG(INFO) <<"submitThread: waiting lock...";

    uniqueLockSubmit.lock();
    ANNIWOLOG(INFO) <<"submitThread: get into uniqueLock OK";

    //取得有效区域
    const Polygon* polygonSafeArea_ptr={nullptr};

    std::unordered_map<int,std::unordered_map<std::string, Polygon>  >::iterator got_id_func_cap = globalJsonConfObj.validArea_conf_map.find(camId);

    if (got_id_func_cap == globalJsonConfObj.validArea_conf_map.end())
    {
        ANNIWOLOG(INFO) << "not found in validArea_conf_map,camId:" <<camId;
    }
    else
    {
        std::unordered_map<std::string, Polygon>& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, Polygon>::iterator got_id_func_cap2 = conf_map.find(f);
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "not found in validArea_conf_map,camId:" <<camId<<"func:"<<f;
        }
        else
        {
            const Polygon& polygonSafeArea = got_id_func_cap2->second;
            polygonSafeArea_ptr=&polygonSafeArea;
        }
    }

    if(f  == std::string("safeErea" ))
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> safeEreaTasks;
        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  safeEreaTasks.find(tmpInstanceId);
            if (perCamTask == safeEreaTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in safeEreaTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for safeErea  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_SAFEAREA;
            ANNIWOLOG(INFO) <<"use this isntance: for safeErea  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  safeEreaTasks.find(instanceCnt);
        if (perCamTask == safeEreaTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for safeErea when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(safeEreaDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);     

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            safeEreaTasks.insert(std::move(taskpair));
            submitSuccess=true;

        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for safeErea camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(safeEreaDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);     

            perCamTask->second=std::move(futr);
            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: safeErea group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }
        
        ANNIWOLOG(INFO) <<"submited thread: end safeErea group camId: "<<camId<<" instanceID:"<<instanceCnt;


    }
    else if(f ==  std::string("helmet"))
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> helmetTasks;

        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  helmetTasks.find(tmpInstanceId);
            if (perCamTask == helmetTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in helmetTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for helmet  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_HELMET;
            ANNIWOLOG(INFO) <<"use this isntance: for helmet  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }


        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  helmetTasks.find(instanceCnt);
        if (perCamTask == helmetTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for helmet when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(helmetDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);     

            ANNIWOLOG(INFO) <<"submited thread: for helmet when no this instanceID:"<<instanceCnt<<" camId:"<<camId;


            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            helmetTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for helmet camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(helmetDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);     

            ANNIWOLOG(INFO) <<"submited thread: for helmet when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            submitSuccess=false;

            ANNIWOLOG(INFO) <<"DISCARD img for: helmet group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
        }
        
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end helmet group camId: "<<camId<<" instanceID:"<<instanceCnt;

    }
    
    #ifdef __aarch64__
    #else	
    else if(f ==  std::string("convery"))
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> converyTasks;

        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
    
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  converyTasks.find(tmpInstanceId);
            if (perCamTask == converyTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in converyTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for convery  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_CONVERY;
            ANNIWOLOG(INFO) <<"use this isntance: for convery  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  converyTasks.find(instanceCnt);
        if (perCamTask == converyTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for convery when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(converyDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            converyTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for convery camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(converyDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: convery group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }


    }
    #endif
    
    else if(f  == std::string("uptruck"))
    {
        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> UptruckTasks;

        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  UptruckTasks.find(tmpInstanceId);
            if (perCamTask == UptruckTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in UptruckTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for uptruck  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_UPTRUCK;
            ANNIWOLOG(INFO) <<"use this isntance: for uptruck  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }


        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  UptruckTasks.find(instanceCnt);
        if (perCamTask == UptruckTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for uptruck when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(uptruckDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            UptruckTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for uptruck camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(uptruckDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: uptruck group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end uptruck group camId: "<<camId<<" instanceID:"<<instanceCnt;


    }
    else if(f  == std::string("window"))
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> windowTasks;

        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  windowTasks.find(tmpInstanceId);
            if (perCamTask == windowTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in windowTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for window  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_WINDOW;
            ANNIWOLOG(INFO) <<"use this isntance: for window  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }


        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  windowTasks.find(instanceCnt);
        if (perCamTask == windowTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for window when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(windowDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            windowTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for window camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(windowDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: window group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end window group camId: "<<camId<<" instanceID:"<<instanceCnt;

    }
    else if (f ==  std::string("fire"))
    {
        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> fireTasks;

        bool useExistingInstance=false;

        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  fireTasks.find(tmpInstanceId);
            if (perCamTask == fireTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in fireTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for fire  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_FIRE;
            ANNIWOLOG(INFO) <<"use this isntance: for fire  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        std::unordered_map<int, std::future<void>>::iterator perCamTask =  fireTasks.find(instanceCnt);
        if (perCamTask == fireTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for fire when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(fireDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            fireTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for fire camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(fireDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      
    

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: fire group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end fire group camId: "<<camId<<" instanceID:"<<instanceCnt;

        
    }
    else if (f ==  std::string("xunjian"))
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> xunjianTasks;

        bool useExistingInstance=false;

        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  xunjianTasks.find(tmpInstanceId);
            if (perCamTask == xunjianTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in xunjianTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for xunjian  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN;
            ANNIWOLOG(INFO) <<"use this isntance: for xunjian  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        std::unordered_map<int, std::future<void>>::iterator perCamTask =  xunjianTasks.find(instanceCnt);
        if (perCamTask == xunjianTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for xunjian when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(xunjianDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            xunjianTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for xunjian camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(xunjianDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      
    

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: xunjian group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end xunjian group camId: "<<camId<<" instanceID:"<<instanceCnt;
        
    }
    else if (f ==  std::string("zhuangxieyou"))
    {
        
        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> zhuangxieyouTasks;

        bool useExistingInstance=false;

        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  zhuangxieyouTasks.find(tmpInstanceId);
            if (perCamTask == zhuangxieyouTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in zhuangxieyouTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for zhuangxieyou  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_ZXY;
            ANNIWOLOG(INFO) <<"use this isntance: for zhuangxieyou  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        std::unordered_map<int, std::future<void>>::iterator perCamTask =  zhuangxieyouTasks.find(instanceCnt);
        if (perCamTask == zhuangxieyouTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for zhuangxieyou when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(zxyDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            zhuangxieyouTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for zhuangxieyou camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(zxyDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr);      
    

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: zhuangxieyou group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end zhuangxieyou group camId: "<<camId<<" instanceID:"<<instanceCnt;
        
        
    }
    else if (f ==  std::string("chepai"))
    {
        
        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> chepaiTasks;

        bool useExistingInstance=false;

        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  chepaiTasks.find(tmpInstanceId);
            if (perCamTask == chepaiTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in chepaiTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for chepai  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI;
            ANNIWOLOG(INFO) <<"use this isntance: for chepai  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        std::unordered_map<int, std::future<void>>::iterator perCamTask =  chepaiTasks.find(instanceCnt);
        if (perCamTask == chepaiTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for chepai when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(chepaiDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            chepaiTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for chepai camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(chepaiDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      
    

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: chepai group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }
        
        ANNIWOLOG(INFO) <<"submited thread: end chepai group camId: "<<camId<<" instanceID:"<<instanceCnt;

        
    }
    else if (f ==  std::string("mask"))
    {   
        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> maskTasks;

        bool useExistingInstance=false;

        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  maskTasks.find(tmpInstanceId);
            if (perCamTask == maskTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in maskTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for mask  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_MASK;
            ANNIWOLOG(INFO) <<"use this isntance: for mask  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }



        std::unordered_map<int, std::future<void>>::iterator perCamTask =  maskTasks.find(instanceCnt);
        if (perCamTask == maskTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for mask when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(maskDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            maskTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for mask camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(maskDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);      
    

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: mask group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;

            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }
        
        ANNIWOLOG(INFO) <<"submited thread: end mask group camId: "<<camId<<" instanceID:"<<instanceCnt;

        
    }
    else if( f ==  std::string("smoke") || f ==  std::string("phone") )
    {

        static int instanceCnt=0;
        //camId, instanceId
        static std::unordered_map<int, int> busyCamIdInstanceMap;
        static std::unordered_map<int, std::future<void>> smokephoneTasks;

        bool useExistingInstance=false;


        std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
        if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
        {
            int tmpInstanceId=iterCamInstanceId->second;
            
            std::unordered_map<int, std::future<void>>::iterator perCamTask =  smokephoneTasks.find(tmpInstanceId);
            if (perCamTask == smokephoneTasks.end())
            {
                ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in smokephone:"<<iterCamInstanceId->second<<" camId:"<<camId;
                busyCamIdInstanceMap.erase(camId);

            }else
            {
                useExistingInstance=true;
                instanceCnt=iterCamInstanceId->second;

                ANNIWOLOG(INFO) <<"use existing isntance: for smokephone  instanceID:"<<instanceCnt<<" camId:"<<camId;

            }


        }else
        {
            instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_SMOKEPHONE;
            ANNIWOLOG(INFO) <<"use this isntance: for smokephone  instanceID:"<<instanceCnt<<" camId:"<<camId;

        }




        
        std::unordered_map<int, std::future<void>>::iterator perCamTask =  smokephoneTasks.find(instanceCnt);
        if (perCamTask == smokephoneTasks.end())
        {
            ANNIWOLOG(INFO) <<"submiting thread: for smokephone when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

            std::future<void> futr=pool->enqueue(smokePhoneDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);           

            std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(futr));
            smokephoneTasks.insert(std::move(taskpair));

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;


        }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
        {
            ANNIWOLOG(INFO) <<"submiting thread: for smokephone camId:"<<camId<<" instanceID:"<<instanceCnt;
            std::future<void> futr=pool->enqueue(smokePhoneDetect->detect,camId,instanceCnt,img,polygonSafeArea_ptr,personbaseDetObj.det_results[camId]);           

            perCamTask->second=std::move(futr);

            //更新busymap
            int previousCamId=-1;
            for(auto& item:busyCamIdInstanceMap)
            {
                if(item.second == instanceCnt)
                {
                    previousCamId=item.first;
                    break;
                }
            }
            if(previousCamId != -1)
            {
                busyCamIdInstanceMap.erase(previousCamId);
            }
            std::pair<int, int> tmpitem(camId,instanceCnt);
            busyCamIdInstanceMap.insert(std::move(tmpitem));

            submitSuccess=true;

        }
        else
        {
            ANNIWOLOG(INFO) <<"DISCARD img for: smokephone group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
            submitSuccess=false;

        }
        if(!useExistingInstance)
        {
            instanceCnt++;
        }

        ANNIWOLOG(INFO) <<"submited thread: end smokephone group camId: "<<camId<<" instanceID:"<<instanceCnt;


    }
    else 
    {
        ANNIWOLOG(INFO) <<f<<" is NOT the expect  function!"<<std::endl;
    }
    
    uniqueLockSubmit.unlock();
    return submitSuccess;

}



static void personbaseGroupFunc(const std::vector<std::string> infunctions, int camId, int instanceID, cv::Mat img )
{
    PERSONBASE_DET& persondetObj=*personbase_detObjPtr;
    //clear camId base person det result buffer
    persondetObj.clearResults(camId);

    if(istodoInitTracks)
    {
        ANNIWOLOG(INFO) <<"personbaseGroupFunc: istodoInitTracks is true. Abort...";
        return;
    }
    persondetObj.do_detect(camId,instanceID,img);
    
    if(istodoInitTracks)
    {
        ANNIWOLOG(INFO) <<"personbaseGroupFunc: istodoInitTracks is true. Abort...";
        return;

    }

    if(persondetObj.hasperson(camId))
    {
        std::stringstream buffer;  
        for(int i=0; i < infunctions.size(); i++)
        {
            const std::string& pt=infunctions[i];
            buffer << pt<<" ";  
        }
        std::string vecValuestr(buffer.str());
        ANNIWOLOG(INFO) <<" personbaseGroupFunc infunctions:"<<vecValuestr<<",camId"<<camId;


        for(const std::string& f:infunctions)
        {
            if(istodoInitTracks)
            {
                ANNIWOLOG(INFO) <<"personbaseGroupFunc: istodoInitTracks is true. Abort...";
                return;

            }
            submitThread(f, camId, img,persondetObj);

        }
        ANNIWOLOG(INFO) <<"personbaseGroupFunc: exit...";

    
    }
}




void initAllTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj)
{
    if(safeEreaDetect)
    {
        safeEreaDetect->initTracks(globalJsonConfObj);

    }
    if(windowDetect)
    {
        windowDetect->initTracks(globalJsonConfObj);

    }

    if(uptruckDetect)
    {
        uptruckDetect->initTracks(globalJsonConfObj);

    }

    if(fireDetect)
    {
        fireDetect->initTracks(globalJsonConfObj);

    }
    if(helmetDetect)
    {
        helmetDetect->initTracks(globalJsonConfObj);

    }
    if(smokePhoneDetect)
    {
        smokePhoneDetect->initTracks(globalJsonConfObj);
    }
    // if(converyDetect)
    // {
    //     #ifdef __aarch64__
    //         ANNIWOCHECK(false);
    //     #else
    //         converyDetect->initTracks(globalJsonConfObj);
    //     #endif
    // }
    if(xunjianDetect)
    {
        xunjianDetect->initTracks(globalJsonConfObj);
    }
    if(zxyDetect)
    {
        zxyDetect->initTracks(globalJsonConfObj);
    }
    if(chepaiDetect)
    {
        chepaiDetect->initTracks(globalJsonConfObj);
    }
    if(maskDetect)
    {
        maskDetect->initTracks(globalJsonConfObj);
    }
}

//todo:absence是否提交逻辑可以写在这里
inline bool isRequireSubmitThread(const std::unordered_set<std::string>& perCamsubmittedfuncs, const std::string& f, int camId)
{

    if(f == std::string("smoke") || f == std::string("phone"))
    {
        if(  ( perCamsubmittedfuncs.find("smoke") != perCamsubmittedfuncs.end() ) || ( perCamsubmittedfuncs.find("phone") != perCamsubmittedfuncs.end() )  )
        {
            return false;
        } 
    }

    if(!isTimeIntervalOK(f,  camId))
    {
        ANNIWOLOG(INFO) <<"f is not time OK.ignore "<<f<<" camId:"<<camId;
        return false;
    }

    return true;
}


void* detectFunc(void* param)
{

    shapes::Rectangle videogpuObj;


    for (auto& f : globalINICONFObj.in_use_conf_functions)
    {
        if(f == std::string("fire"))
        {
            fireDetect = new FireDetection(globalINICONFObj.onlineCollectionPath);
        }
        if( f == std::string("smoke") || f == std::string("phone") )
        {
            if(!smokePhoneDetect)
            {
                smokePhoneDetect = new SmokePhoneDetection();
            }
            
        }
        if(f == std::string("helmet") )
        {
	        helmetDetect = new HelmetDetection();
            
        }
        if(f == std::string("safeErea"))
        {
            safeEreaDetect = new safeEreaDetection();
            
        }
        if(f == std::string("window"))
        {
            windowDetect = new WindowDetection();
        }
        if(f == std::string("convery"))
        {
            #ifdef __aarch64__
                ANNIWOCHECK(false);
            #else
                converyDetect = new ConveryDetection();
            #endif

        }
        if(f == std::string("uptruck"))
        {
            uptruckDetect = new UptruckDetection();
        }
        if(f == std::string("xunjian"))
        {
            xunjianDetect = new XunjianDetection();
        }
        if(f == std::string("zhuangxieyou"))
        {
            zxyDetect = new ZxyDetection();
        }
        if(f == std::string("chepai"))
        {
            chepaiDetect = new ChepaiDetection();
        }

        if(f == std::string("mask"))
        {
            maskDetect = new MaskDetection();
        }
    }


    basePersonDetect = new BasePersonDetection();

    ANNIWOCHECK(pool==nullptr);

    #ifdef __aarch64__
        // pool = new ThreadPool(100);
        pool = new ThreadPool(50);
        // poolpersonbase = new ThreadPool(28);
        poolpersonbase = new ThreadPool(12);
        std::cout<<"arm 64 machine enable! "<<std::endl;
    #else
        //x86_64 server
        pool = new ThreadPool(865);
        poolpersonbase = new ThreadPool(105);
    #endif



    ///////////////////
    //Make local video read frame!
//camId 5
    // std::string inputs = "../videos/64_20220106153913_20220106154337_196544.mp4";//烧纸测试
    // std::string inputs = "../videos/firetest_emb_1.mp4";//侯在机器人公司测试无报警
    // std::string inputs = "../videos/xinjinxieyouqu.mp4";//新津卸油
    // std::string inputs = "../videos/53f03eb2079de082178ec30c1f2e17b6_bwrkj.mp4";//北外人孔井20230210
    // std::string inputs = "../videos/192.168.0.105_ch15_20230221104325_20230221104936_rkj20230221.mp4";//北外人孔井
    // std::string inputs = "../videos/1676266654129_fire.mp4";//

    
    // std::string inputs = "../videos/converytest1.mp4"; //convery
    // std::string inputs = "../videos/xunjian-jiayouji.mp4";
    // std::string inputs = "../videos/NVR_ch3_main_20220510163100_20220510163359.asf";//helmet
    
    // std::string inputs = "../videos/20cf4799ecc4c4c1ddf36394575d527e_jyz_weilan.mp4";//加油站电子围栏
    // std::string inputs = "../videos/20cf4799ecc4c4c1ddf36394575d527e_jyz_weilan.mp4";//加油站电子围栏
    // std::string inputs = "../videos/3c626856852fc4b945f011d07a5c5800_dzwl_notrack.mp4";//加油站电子围栏.夜间，模型问题。

    // std::string inputs = "../videos/NVR_ch11_main_20220925090916_20220925091042-jyj-5.mp4";//jiayouji
    // std::string inputs = "../videos/xunjian-jiayouji.mp4"; //jiayouji
    // std::string inputs = "../videos/zhyxunjian_jyj0.mp4"; //jiayouji

    // std::string inputs = "../videos/10_19_jinzhichepai.mp4"; //静止车牌,ppyoloe没有检测到车牌！！！score:0.4313 需要调,调了又被不清晰干掉了
    // std::string inputs = "../videos/b5c0d358f022d3a6af6baebcdb3f599e-chepai.mp4"; //chepai
    // std::string inputs = "../videos/zhyJiayouji_NVR_ch4_main_20221216100144_20221216100256.mp4"; //中海油兴义加油机
    // std::string inputs = "../videos/192.168.0.204.mp4"; //中海油北外加油机
    // std::string inputs = "../videos/2d78d839253702061db8eb2c0e656075_rkj0109.mp4"; //中海油新津人孔井
    // std::string inputs = "../videos/41e787a101f8c4a2d8f5a99ab5dc22f6_jiayouji.mp4"; //中海油新义，无.


    // std::string inputs = "../videos/99788c47fa0b9ee4459187a0bfb5e54f_jyz_mask.mp4"; //加油站口罩
    // std::string inputs = "../videos/7a86674cf9002abd4abdddebf8626793_0129_wbrkj.mp4";//中海油外北人孔井
    // std::string inputs = "../videos/NVR_ch4_main_2023_rkj.mp4";//新津人孔井漏报、重复
    // std::string inputs = "../videos/192.168.0.202_rkj_waibei.mp4";//人孔井漏报
    // std::string inputs = "../videos/192.168.0.203_beiwai_jyj.mp4";//北外加油机无报警
    // std::string inputs = "../videos/192.168.0.202_xinjinRKJ.mp4";//新津人孔井
    // std::string inputs = "../videos/NVR_ch4_main_20230319150501_20230319151446_rkj_xinjing.mp4";//新津人孔井,3/20
    // std::string inputs = "../videos/192.168.0.202_xinjingAM.mp4";//新津人孔井,3/23
    // std::string inputs = "../videos/1684638900201_IP_192.168.1.65.mp4";//室内小盒子烟火测试
    // std::string inputs = "../videos/1685157845229_IP_192.168.1.65_smoke.mp4";//室内抽烟测试，因face检测不到
    // std::string inputs = "../videos/1686486299391_ip_192.168.1.65.mp4";//打电话测试
    // std::string inputs = "../videos/dadianhua-meiyoubaojing.mp4";//打电话测试
    // std::string inputs = "../videos/10.118.32.136_convery.mp4";//打电话测试
    std::string inputs = "../videos/phontest_1.mp4";//打电话测试

    



//camId 23  -----------
    // std::string inputs2 = "../videos/converytest2.mp4"; //convery

    // std::string inputs2 = "../videos/xunjian-renkongjing2.mp4";
    // std::string inputs2 = "../videos/NVR_ch7_main_20220510164100_20220510165159.asf";//smoke


    // std::string inputs2 = "../videos/renkongjing_xunjian_9_5.mp4";//

    

    
    // std::string inputs2 = "../videos/NVR_ch4_main_20220925083138_20220925084605-rkj-23.mp4"; //rkj
    
    // std::string inputs2 = "../videos/jiayouzhan_jingzhichepai_20221020161316.mp4"; //加油站车牌,是太模糊被过滤掉了
    // std::string inputs2 = "../videos/67afefabd15d2c077631b33058658ce9_lvpaiche.mp4"; //加油站车牌，绿牌车
    // std::string inputs2 = "../videos/kouzhao.mp4"; //kouzhao
    
    // std::string inputs2 = "../videos/916d23e4a360812b3e13e5ecb793524d_chepai_missing.mp4"; //加油站车牌
    // std::string inputs2 = "../videos/jiayouzhan_jingzhichepai_20221020161316.mp4"; //加油站车牌
    
    
    // std::string inputs2 = "../videos/64f679fe7eb60ca3e889ffe32ddad74e_dzwl_day.mp4";//加油站电子围栏
    // std::string inputs2 = "../videos/xunjian-jiayouji.mp4"; //jiayouji
    // std::string inputs2 = "../videos/phontest_(3).mp4"; //贵州打电话
    // std::string inputs2 = "../videos/192.168.0.208.mp4";
    // std::string inputs2 = "../videos/192.168.0.13.mp4";//仅有一个
    // std::string inputs2 = "../videos/192.168.0.209.mp4";//外北1230am
    // std::string inputs2 = "../videos/192.168.0.15.mp4";//中海油新津加油机
    // std::string inputs2 = "../videos/32e8d0f3aa73e35e60893b6a995dba2d.mp4";//中海油穿工作服未穿反光衣,少量遮挡
    // std::string inputs2 = "../videos/26e835db35a569c56832b9edb8caae18_rkj0109.mp4";//中海油外北人孔井
    // std::string inputs2 = "../videos/cc5dd94e5d3090de39ec5261e3ed63a1_fgy.mp4";//反光衣
    
    // std::string inputs2 = "../videos/13.mp4"; //加油站火,三轮车
    // std::string inputs2 = "../videos/1676267119298-firetest.mp4"; //冯测试点纸2   OK，报警很多
    // std::string inputs2 = "../videos/1676266439559_fire.mp4"; //冯测试点纸
    // std::string inputs2 = "../videos/1676266857050-firetest.mp4"; //冯测试点纸   没有,why？    //第二次测有一个报警！
    // std::string inputs2 = "../videos/20230212xieyouqu.mp4"; //满足10分钟，应该有报警
    // std::string inputs2 = "../videos/1676956634555_xy_xieyou.mp4"; //没有到10分钟，不应该有报警
    // std::string inputs2 = "../videos/1677246894828_xieyouqu.mp4"; //卸油区：应该无报警
    // std::string inputs2 = "../videos/firetest_emb_2.mp4"; //侯在机器人公司测试无报警2
    // std::string inputs2 = "../videos/95ee56f493a519_rkj.mp4"; //北外人孔井漏报、重复
    // std::string inputs2 = "../videos/192.168.0.214_rkj_xinjing.mp4"; //
    // std::string inputs2 = "../videos/192.168.0.208_beiwai_jyj.mp4"; //北外加油机无报警
    // std::string inputs2 = "../videos/192.168.1.215_xingyi_jiayouji.mp4"; //兴义加油机无报警
    // std::string inputs2 = "../videos/192.168.0.214_beiwai.mp4"; //北外人孔井,3/23
    // std::string inputs2 = "../videos/92ef812b5c487a05_xieyouqu_absence_ok.mp4"; //卸油区离岗
    // std::string inputs2 = "../videos/NVR_ch13_main_20230510151827_20230510153504_xieyouAbsence.mp4"; //卸油区离岗,异常退出问题
    // std::string inputs2 = "../videos/1684639043324_IP_192.168.1.64.mp4"; //室内小盒子烟火测试
    // std::string inputs2 = "../videos/chouyan_dahuoji_ceshi_2.mp4"; //抽烟打火机测试
    // std::string inputs2 = "../videos/dadianhua-meiyoubaojing _2.mp4"; //打电话
    // std::string inputs2 = "../videos/10.120.12.146_convery.mp4"; //打电话
    std::string inputs2 = "../videos/phontest_2.mp4"; //打电话

    

//camId 64
    // std::string inputs3 = "../videos/jiayouzhan-renche.mp4";
    // std::string inputs3 = "../videos/zhyxunjian_jyj1.mp4";
    
    // std::string inputs3 = "../videos/converytest3.mp4"; //convery

    // std::string inputs3 = "../videos/NVR_ch5_main_20220717151700_20220717151959.mp4"; //文件丢！徐州抽烟
    // std::string inputs3 = "../videos/NVR_ch7_main_20220630175853_20220630180342.dav";//徐州抽烟
    // std::string inputs3 = "../videos/XJXYQ.mp4";//中海油油罐车停车
    // std::string inputs3 = "../videos/45d3cd2ffeb012db8c968722945a8561.mp4";//中海油油罐车停车
    // std::string inputs3 = "../videos/4ebc31ea53fc1891e5617f4deb1bf244.mp4";//中海油穿工作服未穿反光衣
    // std::string inputs3 = "../videos/dzwl_chongfu.mp4";


    // std::string inputs3 = "../videos/NVR_ch12_main_20220925091133_20220925091252-jyj-64.mp4"; //jiayouji
    // std::string inputs3 = "../videos/f142121f78d7551eb96e009fb5d1dbdb_1013_dzwl.mp4";//加油站电子围栏

    // std::string inputs3 = "../videos/jiayouzhan_jingzhichepai_20221020161316.mp4"; //加油站车牌
    // std::string inputs3 = "../videos/192.168.0.211.mp4"; //中海油外北加油机，检测不出来！
    // std::string inputs3 = "../videos/192.168.0.211.mp4"; //中海油外北加油机
    // std::string inputs3 = "../videos/192.168.0.12.mp4"; //中海油新津加油机
    

    // std::string inputs3 = "../videos/b5c0d358f022d3a6af6baebcdb3f599e-chepai.mp4"; //chepai,OK
    // std::string inputs3 = "../videos/05.mp4"; //加油站火
    // std::string inputs3 = "../videos/1676266857050-firetest.mp4"; //冯测试点纸   没有,why？
    // std::string inputs3 = "../videos/2e3c21b5d91beb15a4e1362fbc430811_chedingzhanren.mp4"; //车顶站人
    // std::string inputs3 = "../videos/1676956772159_xy_xieyou.mp4"; //卸油区应该无报警
    // std::string inputs3 = "../videos/1676962162360_beiwai_xieyou.mp4"; //没有到10分钟，不应该有报警
    // std::string inputs3 = "../videos/1677246971684_xieyouqu.mp4"; //卸油区：应该无报警
    // std::string inputs3 = "../videos/1678069081602_cdzr_0306.mp4"; //车顶站人
    // std::string inputs3 = "../videos/1678506721019_cdzr.mp4"; //
    // std::string inputs3 = "../videos/192.168.0.209_beiwai_jyj.mp4"; //北外加油机无报警
    // std::string inputs3 = "../videos/192.168.1.217_xingyi_jiayouji.mp4"; //兴义加油机无报警
    // std::string inputs3 = "../videos/192.168.0.214-1_beiwai.mp4"; //北外人孔井,3/23
    // std::string inputs3 = "../videos/1684639416178_IP_192.168.1.196.mp4"; //室内小盒子烟火测试
    // std::string inputs3 = "../videos/1686486823002_ip_192.168.1.196.mp4"; //打电话
    // std::string inputs3 = "../videos/shuliangjishipin_convery.mp4"; //打电话
    std::string inputs3 = "../videos/phontest_3.mp4"; //打电话


    


    cv::VideoCapture cap,cap2,cap3;
    // bool IS_TEST_VIDEO=true;
    bool IS_TEST_VIDEO=false;

    if(IS_TEST_VIDEO)
    {
        if (inputs.find("mp4") != std::string::npos || inputs.find("avi") != std::string::npos || inputs.find("asf") != std::string::npos
                || inputs.find("dav") != std::string::npos)
        {   
            std::cout<<"read video from "<<inputs<<std::endl;
            cap.open(inputs);
            if(!cap.isOpened()){
                std::cout<<"Error: video stream can't be opened!"<<std::endl;
                return (void*)0;
            }        
            int h = cap.get(4);
            int w = cap.get(3);

        }

        if (inputs2.find("mp4") != std::string::npos || inputs2.find("avi") != std::string::npos || inputs2.find("asf") != std::string::npos
        || inputs2.find("dav") != std::string::npos)
        {   
            std::cout<<"read video from "<<inputs2<<std::endl;
            cap2.open(inputs2);
            if(!cap2.isOpened()){
                std::cout<<"Error: video stream can't be opened!"<<std::endl;
                return (void*)0;
            }        
            int h = cap2.get(4);
            int w = cap2.get(3);

        }

        if (inputs3.find("mp4") != std::string::npos || inputs3.find("avi") != std::string::npos || inputs3.find("asf") != std::string::npos
        || inputs3.find("dav") != std::string::npos)
        {   
            std::cout<<"read video from "<<inputs3<<std::endl;
            cap3.open(inputs3);
            if(!cap3.isOpened()){
                std::cout<<"Error: video stream can't be opened!"<<std::endl;
                return (void*)0;
            }        
            int h = cap3.get(4);
            int w = cap3.get(3);

        }
    }
    




    ///////////////

    int i=0;
    int  i5=0, i23=0, i64=0;
    int requestlogDumpTimeCounter=0;

    while(! (isVideoEnd5 && isVideoEnd23 && isVideoEnd64))
    {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
            // sleep(1); //unsigned int seconds  1sec is OK
            //static int useconds=10*1000;   //already OK
            //static int useconds=35*1000;   //加了运粮机后oom?
            // static int useconds=50*1000;
            static int useconds=50*1000;
            if(!IS_TEST_VIDEO)
            {
                useconds=500*1000;
            }

            usleep(useconds);

    ///////////////////////////Main logic

            //todo:获取时间，备份日志与每日重新清空track
            int nowMinute=getCurMinuteDaytimeXB();

            if(!tidayUpNow)
            {
                if(nowMinute>tidyuptimeS && nowMinute<tidyuptimeE)
                {
                    //需要做重清并设置标志
                    tidayUpNow = true; 
                    ANNIWOLOG(INFO) << "detect: enter set tidayUpNow:" <<tidayUpNow<< "tidiedOnce:" <<tidiedOnce;
                }else
                {
                }
            }else
            {
                if(nowMinute>tidyuptimeS && nowMinute<tidyuptimeE)
                {
                }else
                {
                    ANNIWOLOG(INFO) << "detect: enter re-set tidayUpNow:" <<tidayUpNow<< "tidiedOnce:" <<tidiedOnce;
                    tidayUpNow=false;    //重置时间标识
                    tidiedOnce = false;
                }
            }

            //测试
            // if(i == 1500)
            // {
            //     istodoInitTracks=true;
            //     tidayUpNow=true;
            // }

            if(istodoInitTracks || ( tidayUpNow && (!tidiedOnce) )  )
            {
                if(istodoInitTracks)
                {
                    ANNIWOLOG(INFO) << "detect: enter istodoInitTracks==True" ;
                }else
                {
                    ANNIWOLOG(INFO) << "detect: enter tidayUpNow:" <<tidayUpNow<< "tidiedOnce:" <<tidiedOnce;
                }

                //测试
                // if(isFirstimeInitFramer)
                // {
                //     ANNIWOLOG(INFO) << "detect: enter isFirstimeInitFramer" ;
                //     videogpuObj.init_framer(rtmpStrs,rtmpIds);
                //     isFirstimeInitFramer = false;
                // }
                // else
                // {
                //     ANNIWOLOG(INFO) << "detect: calling stop2uninitialize_framing" ;
                //     videogpuObj.stop2uninitialize_framing();
                //     ANNIWOLOG(INFO) << "detect: calling re_init_framer" ;
                //     videogpuObj.re_init_framer(rtmpStrs, rtmpIds);
                // }
                
                

                //must wait all thread done,otherwise may have issue!!! like deepsort feature extractor
                if(pool)
                {
                    if(poolpersonbase)
                    {
                        ANNIWOLOG(INFO) <<"detect: try to deleted poolpersonbase...";

                        delete poolpersonbase;
                        poolpersonbase=nullptr;

                        ANNIWOLOG(INFO) <<"detect: poolpersonbase deleted OK";

                    }
                    ANNIWOLOG(INFO) <<"detect: try to deleted main pool";
                    

                    delete pool;
                    pool=nullptr;


                    ANNIWOLOG(INFO) <<"detect: pool deleted OK";


                    //在这里进行整理
                    if(tidayUpNow )
                    {
                        usleep(useconds);
                        size_t filesize = getFileSize1("../lsm.log");

                        if(filesize > 100*1024*1024)//200M
                        {
                            std::stringstream buffer;  

                            buffer <<"../lsm.log_"<<log_suffix_cnt;  
                            
                            if(CopyFile("../lsm.log",buffer.str().c_str() ))
                            {
                                if(TrunckFile("../lsm.log"))
                                {
                                    ANNIWOLOG(INFO) <<"detect: TrunckFile success!";
                                }
                                else
                                {
                                    ANNIWOLOG(INFO) <<"detect: TrunckFile error!";
                                }

                            }else
                            {
                                ANNIWOLOG(INFO) <<"detect: calling file copy error!";
                            }

                            log_suffix_cnt += 1;
                        }

                        ANNIWOLOG(INFO) <<"detect: log tidyup OK";

                    }


                    #ifdef __aarch64__
                        pool = new ThreadPool(100);
                        poolpersonbase = new ThreadPool(28);
                    #else
                        //x86_64 server
                        pool = new ThreadPool(768);
                        poolpersonbase = new ThreadPool(125);
                    #endif

                    ANNIWOLOG(INFO) <<"detect: pool created OK";

                }

                std::unique_lock<std::mutex> uniqueLock(mtx4GlobalVariables, std::defer_lock);
                uniqueLock.lock();
                ANNIWOLOG(INFO) <<"detect: get into uniqueLock OK";

                //////////
                globalJsonConfObj.id_func_cap=globalJsonConfObjNotApplied.id_func_cap;
                globalJsonConfObj.validtypes_map=globalJsonConfObjNotApplied.validtypes_map;
                globalJsonConfObj.validperoids_hour_map=globalJsonConfObjNotApplied.validperoids_hour_map;
                globalJsonConfObj.validperoids_week_map=globalJsonConfObjNotApplied.validperoids_week_map;
                globalJsonConfObj.validArea_conf_map=globalJsonConfObjNotApplied.validArea_conf_map;
                globalJsonConfObj.interval_conf_map=globalJsonConfObjNotApplied.interval_conf_map;
                globalJsonConfObj.stay_conf_map=globalJsonConfObjNotApplied.stay_conf_map;
                globalJsonConfObj.taskid_conf_map=globalJsonConfObjNotApplied.taskid_conf_map;
                globalJsonConfObj.facedatasetpath_conf_map=globalJsonConfObjNotApplied.facedatasetpath_conf_map;
                globalJsonConfObj.eventUrl_conf_map=globalJsonConfObjNotApplied.eventUrl_conf_map;
                globalJsonConfObj.absenceStartConition_conf_map=globalJsonConfObjNotApplied.absenceStartConition_conf_map;

                //////////

                std::stringstream buffer;  
                buffer << "../requestjsonApplied_"<<requestlogDumpTimeCounter<<".log";  
                std::string nameStr(buffer.str());

                dumpToTxtFile(nameStr.c_str(),currentInJsonAll);
                requestlogDumpTimeCounter++;

                uniqueLock.unlock();

                ANNIWOLOG(INFO) <<"detect: out of  uniqueLock OK";
                ANNIWOLOG(INFO) <<"detect: newly applied:globalJsonConfObj.validperoids_week_map.size"<< globalJsonConfObj.validperoids_week_map.size();
                //std::unordered_map<int,std::unordered_map<std::string, Polygon>  >
                for(auto& itempair:globalJsonConfObj.validArea_conf_map)
                {
                    // cout<<kv.first<<kv.second<<endl;
                    int camId = itempair.first;
                    auto& funcAreaMap = itempair.second;

                    for(auto& funcAreaItem:funcAreaMap)
                    {
                        auto& funcname = funcAreaItem.first;
                        auto& polygonSafeArea = funcAreaItem.second;

                        std::stringstream buffer;  
                        for(int i=0; i < polygonSafeArea.size(); i++)
                        {
                            const cv::Point& pt=polygonSafeArea.pt[i];
                            buffer << pt.x<<","<<pt.y<<" ";  
                        }
                        std::string text(buffer.str());

                        ANNIWOLOG(INFO) << "detect json:validArea_conf_map,camId:" <<camId<<" func:"<<funcname<<" validArea:"<<text;

                    }

                }
                

                basePersonDetect->initTracks(globalJsonConfObj,person_base_functions);

                ANNIWOLOG(INFO) <<"detect: basePersonDetect->initTracks OK";

                if(personbase_detObjPtr)
                {
                    delete personbase_detObjPtr;
                    personbase_detObjPtr=nullptr;
                }
                ANNIWOLOG(INFO) <<"detect: personbase_detObjPtr deleted OK";

                personbase_detObjPtr =  new PERSONBASE_DET(globalJsonConfObj.id_func_cap,person_base_functions);
                ANNIWOLOG(INFO) <<"detect: personbase_detObjPtr created OK";



                initAllTracks(globalJsonConfObj);              

                ANNIWOLOG(INFO) <<"detect: initAllTracks OK";


                istodoInitTracks = false;
                
            }

            ANNIWOLOG(INFO) <<"detect(): calling consume_frame";


            //TEST WITH VIDEOS/////////////////////
            int camId=-1;
            cv::Mat input_image,img;

            if(IS_TEST_VIDEO)
            {
                //Make local video read frame!
                i++;
                int order=i%3;
                if(order == 0 )
                {
                    if(!cap.read(input_image))
                    {
                        isVideoEnd5=true;
                    }else
                    {
                        ///////////////
                        camId = 5;
                        img = input_image;
                    }

                    if(!input_image.data){
                        continue;
                    }
                }else if(order == 1)
                {
                    if(!cap2.read(input_image))
                    {
                        isVideoEnd23=true;
                    }else
                    {
                        ///////////////
                        camId = 23;
                        img = input_image;
                    }

                    if(!input_image.data){
                        continue;
                    }      
                }else
                {
                    if(!cap3.read(input_image))
                    {
                        isVideoEnd64 =true;
                    }else
                    {
                        ///////////////
                        camId = 64;
                        img = input_image;
                    }

                    if(!input_image.data){
                        continue;
                    }      
                }
            }

            //TEST WITH VIDEOS/////////////////////


            //TEST WITH IMAGES///////////////
            if(! IS_TEST_VIDEO)
            {
                //Make local image read frame!
                int order=i%3;
                if(order == 0 )
                {
                    static std::vector<std::string> all_img_paths5;
                    if(all_img_paths5.size() <= 0 )
                    {
                        std::vector<cv::String> cv_all_img_paths;
                        cv::glob("../images/camID5_dir/", cv_all_img_paths);
                        for (const auto& img_path : cv_all_img_paths) {
                            all_img_paths5.push_back(img_path);
                        }
                    }

                    if(all_img_paths5.size()<=0 || i5 >= all_img_paths5.size())
                    {
                        isVideoEnd5=true;
                    }else
                    {
                        ///////////////
                        camId = 5;
                        input_image = cv::imread(all_img_paths5[i5], 1);
                        img = input_image;
                        i5++;
                    }

                    if(!input_image.data){
                        i++;
                        continue;
                    }
                }else if(order == 1)
                {
                    static std::vector<std::string> all_img_paths23;
                    if(all_img_paths23.size() <= 0)
                    {
                        std::vector<cv::String> cv_all_img_paths;
                        cv::glob("../images/camID23_dir/", cv_all_img_paths);
                        for (const auto& img_path : cv_all_img_paths) {
                            all_img_paths23.push_back(img_path);
                        }
                    }


                    if(all_img_paths23.size()<=0 || i23 >= all_img_paths23.size())
                    {
                        isVideoEnd23=true;
                    }else
                    {
                        ///////////////
                        camId = 23;
                        input_image = cv::imread(all_img_paths23[i23], 1);

                        img = input_image;
                        i23++;
                    }

                    if(!input_image.data){
                        i++;
                        continue;
                    }      
                }else
                {
                    static std::vector<std::string> all_img_paths64;
                    if(all_img_paths64.size() <= 0)
                    {
                        std::vector<cv::String> cv_all_img_paths;
                        cv::glob("../images/camID64_dir/", cv_all_img_paths);
                        for (const auto& img_path : cv_all_img_paths) {
                            all_img_paths64.push_back(img_path);
                        }
                    }

                    if(all_img_paths64.size()<=0 || i64 >= all_img_paths64.size())
                    {
                        isVideoEnd64=true;
                    }else
                    {
                        ///////////////
                        camId = 64;
                        input_image = cv::imread(all_img_paths64[i64], 1);
                        
                        img = input_image;

                        i64++;
                    }

                    if(!input_image.data){
                        i++;
                        continue;
                    }      
                }
                i++;

            }




            ////////////////////////////////



            if(isVideoEnd5  && isVideoEnd23  && isVideoEnd64  )
            {
                ANNIWOLOG(INFO) << "Got video END !!!!!!!!!!!!!!!!!!!!!!!camId:" <<camId;
                break;

            }


            std::unordered_map<int, std::vector<std::string> >::const_iterator got_id_func_cap = globalJsonConfObj.id_func_cap.find(camId);

            if (got_id_func_cap == globalJsonConfObj.id_func_cap.end())
            {
                ANNIWOLOG(INFO) << "not found in globalJsonConfObj.id_func_cap,camId:" <<camId;
            }
            else
            {
                const std::vector<std::string>& func_list=got_id_func_cap->second;
                int foundcamID =  got_id_func_cap->first;

                ANNIWOLOG(INFO) <<"camId:" << foundcamID << " has " << func_list[0] << "...etc.";
                


                std::unordered_set<std::string> perCamsubmittedfuncs;
                
                std::vector<std::string> personfuncsPerCamthis;

                for (auto& f : func_list)
                {
                    ANNIWOLOG(INFO) <<"detect(): f="<< f ;

                    std::unordered_set<std::string>::const_iterator got_in_use_conf_functions = globalINICONFObj.in_use_conf_functions.find(f);

                    if (got_in_use_conf_functions == globalINICONFObj.in_use_conf_functions.end())
                    {
                        ANNIWOLOG(INFO) <<"f is not use.continue:"<<f;
                        continue;
                    }
                    else
                    {
                        ANNIWOLOG(INFO) <<" f in the list:"<<f<< " camId:" <<camId;



                        bool isOK2Submit = isRequireSubmitThread(perCamsubmittedfuncs,f,camId);

                        if(isOK2Submit)
                        {

                            //组控制,比如personbase组
                            std::unordered_set<std::string>::const_iterator got_person_base_functions = person_base_functions.find(f);

                            if (got_person_base_functions == person_base_functions.end())
                            {
                                bool submitSuccess = submitThread(f, camId, img,*personbase_detObjPtr);

                                perCamsubmittedfuncs.insert(f);

                                if( ! submitSuccess )
                                {
                                    resetIntervalRecord(f, camId);
                                }

                            }
                            else
                            {
                                personfuncsPerCamthis.push_back(f);
                                perCamsubmittedfuncs.insert(f);

                                ANNIWOLOG(INFO) <<"put:"<<f<<" in array for later submit. "<<" camId:"<<camId;

                            }


                        }else
                        {
                            ANNIWOLOG(INFO) <<"no submit thread as not isOK2Submit:"<<f<<" camId:"<<camId<<std::endl;
                        }


                    }



                }

           
                
                
                if(personfuncsPerCamthis.size() > 0)
                {
                    static int instanceCnt=0;

                    //camId, instanceId
                    static std::unordered_map<int, int> busyCamIdInstanceMap;
                    bool useExistingInstance=false;


                    std::unordered_map<int, int>::iterator iterCamInstanceId =  busyCamIdInstanceMap.find(camId);
                    if (iterCamInstanceId != busyCamIdInstanceMap.end()) //在busyCamIdInstanceMap中有记录
                    {
                        int tmpInstanceId=iterCamInstanceId->second;
                        
                        std::unordered_map<int, std::future<void>>::iterator perCamTask =  pGroupTasks.find(tmpInstanceId);
                        if (perCamTask == pGroupTasks.end())
                        {
                            ANNIWOLOG(INFO) <<"Warining:It in busyCamIdInstanceMap but NO this instanceID in pGroupTasks:"<<iterCamInstanceId->second<<" camId:"<<camId;
                            busyCamIdInstanceMap.erase(camId);

                        }else
                        {
                            useExistingInstance=true;
                            instanceCnt=iterCamInstanceId->second;

                            ANNIWOLOG(INFO) <<"use existing isntance: for personbaseGroup  instanceID:"<<instanceCnt<<" camId:"<<camId;

                        }


                    }else
                    {
                        instanceCnt=instanceCnt%globalINICONFObj.ANNIWO_NUM_THREAD_PERSONBASE;
                        ANNIWOLOG(INFO) <<"use this isntance: for personbaseGroup  instanceID:"<<instanceCnt<<" camId:"<<camId;

                    }


                    
                    std::unordered_map<int, std::future<void>>::iterator perCamTask =  pGroupTasks.find(instanceCnt);
                    if (perCamTask == pGroupTasks.end())
                    {
                        ANNIWOLOG(INFO) <<"submiting thread: for personbaseGroup when no this instanceID:"<<instanceCnt<<" camId:"<<camId;

                        std::future<void> fur=poolpersonbase->enqueue(personbaseGroupFunc,personfuncsPerCamthis,camId,instanceCnt,img);   
                        std::pair<int, std::future<void>> taskpair(instanceCnt,std::move(fur));
                        pGroupTasks.insert(std::move(taskpair));

                                                    //更新busymap
                        int previousCamId=-1;
                        for(auto& item:busyCamIdInstanceMap)
                        {
                            if(item.second == instanceCnt)
                            {
                                previousCamId=item.first;
                                break;
                            }
                        }
                        if(previousCamId != -1)
                        {
                            busyCamIdInstanceMap.erase(previousCamId);
                        }
                        std::pair<int, int> tmpitem(camId,instanceCnt);
                        busyCamIdInstanceMap.insert(std::move(tmpitem));


                    }else if(!perCamTask->second.valid()  || perCamTask->second.wait_for(std::chrono::nanoseconds(3))==std::future_status::ready)
                    {
                        ANNIWOLOG(INFO) <<"submiting thread: for personbaseGroup camId:"<<camId<<" instanceID:"<<instanceCnt;
                        std::future<void> futr=poolpersonbase->enqueue(personbaseGroupFunc,personfuncsPerCamthis,camId,instanceCnt,img);   

                        perCamTask->second=std::move(futr);

                        //更新busymap
                        int previousCamId=-1;
                        for(auto& item:busyCamIdInstanceMap)
                        {
                            if(item.second == instanceCnt)
                            {
                                previousCamId=item.first;
                                break;
                            }
                        }
                        if(previousCamId != -1)
                        {
                            busyCamIdInstanceMap.erase(previousCamId);
                        }
                        std::pair<int, int> tmpitem(camId,instanceCnt);
                        busyCamIdInstanceMap.insert(std::move(tmpitem));


                    }
                    else
                    {
                        ANNIWOLOG(INFO) <<"DISCARD img for: personbaseGroup group camId: "<<camId<<"because busy. instanceID:"<<instanceCnt;
                    }

                    if(!useExistingInstance)
                    {
                        instanceCnt++;
                    }

                }


            }

///////////////////////////Main logic end
    }
}


void engineStart()
{

    ANNIWOLOG(INFO) << "Now (re)start engine!";

    ////////////////////////////
    std::ifstream ifs;
    // 3 打开文件 判断是否打开成功
    ifs.open("../key.txt", std::ios::in);
    if (!ifs.is_open()) {
            ANNIWOLOG(INFO) << "file open ../key.txt failed!"<< endl;
            ANNIWOCHECK(false);
            exit(0);
    }
    string buf;
    string outbuf;
    while (getline(ifs, buf)) {
        outbuf=buf;
        ANNIWOLOG(INFO) << outbuf ;
    }
    bool verifyResult = VerifyKey(outbuf);
    if(verifyResult)
    {
        ANNIWOLOG(INFO) << "KEY OK using ../key.txt"<< endl;
    }
    else
    {
        ANNIWOLOG(INFO) << "KEY Failed using ../key.txt"<< endl;
        ANNIWOCHECK(false);
        exit(0);
    }
    //////////////////////

    std::unique_lock<std::mutex> uniqueLock(mtx4GlobalVariables, std::defer_lock);
    uniqueLock.lock();

    //start the detect thread
    if(!threadDetect)
    {
        istodoInitTracks=true;
        threadDetect = new std::thread(detectFunc, (void*)0 );
        ANNIWOLOG(INFO) << "detection thread started" ;

    }
    else
    {
        ANNIWOLOG(INFO) << "detection thread is exsiting...set istodoInitTracks=True";
        istodoInitTracks=true;
    }


    uniqueLock.unlock();

    return ;
}




void managerMent(const std::string& inJsonAll)
{
        static int requestlogDumpTimeCounter=0;
        if(geteuid()==0)
        {
            ANNIWOLOG(INFO) << "with root running,OK!"<< endl;
        }
        else
        {
            ANNIWOLOG(INFO) << "Not with root failed!"<< endl;
            ANNIWOCHECK(false);
            exit(-1);
        }
////////////////////////////
        std::ifstream ifs;
        // 3 打开文件 判断是否打开成功
        ifs.open("../key.txt", std::ios::in);
        if (!ifs.is_open()) {
                ANNIWOLOG(INFO) << "file open ../key.txt failed!"<< endl;
                ANNIWOCHECK(false);
                exit(0);
        }
        string buf;
        string outbuf;
        while (getline(ifs, buf)) {
            outbuf=buf;
            ANNIWOLOG(INFO) << outbuf ;
        }
        bool verifyResult = VerifyKey(outbuf);
        if(verifyResult)
        {
            ANNIWOLOG(INFO) << "KEY OK using ../key.txt"<< endl;
        }
        else
        {
            ANNIWOLOG(INFO) << "KEY Failed using ../key.txt"<< endl;
            ANNIWOCHECK(false);
            exit(0);
        }
//////////////////////
        ANNIWOLOG(INFO) <<"request json:"<< inJsonAll ;

        std::stringstream buffer;  
        buffer << "../requestjsonNAp_"<<requestlogDumpTimeCounter<<".log";  
        std::string nameStr(buffer.str());

        dumpToTxtFile(nameStr.c_str(),inJsonAll);
        requestlogDumpTimeCounter++;
        
        currentInJsonAll=inJsonAll;
        


        rapidjson::Document  document;

        if(document.Parse(inJsonAll.c_str()).HasParseError())
        {
            ANNIWOLOG(INFO) <<"Fatal error json parse!"<<std::endl;
            std::ostringstream os;
            os << "Fatal error json parse! Check the format!!";
            return ;
        }

        assert(document.IsArray());    // Document is a JSON value represents the root of DOM. Root can be either an object or array.


        std::unique_lock<std::mutex> uniqueLock(mtx4GlobalVariables, std::defer_lock);
        uniqueLock.lock();

        globalJsonConfObjNotApplied.id_func_cap.clear();
        globalJsonConfObjNotApplied.validtypes_map.clear();
        globalJsonConfObjNotApplied.validperoids_hour_map.clear();
        globalJsonConfObjNotApplied.validperoids_week_map.clear();
        globalJsonConfObjNotApplied.validArea_conf_map.clear();
        globalJsonConfObjNotApplied.interval_conf_map.clear();
        globalJsonConfObjNotApplied.stay_conf_map.clear();
        globalJsonConfObjNotApplied.taskid_conf_map.clear();
        globalJsonConfObjNotApplied.facedatasetpath_conf_map.clear();
        globalJsonConfObjNotApplied.eventUrl_conf_map.clear();
        rtmpIds.clear();
        rtmpStrs.clear();


        for (rapidjson::SizeType i = 0; i < document.Size(); i++) // rapidjson uses SizeType instead of size_t.
        //todo:解析json
        {
            const rapidjson::Value& q = document[i];

            assert(q.IsObject());  

            
            bool bHascamId = q.HasMember("camId");
            bool bHascamStr =  q.HasMember("camStr");
            bool bHasfuncConf =  q.HasMember("funcConf");
            assert(bHascamId && bHascamStr  );


            int camId = -1;

            // camID必须为int值，保持与c++ videogpu一致
            std::stringstream stream;   
            stream << q["camId"].GetString();     //向stream中插入字符串"1234"
            stream >> camId;     //从stream中提取刚插入的字符串"1234


            std::string rmtplink = {q["camStr"].GetString()};
            // cam_map[camId] = rmtplink
            rtmpIds.emplace_back(camId);
            rtmpStrs.emplace_back(rmtplink);
            
            assert(q.HasMember("func"));

            const rapidjson::Value& funcq=q["func"];
            assert(funcq.IsArray());  
            for (rapidjson::SizeType j = 0; j < funcq.Size(); j++) // rapidjson uses SizeType instead of size_t.
            {
                const rapidjson::Value& fq = funcq[j];
                std::string  f=fq.GetString();
                std::unordered_map<int, std::vector<std::string> >::iterator got_id_func_cap = globalJsonConfObjNotApplied.id_func_cap.find(camId);

                if (got_id_func_cap == globalJsonConfObjNotApplied.id_func_cap.end())
                {
                    ANNIWOLOG(INFO) << "not found in globalJsonConfObjNotApplied.id_func_cap,camId:" <<camId<<"new func:"<<f;
                    std::vector<std::string> caps = {f};
                    globalJsonConfObjNotApplied.id_func_cap.insert(std::pair<int, std::vector<std::string> >(camId,caps) );
                }
                else
                {
                    std::vector<std::string>& func_list=got_id_func_cap->second;
                    func_list.emplace_back(f);
                }
            }


            if(q.HasMember("funcConf"))
            {
                const rapidjson::Value&  funcConfq = q["funcConf"];
                assert(funcConfq.IsObject());  

                if( funcConfq.IsNull())
                {
                    continue;
                }

                for(rapidjson::Value::ConstMemberIterator confIter = funcConfq.MemberBegin(); confIter != funcConfq.MemberEnd(); ++confIter){
                {   //"funcConf"

                    const rapidjson::Value& childIter = confIter->value;
                    std::string funcname  = confIter->name.GetString();
                    //"safeErea":/"helmet":/"smoke"
                    ANNIWOLOG(INFO) <<"funcname:"<<funcname<<std::endl;
                    if(! childIter.IsObject() )
                    {//错误处理！
                        const rapidjson::Value& funcValue  = childIter;
                        rapidjson::Type tpValue= funcValue.GetType();
                        ANNIWOLOG(INFO) <<"funcValue type:"<<tpValue<<std::endl;
                        if(tpValue == rapidjson::Type::kNullType)
                        {
                            ANNIWOLOG(INFO) <<"funcValue is null"<<std::endl;
                        }
                        else if(tpValue == rapidjson::Type::kArrayType)
                        {
                            ANNIWOLOG(INFO) <<"funcValue is Array. Wrong type"<<std::endl;

                        }
                        else if(tpValue == rapidjson::Type::kNumberType)
                        {
                            ANNIWOLOG(INFO) <<"funcValue is Number. Wrong type"<<std::endl;

                        }
                        else if (tpValue == rapidjson::Type::kStringType)
                        {
                            ANNIWOLOG(INFO) <<"funcValue is String. Wrong type"<<std::endl;
                        }
                        else
                        {
                            ANNIWOLOG(INFO) <<"funcValue is UNKOWN type"<<std::endl;

                        }
                    }else
                    {
                        for(rapidjson::Value::ConstMemberIterator it = childIter.MemberBegin(); it != childIter.MemberEnd(); ++it)
                        {//功能对应的具体配置."area"/"interval"/"stay"/"types"/"periods"

                            std::string  paramname=it->name.GetString();
                            
                            ANNIWOLOG(INFO) <<"paramname:"<<paramname<<std::endl;

                            const rapidjson::Value& paramvalue  = it->value;
                            rapidjson::Type tpValue= paramvalue.GetType();
                            ANNIWOLOG(INFO) <<"paramvalue type:"<<tpValue<<std::endl;
                            if(tpValue == rapidjson::Type::kNullType)
                            {
                                ANNIWOLOG(INFO) <<"paramvalue is null"<<std::endl;
                            }
                            else if(tpValue == rapidjson::Type::kArrayType)
                            {//功能对应的具体配置."area"/"interval"/"stay"/"types"/"periods" 对应的值.
                                
                                if(paramname == std::string("types"))
                                {
                                    std::vector<std::string> validtypes;
                                    for (rapidjson::SizeType i = 0; i < paramvalue.Size(); i++) // rapidjson uses SizeType instead of size_t.
                                    {
                                        assert(paramvalue[i].IsString()); 
                                        validtypes.push_back(paramvalue[i].GetString());
                                    }

                                    //valid types
                                    //camId,{func,Vector<String>}
                                    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.validtypes_map.find(camId);
                                    std::vector<std::string> tmpempty;

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.validtypes_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in validtypes_conf_map,camId:" <<camId<<"new to validtypes_conf_map";
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes> mapp = { {funcname , {validtypes,tmpempty}} };
                                        globalJsonConfObjNotApplied.validtypes_map.insert(std::pair<int, std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, AnniwoSafeEreaConcernTypes  >(funcname,{validtypes,tmpempty}));
                                        }
                                        else
                                        {
                                            got_id_func_cap2->second.validtypes = validtypes;
                                        }
                                    }
                                }

                                if(paramname == std::string("excludeTypes"))
                                {
                                    std::vector<std::string> excludetypes;
                                    for (rapidjson::SizeType i = 0; i < paramvalue.Size(); i++) // rapidjson uses SizeType instead of size_t.
                                    {
                                        assert(paramvalue[i].IsString()); 
                                        excludetypes.push_back(paramvalue[i].GetString());
                                    }

                                    //exclude types
                                    //camId,{func,{Vector<String>,Vector<String>}}
                                    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.validtypes_map.find(camId);
                                    std::vector<std::string> tmpempty;

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.validtypes_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in excludetypes_conf_map,camId:" <<camId<<"new to excludetypes_conf_map";
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes> mapp = { {funcname , {tmpempty,excludetypes}} };
                                        globalJsonConfObjNotApplied.validtypes_map.insert(std::pair<int, std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, AnniwoSafeEreaConcernTypes  >(funcname,{tmpempty,excludetypes}));
                                        }
                                        else
                                        {
                                            got_id_func_cap2->second.excludeTypes = excludetypes;
                                        }
                                    }
                                }

                                


                                if(paramname == std::string("periods"))
                                {
                                    //注意如下两个有对应关系。
                                    std::vector<Polygon> validPeriods_hour;
                                    std::vector<std::string> validPeriods_week;

                                    Polygon polygon;
                                    for (rapidjson::SizeType i = 0; i < paramvalue.Size(); i++) // rapidjson uses SizeType instead of size_t.
                                    {
                                        
                                        const rapidjson::Value& q = paramvalue[i];
                                        assert(q.IsObject()); 
                                        bool bHasHour = q.HasMember("hour");
                                        bool bHasWeek =  q.HasMember("week");
                                        assert(bHasHour && bHasWeek);
                                        const rapidjson::Value&  hourarr = q["hour"];
                                        const rapidjson::Value&  weekvalue = q["week"];
                                        


                                        ///////////////////////
                                        assert(hourarr.IsArray());  
                                        polygon.clear();

                                        for (rapidjson::SizeType i = 0; i < hourarr.Size(); i++) // rapidjson uses SizeType instead of size_t.
                                        {
                                            assert(hourarr[i].IsArray());  

                                            cv::Point p;
                                            for (rapidjson::SizeType j = 0; j < hourarr[i].Size(); j++) // rapidjson uses SizeType instead of size_t.
                                            {
                                                if(j == 0)
                                                    p.x = hourarr[i][j].GetInt();
                                                else
                                                    p.y = hourarr[i][j].GetInt();
                                            }
                                            polygon.add(p);
                                        }
                                        ///////////////////////
                                        validPeriods_hour.push_back(polygon);
                                        validPeriods_week.push_back(weekvalue.GetString());

                                    }
                                    ANNIWOLOG(INFO) << "validPeriods_hour.size():" <<validPeriods_hour.size();
                                    ANNIWOLOG(INFO) << "validPeriods_week.size():" <<validPeriods_week.size();


                                    
                                    std::unordered_map<int,std::unordered_map<std::string, std::vector<Polygon>>  >::iterator got_id_func_capIter = globalJsonConfObjNotApplied.validperoids_hour_map.find(camId);

                                    if (got_id_func_capIter == globalJsonConfObjNotApplied.validperoids_hour_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in validperoids_hour_map,camId:" <<camId<<"new to validperoids_hour_map";
                                        std::unordered_map<std::string, std::vector<Polygon>> mapp = { {funcname , validPeriods_hour} };
                                        globalJsonConfObjNotApplied.validperoids_hour_map.insert(std::pair<int, std::unordered_map<std::string, std::vector<Polygon>>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::vector<Polygon>>& conf_map =got_id_func_capIter->second;
                                        std::unordered_map<std::string, std::vector<Polygon>>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::vector<Polygon> >(funcname,validPeriods_hour));
                                        }
                                        else
                                        {
                                            got_id_func_cap2->second = validPeriods_hour;
                                        }
                                    }

                                    ANNIWOLOG(INFO) << "globalJsonConfObjNotApplied.validperoids_hour_map.size():" <<globalJsonConfObjNotApplied.validperoids_hour_map.size();
                                    

                                    std::unordered_map<int,std::unordered_map<std::string, std::vector<std::string>>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.validperoids_week_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.validperoids_week_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in validperoids_week_map,camId:" <<camId<<"new to validperoids_week_map";
                                        std::unordered_map<std::string, std::vector<std::string>> mapp = { {funcname , validPeriods_week} };
                                        globalJsonConfObjNotApplied.validperoids_week_map.insert(std::pair<int, std::unordered_map<std::string, std::vector<std::string>>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::vector<std::string>>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, std::vector<std::string>>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::vector<std::string> >(funcname,validPeriods_week));
                                        }
                                        else
                                        {
                                            got_id_func_cap2->second = validPeriods_week;
                                        }
                                    }
                                }
                                ANNIWOLOG(INFO) << "globalJsonConfObjNotApplied.validperoids_week_map.size():" <<globalJsonConfObjNotApplied.validperoids_week_map.size();



                                if(paramname == std::string("area"))
                                {
                                    Polygon polygonSafeArea;
                                    polygonSafeArea.clear();

                                    for (rapidjson::SizeType i = 0; i < paramvalue.Size(); i++) // rapidjson uses SizeType instead of size_t.
                                    {
                                        assert(paramvalue[i].IsArray());  

                                        cv::Point p;
                                        for (rapidjson::SizeType j = 0; j < paramvalue[i].Size(); j++) // 2个int值
                                        {
                                            if(j == 0)
                                                p.x = paramvalue[i][j].GetInt();
                                            else
                                                p.y = paramvalue[i][j].GetInt();
                                        }
                                        polygonSafeArea.add(p);
                                    }
                                    
                                    if(polygonSafeArea.size() <= 1)
                                    {
                                        ANNIWOLOG(INFO) << "safeArea setting less than 2 points,ignored.camId:" <<camId;
                                        polygonSafeArea.clear();
                                    }

                                    //valid area
                                    //camId,{func,Polygon}
                                    std::unordered_map<int,std::unordered_map<std::string, Polygon>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.validArea_conf_map.find(camId);


                                    if (got_id_func_cap == globalJsonConfObjNotApplied.validArea_conf_map.end())
                                    {
                                        std::unordered_map<std::string, Polygon> mapp = { {funcname , polygonSafeArea} };
                                        globalJsonConfObjNotApplied.validArea_conf_map.insert(std::pair<int, std::unordered_map<std::string, Polygon>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, Polygon>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, Polygon>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, Polygon  >(funcname,polygonSafeArea));
                                        }
                                        else
                                        {
                                            got_id_func_cap2->second = polygonSafeArea;
                                        }
                                    }
                                }

                            }
                            else if(tpValue == rapidjson::Type::kNumberType)
                            {
                                ANNIWOLOG(INFO) <<"paramvalue:"<<paramvalue.GetInt()<<std::endl;
                                if(paramname == std::string("interval"))
                                {
                                    //interval
                                    //camId,{func,{interval,intervalCnter}}
                                    std::unordered_map<int,std::unordered_map<std::string, AnniwoTimeLog>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.interval_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.interval_conf_map.end())
                                    {
                                        //随机开始时间，错开间隔到期时间
                                        int configvalue=paramvalue.GetInt()*1000;

                                        int rdint = randIntWithinScale(configvalue);
                                        ANNIWOLOG(INFO) << "new to interval_conf_map:funcname:"<<funcname<<" camId:" <<camId<<"configvalue:"<<configvalue<< "rdint:"<<rdint;

                                        std::chrono::milliseconds one_second( rdint ); //应该用ms
                                        std::chrono::steady_clock::time_point next_minute = std::chrono::steady_clock::now() + one_second; 
                                            

                                        std::unordered_map<std::string, AnniwoTimeLog> mapp = { {funcname , {paramvalue.GetInt()*1000.0,next_minute}} };
                                        globalJsonConfObjNotApplied.interval_conf_map.insert(std::pair<int, std::unordered_map<std::string, AnniwoTimeLog>  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, AnniwoTimeLog>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, AnniwoTimeLog>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            
                                            //随机开始时间，错开间隔到期时间
                                            int configvalue=paramvalue.GetInt()*1000;
                                            int rdint = randIntWithinScale(configvalue);
                                            ANNIWOLOG(INFO) << "interval_conf_map:funcname:"<<funcname<<" camId:" <<camId<<"configvalue:"<<configvalue<< "rdint:"<<rdint;

                                            std::chrono::milliseconds one_second( rdint ); //ms
                                            std::chrono::steady_clock::time_point next_minute = std::chrono::steady_clock::now() + one_second; 
                                            
                                            conf_map.insert(std::pair<std::string, AnniwoTimeLog  >(funcname,{paramvalue.GetInt()*1000.0,next_minute}));
                                        }
                                        else
                                        {
                                            AnniwoTimeLog& vecValues =  got_id_func_cap2->second ;
                                            vecValues.configInterval= paramvalue.GetInt()*1000.0;

                                            //随机开始时间，错开间隔到期时间
                                            int configvalue=paramvalue.GetInt()*1000;
                                            int rdint = randIntWithinScale(configvalue);
                                            ANNIWOLOG(INFO) << "new to interval_conf_map:funcname:"<<funcname<<" camId:" <<camId<<"configvalue:"<<configvalue<< "rdint:"<<rdint;

                                            std::chrono::milliseconds one_second( rdint ); //应该用ms
                                            std::chrono::steady_clock::time_point next_minute = std::chrono::steady_clock::now() + one_second; 
                                            
                                            vecValues.lastTP = next_minute;
                                        }
                                    }

                                }

                                if(paramname == std::string("stay"))
                                {
                                    //stay
                                    //camId,{func,<isMotionless,stay>}
                                    std::unordered_map<int,std::unordered_map<std::string, AnniwoStay>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.stay_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.stay_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in stay_conf_map,camId:" <<camId<<"new to stay_conf_map";
                                        //{func,<isMotionless,stay>}
                                        std::unordered_map<std::string, AnniwoStay> mapp = { {funcname , {false, paramvalue.GetInt()}} };
                                        globalJsonConfObjNotApplied.stay_conf_map.insert(std::pair<int, std::unordered_map<std::string, AnniwoStay >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, AnniwoStay>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, AnniwoStay>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, AnniwoStay  >(funcname,{false, paramvalue.GetInt()}));
                                        }
                                        else
                                        {
                                            int& curValue =  got_id_func_cap2->second.staySec ;
                                            curValue = paramvalue.GetInt();
                                        }
                                    }

                                }

                                if(paramname == std::string("motionless"))
                                {
                                    //stay isMotionless
                                    //camId,{func,<isMotionless,stay>}
                                    std::unordered_map<int,std::unordered_map<std::string, AnniwoStay>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.stay_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.stay_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "isMotionless:not found in stay_conf_map,camId:" <<camId<<"new to stay_conf_map";
                                        //{func,<isMotionless,stay>}
                                        std::unordered_map<std::string, AnniwoStay> mapp = { {funcname , {paramvalue.GetBool(), 1}} };
                                        globalJsonConfObjNotApplied.stay_conf_map.insert(std::pair<int, std::unordered_map<std::string, AnniwoStay >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, AnniwoStay>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, AnniwoStay>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, AnniwoStay  >(funcname,{paramvalue.GetBool(), 1}));
                                        }
                                        else
                                        {
                                            bool& curValue =  got_id_func_cap2->second.isMotionless ;
                                            curValue = paramvalue.GetBool();
                                        }
                                    }

                                }

                            }
                            else if(tpValue == rapidjson::Type::kStringType)
                            {
                                ANNIWOLOG(INFO) <<"paramvalue:"<<paramvalue.GetString()<<std::endl;
                                if(paramname == std::string("taskId"))
                                {
                                    //camId,{func,strtaskId}
                                    std::unordered_map<int,std::unordered_map<std::string, std::string>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.taskid_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.taskid_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in taskid_conf_map,camId:" <<camId<<"new to taskid_conf_map";
                                        std::unordered_map<std::string, std::string> mapp = { {funcname , paramvalue.GetString()} };
                                        globalJsonConfObjNotApplied.taskid_conf_map.insert(std::pair<int, std::unordered_map<std::string, std::string >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::string>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, std::string>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::string  >(funcname,paramvalue.GetString()));
                                        }
                                        else
                                        {
                                            std::string& curValue =  got_id_func_cap2->second ;
                                            curValue = paramvalue.GetString();
                                        }
                                    }

                                }

                                if(paramname == std::string("dataset"))
                                {
                                    //camId,{func,strtaskId}
                                    std::unordered_map<int,std::unordered_map<std::string, std::string>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.facedatasetpath_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.facedatasetpath_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in facedatasetpath_conf_map,camId:" <<camId<<"new to facedatasetpath_conf_map";
                                        std::unordered_map<std::string, std::string> mapp = { {funcname , paramvalue.GetString()} };
                                        globalJsonConfObjNotApplied.facedatasetpath_conf_map.insert(std::pair<int, std::unordered_map<std::string, std::string >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::string>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, std::string>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::string  >(funcname,paramvalue.GetString()));
                                        }
                                        else
                                        {
                                            std::string& curValue =  got_id_func_cap2->second ;
                                            curValue = paramvalue.GetString();
                                        }
                                    }

                                }

                                if(paramname == std::string("eventUrl"))
                                {
                                    //camId,{func,strtaskId}
                                    std::unordered_map<int,std::unordered_map<std::string, std::string>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.eventUrl_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.eventUrl_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in eventUrl_conf_map,camId:" <<camId<<"new to eventUrl_conf_map";
                                        std::unordered_map<std::string, std::string> mapp = { {funcname , paramvalue.GetString()} };
                                        globalJsonConfObjNotApplied.eventUrl_conf_map.insert(std::pair<int, std::unordered_map<std::string, std::string >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::string>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, std::string>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::string  >(funcname,paramvalue.GetString()));
                                        }
                                        else
                                        {
                                            std::string& curValue =  got_id_func_cap2->second ;
                                            curValue = paramvalue.GetString();
                                        }
                                    }

                                }

                                if(paramname == std::string("startCondition"))
                                {
                                    //This is for absence function's startCondition 
                                    //camId,{func,startCondition}
                                    std::unordered_map<int,std::unordered_map<std::string, std::string>  >::iterator got_id_func_cap = globalJsonConfObjNotApplied.absenceStartConition_conf_map.find(camId);

                                    if (got_id_func_cap == globalJsonConfObjNotApplied.absenceStartConition_conf_map.end())
                                    {
                                        ANNIWOLOG(INFO) << "not found in absenceStartConition_conf_map,camId:" <<camId<<"new to absenceStartConition_conf_map";
                                        std::unordered_map<std::string, std::string> mapp = { {funcname , paramvalue.GetString()} };
                                        globalJsonConfObjNotApplied.absenceStartConition_conf_map.insert(std::pair<int, std::unordered_map<std::string, std::string >  >( camId, std::move(mapp) ) );
                                    }
                                    else
                                    {
                                        std::unordered_map<std::string, std::string>& conf_map =got_id_func_cap->second;
                                        std::unordered_map<std::string, std::string>::iterator got_id_func_cap2 = conf_map.find(funcname);
                                        if (got_id_func_cap2 == conf_map.end())
                                        {
                                            conf_map.insert(std::pair<std::string, std::string  >(funcname,paramvalue.GetString()));
                                        }
                                        else
                                        {
                                            std::string& curValue =  got_id_func_cap2->second ;
                                            curValue = paramvalue.GetString();
                                        }
                                    }    

                                }
                                
                                


                            }
                            else
                            {
                                ANNIWOLOG(INFO) <<"paramvalue is UNKOWN type"<<std::endl;

                            }

                        }
                    } 


                }
            

              }
            }
        }


    uniqueLock.unlock();

    
    ANNIWOLOG(INFO) << "read json:globalJsonConfObjNotApplied.validperoids_week_map.size():" <<globalJsonConfObjNotApplied.validperoids_week_map.size();
    ANNIWOLOG(INFO) << "read json:globalJsonConfObjNotApplied.validArea_conf_map.size():" <<globalJsonConfObjNotApplied.validArea_conf_map.size();

    //std::unordered_map<int,std::unordered_map<std::string, Polygon>  >
    for(auto& itempair:globalJsonConfObjNotApplied.validArea_conf_map)
    {
        // cout<<kv.first<<kv.second<<endl;
        int camId = itempair.first;
        auto& funcAreaMap = itempair.second;

        for(auto& funcAreaItem:funcAreaMap)
        {
            auto& funcname = funcAreaItem.first;
            auto& polygonSafeArea = funcAreaItem.second;

            std::stringstream buffer;  
            for(int i=0; i < polygonSafeArea.size(); i++)
            {
                const cv::Point& pt=polygonSafeArea.pt[i];
                buffer << pt.x<<","<<pt.y<<" ";  
            }
            std::string text(buffer.str());

            ANNIWOLOG(INFO) << "read json:validArea_conf_map,camId:" <<camId<<" func:"<<funcname<<" validArea:"<<text;

        }

    }




}


int main(int argc, char *argv[])
{
    
    //////////////Init g3 log custom sink for mine,此处参数未使用////////////////////
    const std::string path_to_log_file = "../";
    const std::string log_file = "";

    std::unique_ptr<g3::LogWorker> logworker {g3::LogWorker::createLogWorker()};

    
    // auto handle = logworker->addDefaultLogger(log_file, path_to_log_file);
    // g3::initializeLogging(logworker.get());


   auto sinkHandle = logworker->addSink(std::make_unique<LogRotate>(log_file,path_to_log_file),
                                          &LogRotate::save);
   
   // initialize the logger before it can receive LOG calls
   initializeLogging(logworker.get());                        

    /////////////////////////////////////////////////////////////////////////////////////
    srand((unsigned)time(NULL));//初始化种子

    //////////////////////////////////////////

    //read the ini file
    mINI::INIFile file("../config.ini");
    mINI::INIStructure ini;

    if(!  file.read(ini))
    {
        ANNIWOLOG(INFO) << "Error no ini file!" ;
        return -1;
    }

    if(ini.has("config"))
    {
        if(ini["config"].has("inusefunctions"))
        {
            std::string strvalue = ini.get("config").get("inusefunctions");
            std::vector<std::string> strVector = stringSplit(strvalue, ' '); 
            for (auto f : strVector)
            {
                std::unordered_set<std::string>::const_iterator got_conf_functions = all_conf_functions.find(f);

                if (got_conf_functions == all_conf_functions.end())
                {
                    ANNIWOLOG(INFO) <<"ini f is not valid.ignored!"<<f;
                    continue;
                }
                else
                {
                    globalINICONFObj.in_use_conf_functions.emplace(f);
                }
            }

        }else
        {
            ANNIWOLOG(INFO) << "Error no inusefunctions setting in ini file!" ;
            ANNIWOCHECK(false);
            exit(-1);

        }

        globalINICONFObj.domain_config=ANNIWO_DOMANI_LIANGKU;
        if(ini["config"].has("domain"))
        {
            std::string strvalue = ini.get("config").get("domain");
            std::vector<std::string> strVector = stringSplit(strvalue, ' '); 
            if(strVector[0]=="jiayouzhan")
            {
                globalINICONFObj.domain_config=ANNIWO_DOMANI_JIAYOUZHAN;
                ANNIWOLOG(INFO) <<"domain_config:  "<<"jiayouzhan"<<std::endl;

            }else
            {
                ANNIWOLOG(INFO) <<"domain_config:  "<<"jiayouzhan"<<std::endl;
            }

        }
        
    }
    if(ini.has("path"))
    {

        //创建根图片输出目录
        std::string tmpPath=std::string("/var/anniwo/");

        struct stat st = {0};
        //创建目录
        if (stat(tmpPath.c_str(), &st) == -1) {
            mkdir(tmpPath.c_str(), 0700);
        }
        //检查是否创建成功
        if (stat(tmpPath.c_str(), &st) == -1) {
            ANNIWOLOG(INFO) <<"Unable to create:"<<tmpPath<<std::endl;
            ANNIWOCHECK(false);
            exit(-1);
        }

        //////////////////////////////////////

        if(ini["path"].has("onlineCollectionPath"))
        {
            std::string strvalue = ini.get("path").get("onlineCollectionPath");
            std::vector<std::string> strVector = stringSplit(strvalue, ' '); 

            //todo
            globalINICONFObj.onlineCollectionPath=strVector[0];
            if(globalINICONFObj.onlineCollectionPath.length() > 5)
            {
                //标识目录
                if(globalINICONFObj.onlineCollectionPath.back() != '/')
                {
                    globalINICONFObj.onlineCollectionPath.push_back('/');
                }


                struct stat st = {0};
                //创建目录
                if (stat(globalINICONFObj.onlineCollectionPath.c_str(), &st) == -1) {
                    mkdir(globalINICONFObj.onlineCollectionPath.c_str(), 0700);
                }
                //检查是否创建成功
                if (stat(globalINICONFObj.onlineCollectionPath.c_str(), &st) == -1) {
                    ANNIWOLOG(INFO) <<"Unable to create:"<<globalINICONFObj.onlineCollectionPath<<std::endl;
                    ANNIWOCHECK(false);
                    exit(-1);
                }



            }

        }
    }

    //阈值配置
    if(ini.has("theshold"))
    {
        //todo:遍历key,value

        if(ini["theshold"].has("helmet"))
        {
            std::string strvalue = ini.get("theshold").get("helmet");
            
            std::istringstream isb_str(strvalue);
            float fvalue = 1.0;
	        isb_str >> fvalue;

            std::string f("helmet");
            std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(f);

            if (got_theshold == globalINICONFObj.thesholdsetting.end())
            {
                ANNIWOLOG(INFO) <<"ini:f is not thesholdsetting....make one.f: "<<f<<" value:"<<fvalue ;
                std::pair<std::string, float> settingpair(f,fvalue);

                globalINICONFObj.thesholdsetting.insert(std::move(settingpair));
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:f is already in thesholdsetting....CHECK your ini, ignored. "<<f;
            }
        }

        if(ini["theshold"].has("jyzxunjian_jiayouji"))
        {
            std::string strvalue = ini.get("theshold").get("jyzxunjian_jiayouji");
            
            std::istringstream isb_str(strvalue);
            float fvalue = 1.0;
	        isb_str >> fvalue;

            std::string f("jyzxunjian_jiayouji");
            std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(f);

            if (got_theshold == globalINICONFObj.thesholdsetting.end())
            {
                ANNIWOLOG(INFO) <<"ini:f is not thesholdsetting....make one.f: "<<f<<" value:"<<fvalue ;
                std::pair<std::string, float> settingpair(f,fvalue);

                globalINICONFObj.thesholdsetting.insert(std::move(settingpair));
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:f is already in thesholdsetting....CHECK your ini, ignored. "<<f;
            }
        }

        if(ini["theshold"].has("jyzxunjian_rkj"))
        {
            std::string strvalue = ini.get("theshold").get("jyzxunjian_rkj");
            
            std::istringstream isb_str(strvalue);
            float fvalue = 1.0;
	        isb_str >> fvalue;

            std::string f("jyzxunjian_rkj");
            std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(f);

            if (got_theshold == globalINICONFObj.thesholdsetting.end())
            {
                ANNIWOLOG(INFO) <<"ini:f is not thesholdsetting....make one.f: "<<f<<" value:"<<fvalue ;
                std::pair<std::string, float> settingpair(f,fvalue);

                globalINICONFObj.thesholdsetting.insert(std::move(settingpair));
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:f is already in thesholdsetting....CHECK your ini, ignored. "<<f;
            }
        }


    }


    //检测线程数目阈值配置
    if(ini.has("threads"))
    {
        //todo:遍历key,value
        globalINICONFObj.ANNIWO_NUM_THREAD_PERSONBASE=8;

        if(ini["threads"].has("personbaseInstance"))
        {
            std::string strvalue = ini.get("threads").get("personbaseInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_PERSONBASE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.personbaseInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }
    
        globalINICONFObj.ANNIWO_NUM_THREAD_FIRE=8;

        if(ini["threads"].has("fireInstance"))
        {
            std::string strvalue = ini.get("threads").get("fireInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_FIRE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.fireInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_WINDOW=8;
        if(ini["threads"].has("windowInstance"))
        {
            std::string strvalue = ini.get("threads").get("windowInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_WINDOW=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.windowInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_THREAD_UPTRUCK=1;
        if(ini["threads"].has("uptruck"))
        {
            std::string strvalue = ini.get("threads").get("uptruck");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_UPTRUCK=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.uptruck should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_THREAD_HELMET=8;
        if(ini["threads"].has("helmetInstance"))
        {
            std::string strvalue = ini.get("threads").get("helmetInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_HELMET=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.helmetInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_CONVERY=8;
        if(ini["threads"].has("converyInstance"))
        {
            std::string strvalue = ini.get("threads").get("converyInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_CONVERY=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.converyInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_SMOKEPHONE=8;

        if(ini["threads"].has("smokephoneInstance"))
        {
            std::string strvalue = ini.get("threads").get("smokephoneInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_SMOKEPHONE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.smokephoneInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_SAFEAREA=8;
        if(ini["threads"].has("safeErea"))
        {
            std::string strvalue = ini.get("threads").get("safeErea");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_SAFEAREA=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.safeErea should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN=8;
        if(ini["threads"].has("xunjian"))
        {
            std::string strvalue = ini.get("threads").get("xunjian");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.xunjian should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_ZXY=8;
        if(ini["threads"].has("zhuangxieyou"))
        {
            std::string strvalue = ini.get("threads").get("zhuangxieyou");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_ZXY=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.zhuangxieyou should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI=8;
        if(ini["threads"].has("chepai"))
        {
            std::string strvalue = ini.get("threads").get("chepai");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.chepai should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_THREAD_MASK=8;
        if(ini["threads"].has("mask"))
        {
            std::string strvalue = ini.get("threads").get("mask");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_THREAD_MASK=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.mask should bigger than 1...CHECK your ini, ignored. ";
            }
        }

    }else
    {
        globalINICONFObj.ANNIWO_NUM_THREAD_PERSONBASE=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_FIRE=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_WINDOW=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_HELMET=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_CONVERY=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_SMOKEPHONE=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_SAFEAREA=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_ZXY=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_MASK=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI=8;
        globalINICONFObj.ANNIWO_NUM_THREAD_UPTRUCK=1;
        
    }


    //检测GPU实例(context)占用数目阈值配置
    if(ini.has("gpuoccupy"))
    {
        //todo:遍历key,value
        globalINICONFObj.ANNIWO_NUM_INSTANCE_PERSONBASE=1;

        if(ini["gpuoccupy"].has("personbaseInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("personbaseInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_PERSONBASE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.personbaseInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }
    
        globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE=1;

        if(ini["gpuoccupy"].has("fireInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("fireInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.fireInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_WINDOW=1;
        if(ini["gpuoccupy"].has("windowInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("windowInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_WINDOW=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.windowInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        
        globalINICONFObj.ANNIWO_NUM_INSTANCE_UPTRUCK=1;
        if(ini["gpuoccupy"].has("uptruck"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("uptruck");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_UPTRUCK=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.uptruck should bigger than 1...CHECK your ini, ignored. ";
            }
        }
        
        
        
        
        globalINICONFObj.ANNIWO_NUM_INSTANCE_HELMET=1;
        if(ini["gpuoccupy"].has("helmetInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("helmetInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_HELMET=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.helmetInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_CONVERY=1;
        if(ini["gpuoccupy"].has("converyInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("converyInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_CONVERY=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.converyInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_SMOKEPHONE=1;

        if(ini["gpuoccupy"].has("smokephoneInstance"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("smokephoneInstance");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_SMOKEPHONE=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.smokephoneInstance should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_SAFEAREA=1;
        if(ini["gpuoccupy"].has("safeErea"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("safeErea");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_SAFEAREA=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.safeErea should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN=1;
        if(ini["gpuoccupy"].has("xunjian"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("xunjian");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.xunjian should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_ZXY=1;
        if(ini["gpuoccupy"].has("zhuangxieyou"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("zhuangxieyou");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_ZXY=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.zhuangxieyou should bigger than 1...CHECK your ini, ignored. ";
            }
        }

        globalINICONFObj.ANNIWO_NUM_INSTANCE_CHEPAI=1;
        if(ini["gpuoccupy"].has("chepai"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("chepai");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_CHEPAI=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.chepai should bigger than 1...CHECK your ini, ignored. ";
            }
        }


        globalINICONFObj.ANNIWO_NUM_INSTANCE_MASK=1;
        if(ini["gpuoccupy"].has("mask"))
        {
            std::string strvalue = ini.get("gpuoccupy").get("mask");
            
            std::istringstream isb_str(strvalue);
            int ivalue = 0;
	        isb_str >> ivalue;


            if (ivalue > 0)
            {
                globalINICONFObj.ANNIWO_NUM_INSTANCE_MASK=ivalue;
            }else
            {
                //duplicated setting in config!
                ANNIWOLOG(INFO) <<"ini:performance.mask should bigger than 1...CHECK your ini, ignored. ";
            }
        }

    }else
    {

        globalINICONFObj.ANNIWO_NUM_INSTANCE_PERSONBASE=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_WINDOW=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_HELMET=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_CONVERY=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_SMOKEPHONE=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_SAFEAREA=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_ZXY=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_MASK=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_CHEPAI=1;
        globalINICONFObj.ANNIWO_NUM_INSTANCE_UPTRUCK=1;


    }




    if(globalINICONFObj.in_use_conf_functions.size() > 0)
    {
        ANNIWOLOG(INFO) <<"in use functions:";

        std::string tmpPath;

        //创建根图片输出目录
        tmpPath=std::string("/var/anniwo/images/");

        struct stat st = {0};
        //创建目录
        if (stat(tmpPath.c_str(), &st) == -1) {
            mkdir(tmpPath.c_str(), 0700);
        }
        //检查是否创建成功
        if (stat(tmpPath.c_str(), &st) == -1) {
            ANNIWOLOG(INFO) <<"Unable to create:"<<tmpPath<<std::endl;
            ANNIWOCHECK(false);
            exit(-1);
        }


        for (auto& item:globalINICONFObj.in_use_conf_functions) 
        {
            ANNIWOLOG(INFO) <<item<<" ";

            //创建所有图片输出目录
            if(item == "fire")
            {
                tmpPath=std::string("/var/anniwo/images/")+"firesmog";
            }else
            {
                tmpPath="/var/anniwo/images/"+item;
            }

            struct stat st = {0};
            //创建目录
            if (stat(tmpPath.c_str(), &st) == -1) {
                mkdir(tmpPath.c_str(), 0700);
            }
            //检查是否创建成功
            if (stat(tmpPath.c_str(), &st) == -1) {
                ANNIWOLOG(INFO) <<"Unable to create:"<<tmpPath<<std::endl;
                ANNIWOCHECK(false);
                exit(-1);
            }

        }
        ANNIWOLOG(INFO) <<"  "<<std::endl;

    }
    else
    {
        ANNIWOLOG(INFO) <<"No in use function,ignore!";
        ANNIWOCHECK(false);
    }


    ANNIWOLOG(INFO) << "server start! version:" << VERSION ;


    crow::App<ExampleMiddleware> app;

    crow::logger::setLogLevel(crow::LogLevel::DEBUG);

    app.get_middleware<ExampleMiddleware>().setMessage("hello anniwo");

    // simple json response
    // To see it in action enter {ip}:18080/json
    CROW_ROUTE(app, "/engineStart")
    ([]{

        crow::json::wvalue x;
        x["message"] = "Now (re)start engine!";

        engineStart();

        return x;
    });

        // A simpler way for json example:
    //      * curl -d '{"a":1,"b":2}' {ip}:18080/add_json
    CROW_ROUTE(app, "/managerMent")
        .methods("POST"_method)
    ([](const crow::request& req){



        managerMent(req.body);

        std::ostringstream os;
        os << "Configuration accept!";
        return crow::response{os.str()};
    });

    app.port(5000)
        .multithreaded()
        .run();
}
