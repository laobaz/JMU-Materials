#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "window.hpp"


static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;






static const int NUM_CLASSES = 3;
static const float BBOX_CONF_THRESH = 0.35;
static const int NUM_CLASSES_INUSE = 3;
//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);

static const std::vector<std::string>  class_names = {
    "work_sign",
    "windows_open",
    "windows_close"
};



const static std::string model_file={"../models/window/best_windowssign_sim.trt"};
static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};
static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;


static int gpuNum = 0;



const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf


std::unordered_map<int, std::vector<float> >  WindowDetection::m_input_datas;


static std::unordered_map<int, std::vector<Object> > allLastObjects ;


// Default constructor
WindowDetection::WindowDetection () { 
    ANNIWOLOG(INFO) << "WindowDetection(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "WindowDetection(): Success initialized!" ;

}

// Destructor
WindowDetection::~WindowDetection () 
{
    // destroy the engine
    delete engine;
    delete runtime;
}



static void PostProcessResults(int camID, cv::Mat  bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{


    cv::Mat image = bgr;
    bgr.release();

	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;
    writer.StartArray();    
    std::vector<Object> filteredObjects;


    if(objects.size() <= 0)
    {
        ANNIWOLOG(INFO) <<"windowDetection:objects size 0,camID:"<<camID;
    }

    // std::vector<std::vector<float>> results ;
    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];

        // 1:windows_open
        if(obj.label == 1 )
        {
            ANNIWOLOGF(INFO, "WindowDetection: camID:%d %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                camID,  class_names[obj.label].c_str(), obj.prob,
                obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);

            int x1=obj.rect.x;
            int y1 = obj.rect.y;
            int x2=(obj.rect.x+obj.rect.width) >  image.cols ? image.cols  : (obj.rect.x+obj.rect.width) ;
            int y2 =(obj.rect.y+obj.rect.height) >  image.rows ? image.rows : (obj.rect.y+obj.rect.height);

            // results.push_back({x1,y1,x2,y2,obj.prob,int(obj.label)});

            if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
            {
                box_poly.clear();
                box_poly.add(cv::Point(int(x1),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y2)));
                box_poly.add(cv::Point(int(x1),int(y2)));
                _inter.clear();
                intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
                if( _inter.size() ) {
                    float area = _inter.area();
                    // cv::Point center = _inter.getCenter();
                    ANNIWOLOG(INFO) <<"WindowDetection: Area intersected = "<<area<<",camID:"<<camID;

                    // if(area > 10.0)
                    if(area >= box_poly.area()-10.0)//交叠部分等于自身，说明在其内部
                    {
                        
                        ANNIWOLOG(INFO) <<
                        "WindowDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<class_names[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;


                    }else
                    {
                        continue;
                    }


                }else
                {
                    ANNIWOLOG(INFO) <<"WindowDetection: Area intersected None "<<"camID:"<<camID;
                    continue;
                }
            }

            filteredObjects.push_back(obj);

            writer.StartObject();               // Between StartObject()/EndObject(), 

            writer.Key("y1");                
            writer.Int(y1);            
            writer.Key("x1");                
            writer.Int(x1);  
            writer.Key("y2");                
            writer.Int(y2);  
            writer.Key("x2");                
            writer.Int(x2);  
            writer.Key("classItem");                // output a key,
            writer.String(class_names[obj.label].c_str());             // follow by a value.
        

            writer.EndObject();

            jsonObjCnt++;


#ifdef ANNIWO_INTERNAL_DEBUG
            ////////////////////////////////////////////////////////////////////////////////
            //todo:Below is leave for debugging! 描绘部分!
            cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
            float c_mean = cv::mean(color)[0];
            cv::Scalar txt_color;
            if (c_mean > 0.5){
                txt_color = cv::Scalar(0, 0, 0);
            }else{
                txt_color = cv::Scalar(255, 255, 255);
            }

            cv::rectangle(image, obj.rect, color * 255, 2);

            char text[256];
            sprintf(text, "%s %.1f%%", class_names[obj.label].c_str(), obj.prob * 100);

            int baseLine = 0;
            cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

            cv::Scalar txt_bk_color = color * 0.7 * 255;

            int x = obj.rect.x;
            int y = obj.rect.y + 1;
            if (y > image.rows)
                y = image.rows;

            cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                        txt_bk_color, -1);

            cv::putText(image, text, cv::Point(x, y + label_size.height),
                        cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
            ////////////////////////////////////////////////////////////////////////////////
#endif
        }


    }




    writer.EndArray();

    if(filteredObjects.size() <= 0)
    {
        ANNIWOLOG(INFO) <<"windowDetection:filteredObjects size 0,camID:"<<camID;
    }else
    {
        if(isResultDuplicated(allLastObjects[camID],filteredObjects))
        {
            ANNIWOLOG(INFO) <<"WindowDetection:Duplicated results.Ignored.camID:"<<camID<<std::endl;
            allLastObjects[camID]=filteredObjects;

            return;
        }
    }

    //update history results
    allLastObjects[camID]=filteredObjects;


    if(jsonObjCnt > 0)
    {
        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/window/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/window"};

        getTaskId(globalJsonConfObjPtr,camID,"window",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"window","/window",submitUrl);

        ANNIWOLOG(INFO) <<"windowDetection:save file name drawed is:"<<imgPath<<",camID:"<<camID<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }


}







void WindowDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    allLastObjects.clear();
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);


    globalJsonConfObjPtr=&globalJsonConfObj;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("window"))
            {

                std::vector<Object> emptyObjArray;
                ANNIWOLOG(INFO) << "WindowDetection::initTracks:allLast insert" <<"camID:"<<camID<<" ";
                allLastObjects.insert(std::pair<int, std::vector<Object>  >(camID,emptyObjArray) );

                break;
            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_WINDOW;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }


    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_FIRE个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_WINDOW)
    {
        ANNIWOLOG(INFO) << "WindowDetection::initTracks insert instance" <<"cntID:"<<cntID<<" ";

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }



 }
//todo:polygonSafeArea
void WindowDetection::detect(  int camID, int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr) 
{    

    std::vector<Object> objects;
    cudaSetDevice(gpuNum);


    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_WINDOW);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    if (iterCamInstance != executionContexts.end()) 
    {

        yolov4_detection_staff(m_input_datas,camID,instanceID,img,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "WindowDetection");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }

    if(objects.size() > 0)
    {
        PostProcessResults(camID, img, objects,polygonSafeArea_ptr);
    }
    else
    {
        ANNIWOLOG(INFO) << "WindowDetection:no objects" ;
    }


    
    ANNIWOLOG(INFO) << "WindowDetection:exit detect()" ;


    return;
}
