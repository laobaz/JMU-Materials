#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "uptruck_items.hpp"





static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;


static const int NUM_CLASSES = 5;
static const float BBOX_CONF_THRESH = 0.29;

static const int NUM_CLASSES_INUSE = 5;

//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);



const std::vector<std::string>  class_names_uptruckitems = {
"work_clothe_blue",
"work_clothe_cobalt",
"tank_truck",
"weilan",
"helmet"
};


static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};
static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;


static int gpuNum = 0;


//todo
const static std::string model_file={"../models/jyz_chedingzy/chedingzr/jyz_chedingzr_sim.trt"};



const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf


std::unordered_map<int, std::vector<float> >  Uptruckitems::m_input_datas;




Uptruckitems::Uptruckitems () { 

    ANNIWOLOG(INFO) << "Uptruckitems(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "Uptruckitems(): Success initialized!" ;
}

// Destructor
Uptruckitems::~Uptruckitems () 
{
    // destroy the engine
    delete engine;
    delete runtime;
}






void Uptruckitems::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);

    globalJsonConfObjPtr=&globalJsonConfObj;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter)
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("uptruck"))
            {

                // std::vector<Object> emptyObjArray;
                ANNIWOLOG(INFO) << "Uptruckitems::initTracks: insert" <<"camID:"<<camID<<" ";

                break;
            }
            else
            {
                continue;
            }
        }
    }


    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_UPTRUCK;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }


    int cntID=0;
    //ANNIWO_NUM_THREAD_UPTRUCK
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_UPTRUCK)
    {
        ANNIWOLOG(INFO) << "Uptruckitems::initTracks: insert instance" <<"cntID:"<<cntID;

//////////////////Predictor clone to each camID    

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }

 }
//todo:polygonSafeArea
void Uptruckitems::detect(  int camID,int instanceID, cv::Mat img, std::vector<Object>& objects)  
{    

    cudaSetDevice(gpuNum);

    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_UPTRUCK);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    if (iterCamInstance != executionContexts.end()) 
    {

        yolov4_detection_staff(m_input_datas,camID,instanceID,img,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "Uptruckitems");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }

    if(objects.size() > 0 && objects.size() < 100)
    {
        //nothing
    }
    else
    {
        ANNIWOLOG(INFO) << "Uptruckitems:no objects.objects.size():" << objects.size() <<"camID:"<<camID <<"instanceID:"<<instanceID ;
    }

    
    ANNIWOLOG(INFO) << "Uptruckitems:exit detect()" <<"camID:"<<camID <<"instanceID:"<<instanceID ;


    return;
}
