#ifndef YOLOX_ORBMATCH_H
#define YOLOX_ORBMATCH_H
#include <opencv2/opencv.hpp>


void orbsimilary_mainfunc(cv::Mat image1,cv::Mat image2, float& similaryOut );

#endif 