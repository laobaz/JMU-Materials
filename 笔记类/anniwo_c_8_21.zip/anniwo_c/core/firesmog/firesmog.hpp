#ifndef YOLOX_FIRESMOG_H
#define YOLOX_FIRESMOG_H
#include <opencv2/opencv.hpp>
#include <unordered_set>
#include <unordered_map>
#include "../utils/utils_intersection.hpp"
#include "../common/yolo/yolo_common.hpp"



class FireDetection  {
    public:
        FireDetection(const std::string& in_onlineSavePath) ;
        ~FireDetection() ;

        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);
        //todo:polygonSafeArea
        static void detect(  int camID,int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr);
    private:
        static  std::unordered_map<int, std::vector<float> >  m_input_datas;

    // private:
        
};

#endif 

