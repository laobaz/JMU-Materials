#ifndef YOLOX_FIRESMOG_FLSTM_H
#define YOLOX_FIRESMOG_FLSTM_H
#include <opencv2/opencv.hpp>
#include <unordered_set>
#include <unordered_map>
#include "../utils/utils_intersection.hpp"
#include "../common/yolo/yolo_common.hpp"



class FireFLSTM  {
    public:
        FireFLSTM() ;
        ~FireFLSTM() ;

        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);

        static void detect(  int camID,int instanceID, std::vector<float>& inputStream, std::vector<float>& outresults );
    private:
        static  std::unordered_map<int, std::vector<float> >  m_input_datas;
        
};

#endif 

