#include "orb_match.hpp"
#include <iostream>
#include <opencv2/features2d.hpp>


void extracte_orb(cv::Mat input, std::vector<cv::KeyPoint>& keypoint, cv::Mat descriptor)
{
    cv::Ptr<cv::ORB> f2d = cv::ORB::create();
    f2d->detect(input, keypoint);
    f2d->compute(input, keypoint, descriptor);
}

void match_two_image(cv::Mat image1, cv::Mat image2, std::vector<cv::KeyPoint> keypoint1, std::vector<cv::KeyPoint> keypoint2, 
    cv::Mat descriptor1, cv::Mat descriptor2,float& similaryOut) 
{
    cv::BFMatcher matcher(cv::NORM_HAMMING);
    std::vector<std::vector< cv::DMatch >> matches;


    matcher.knnMatch(descriptor2, descriptor1, matches, 2);
    
    std::vector< cv::DMatch > good_matches;
    for (int i = 0; i < matches.size(); i ++) {
        float rejectRatio = 0.75;
        if (matches[i][0].distance / matches[i][1].distance > rejectRatio)
            continue;
        good_matches.push_back(matches[i][0]);
    }

    float similary = (float)good_matches.size()/(float)matches.size();
    // std::cout<<"Similary:"<<similary<<std::endl;
    similaryOut=similary;

}

void orbsimilary_mainfunc(cv::Mat image1,cv::Mat image2, float& similaryOut )
{
    cv::Mat src_gray1,src_gray2;
    cv::cvtColor( image1, src_gray1, cv::COLOR_BGR2GRAY ); // Convert the image to grayscale
    cv::cvtColor( image2, src_gray2, cv::COLOR_BGR2GRAY ); // Convert the image to grayscale

    std::vector<cv::KeyPoint> keypoint1, keypoint2;
    cv::Mat descriptor1, descriptor2;
    extracte_orb(src_gray1, keypoint1, descriptor1);
    extracte_orb(src_gray2, keypoint2, descriptor2);
    match_two_image(src_gray1, src_gray2, keypoint1, keypoint2, descriptor1, descriptor2,similaryOut);
}
