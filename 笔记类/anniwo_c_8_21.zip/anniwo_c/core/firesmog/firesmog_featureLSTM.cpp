#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <deque>
#include <algorithm>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>


#include "firesmog_featureLSTM.hpp"


#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"


static const std::vector<std::string>  class_names = {
"background",
"fire",
"smog"
};




static const int NUM_CLASSES_INUSE = 3;

static const int NUM_CLASSES = 3;



const int batch_size = 1;
const int seq_length = 5;
const int inputdims=1280;
static std::vector<int> input_shape = {batch_size, seq_length, inputdims};    

int net_out_size = 3;

static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};

static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;
const static std::string model_file={"../models/firesmog_r/fire_lm.trt"};


std::unordered_map<int, std::vector<float> >  FireFLSTM::m_input_datas;



// Default constructor
FireFLSTM::FireFLSTM () { 

    ANNIWOLOG(INFO) << "FireLM(): Success initialized!" ;

    ANNIWOLOG(INFO) << "FireLM(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "FireLM(): Success initialized!" ;

}

// Destructor
FireFLSTM::~FireFLSTM () {

    // destroy the engine
    delete engine;
    delete runtime;

}




void FireFLSTM::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter)
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f ==  std::string("fire"))
            {
                ANNIWOLOG(INFO) << "FireLM::initTracks: insert" <<"camID:"<<camID<<" ";

                break;
            }
            else
            {
                continue;
            }
        }
    }

    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_FIRE个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_FIRE)
    {
        ANNIWOLOG(INFO) << "FireLM::initTracks: insert instance" <<"cntID:"<<cntID;

        std::vector<float> input_data(batch_size*seq_length*inputdims);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

        cntID++;
    }

    executionContexts.clear();
    contextlocks.clear();
    cudaSetDevice(gpuNum);

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }

}


void FireFLSTM::detect(  int camID,int instanceID,  std::vector<float>& inputStream, std::vector<float>& outresults ) 
{    


    ANNIWOCHECK(inputStream.size() == batch_size * seq_length * inputdims);

    ANNIWOLOG(INFO) << "FireLM:detect entered"<<"camID:"<<camID ;

    std::unordered_map<int, std::vector<float> >::iterator got_m_input_datas = m_input_datas.find(instanceID);

    if (got_m_input_datas == m_input_datas.end())
    {
        ANNIWOLOG(INFO) << "FireFeature:detect "<<"instanceID:"<<instanceID <<"NOT in predictors map!";
        ANNIWOCHECK(false);

        return ;
    }

    cudaSetDevice(gpuNum);


    std::vector<float> out_data( net_out_size, 0.0);


    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);
    ANNIWOCHECK(iterCamInstance != executionContexts.end()) ;

    // run inference
    auto start = std::chrono::system_clock::now();

    int inputStreamSize = batch_size*seq_length*inputdims;

    TrtGPUInfer(*iterCamInstance->second,gpuNum,*iterCamInstancelock->second, inputStream.data(), out_data.data(), net_out_size,
                inputStreamSize,  "lstm_1_input", "dense_2","FireLM:" );


    auto end = std::chrono::system_clock::now();
    ANNIWOLOG(INFO) <<"FireLM:infer time:" << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms,"<<"camID:"<<camID ;

    outresults=out_data;

    std::stringstream buffer;  
    for(float item:outresults)
    {
        buffer <<item<<",";  
    }
    std::string contents(buffer.str());

    ANNIWOLOG(INFO) << "FireLM:exit detect()" <<"camID:"<<camID<<"r net result:"<<contents;

    return;
}
