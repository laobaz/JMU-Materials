#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <deque>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>
#include <xtensor.hpp>

#include "firesmog.hpp"


#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"

#include "firesmog_classification.hpp"
#include "firesmog_mobilenetfeature.hpp"
#include "firesmog_featureLSTM.hpp"
#include "orb_match.hpp"



// static std::string submitUrlPrefix = {"http://localhost:7008/safety-event-local/socketEvent/"};
// static std::string submitUrl = submitUrlPrefix + "firesmog";
// static std::string taskId = ""



static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;

static std::unordered_map<int, std::vector<Object> > allLastObjects ;

static std::unordered_map<int, std::deque<ObjectHisSave> > allHisListMap ;

static const int NUM_CLASSES_INUSE = 4;

static const int NUM_CLASSES = 4;
// static const float BBOX_CONF_THRESH = 0.58; //yolox
static const float BBOX_CONF_THRESH = 0.1;  //yolov4

//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);

// "background",
// "fire",
// "lazhu",
// "dahuoji",
// "huochai",
// "smog",
// "light"
static const std::vector<std::string>  class_names = {
    "background",
    "fire",
    "smog",
    "light"
};


static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};

static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;



const static std::string model_file={"../models/firesmog/best_model_firesmog_sim.trt"};



const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf

std::unordered_map<int, std::vector<float> >  FireDetection::m_input_datas;
static std::string onlineSavePath={""};


static FireClassification *fireclassier = nullptr;
//todo:同一个mobilenet同时出feature和分类结果
static FireFeature *firefeatureExtractor = nullptr;
static FireFLSTM *fireRnnclassier = nullptr;

// Default constructor
FireDetection::FireDetection (const std::string& in_onlineSavePath) { 

    fireclassier= new FireClassification();
    firefeatureExtractor= new FireFeature();
    fireRnnclassier = new FireFLSTM();


    onlineSavePath = in_onlineSavePath;
    onlineSavePath = onlineSavePath+ "/firesmog/";

    struct stat st = {0};
    //创建目录
    if (stat(onlineSavePath.c_str(), &st) == -1) {
        mkdir(onlineSavePath.c_str(), 0700);
    }
    //检查是否创建成功
    if (stat(onlineSavePath.c_str(), &st) == -1) {
        ANNIWOLOG(INFO) <<"Unable to create:"<<onlineSavePath<<std::endl;
        ANNIWOCHECK(false);
        exit(-1);
    }

    

    ANNIWOLOG(INFO) << "FireDetection(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "FireDetection(): Success initialized!" ;



}

// Destructor
FireDetection::~FireDetection () {

    // destroy the engine
    delete engine;
    delete runtime;


}



static void main_func(int camID,int instanceID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{


    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;
    writer.StartArray();    

    std::vector<Object> filteredObjects;

    int fire_h=0;
    int fire_w=0;
    float inter_area=0.0;
    float union_area =0.0;


    std::unordered_map<int, std::deque<ObjectHisSave> >::iterator got_id_func_cap = allHisListMap.find(camID);

    if (got_id_func_cap == allHisListMap.end())
    {
        ANNIWOLOG(INFO) << "FireDetection.main_func ERROR: allHisListMap,camID:" <<camID;
        ANNIWOCHECK(false);

    }

    std::deque<ObjectHisSave>& hisList =got_id_func_cap->second;
    

    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];
        //todo:正常情况下一般只有一丛火，如目标数目大于1，只取第一个。
        if(i>0)
        {
            ANNIWOLOG(INFO) <<"FireDetection:WARN:more than 1 results.Ignored more.camID:"<<camID<<std::endl;
            break;
        }



        if( class_names[obj.label] == std::string("fire") || class_names[obj.label] == std::string("smog") )
        {
            ANNIWOLOGF(INFO, "FireDetection: camID:%d  %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
             camID,  class_names[obj.label].c_str(), obj.prob, obj.rect.x, obj.rect.y,
             obj.rect.width, obj.rect.height);

            int x1=obj.rect.x;
            int y1 = obj.rect.y;
            int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
            int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);
            if(x2 <= x1 || y2 <= y1)
            {
                continue;
            }


            if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
            {
                box_poly.clear();
                box_poly.add(cv::Point(int(x1),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y2)));
                box_poly.add(cv::Point(int(x1),int(y2)));
                _inter.clear();
                intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
                if( _inter.size() ) {
                    float area = _inter.area();

                    ANNIWOLOG(INFO) <<"FireDetection: Area intersected = "<<area<<",box_poly="<<box_poly.area()<<"camID:"<<camID;

                    // if(area > 10.0)
                    if(area >= box_poly.area()-10.0)//交叠部分等于自身，说明在其内部
                    {

                        ANNIWOLOG(INFO) <<
                        "FireDetection: detect:check box:"<<obj.rect.x<<","<< obj.rect.y<<","<< obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<class_names[obj.label].c_str()<<"intersectArea:"<<area<<" camID:"<<camID;

                    }else
                    {
                        ANNIWOLOG(INFO) <<"FireDetection: Not in Area intersected"<<"camID:"<<camID;
                        continue;
                    }


                }else
                {
                    ANNIWOLOG(INFO) <<"FireDetection: Area intersected none "<<"camID:"<<camID;
                    continue;
                }
            }else
            {
                //report all.
            }

/////////////////////////////////////////////////////////////////////////////////
            //hislist保存功能：保存切图，之后用于视频识别
            fire_h=y2-y1;
            fire_w=x2-x1;

            cv::Mat fire_img(fire_h, fire_w, CV_8UC3, cv::Scalar(114, 114, 114));
            image(cv::Rect(x1, y1, fire_w, fire_h)).copyTo(fire_img(cv::Rect(0, 0, fire_w, fire_h)));


            ////////////////////////////////////分类过滤/////////////////////////////////////////////
            //进行分类判断，仅通过分类判断的才认为是真正的火
            //分类模型检测
            //"background",
            // "fire",
            // "lazhu",
            // "dahuojihuochai",
            // "welding",
            // "smog"
            std::vector<float> mobilenetResults;
            cv::Mat fire_img2 = fire_img;
            //DEBUG:烟火显存占用尝试
            fireclassier->detect(camID,instanceID,fire_img2, mobilenetResults);
            
            if(mobilenetResults.size() >= 6)
            {
                //
                std::vector<std::size_t> gridwhshape = {6};
                //todo:注意！ auto 类型 xtensor adapt来的，reshape不能用！
                //               arrange来的，reshape也不能用!!!

                auto probs= xt::adapt(mobilenetResults,gridwhshape);
                auto mobilenetclass=xt::argmax(probs);
                ANNIWOLOG(INFO)<<"FireDetection: clsnet:"<<mobilenetclass <<",camID:"<<camID ;
                int predictcls=mobilenetclass(0);

                //DEBUG:烟火显存占用尝试
                // int predictcls=0;

                //background and welding ignore!!!
                if(predictcls == 0 || predictcls == 4 )
                {
                    ANNIWOLOG(INFO) << "FireDetection:detect "<<"camID:"<<camID <<"Res NOT ok,ignore.";
                    continue;
                }
                else if(obj.label == 1 && predictcls != 1 ) //"fire"
                {
                    ANNIWOLOGF(INFO, "FireDetection:IGNORED Not consistence camID:%d  %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f,predict cls:%d\n",
                        camID,  class_names[obj.label].c_str(), obj.prob, obj.rect.x, obj.rect.y,
                        obj.rect.width, obj.rect.height,predictcls);
                    continue;
                    
                }else if(obj.label == 5 && predictcls != 5 ) //"smog"
                {
                    ANNIWOLOGF(INFO, "FireDetection:IGNORED Not consistence camID:%d  %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f,predict cls:%d\n",
                        camID,  class_names[obj.label].c_str(), obj.prob, obj.rect.x, obj.rect.y,
                        obj.rect.width, obj.rect.height,predictcls);
                    
                    continue;

                }
            }
            else
            {
                ANNIWOLOG(INFO)<<"FireDetection:mobilenetResults.size unexpected! ";

                ANNIWOCHECK(false);
            }

            /////////////////////////////////////////////////////////////////////////////////


            hisList.push_back(ObjectHisSave{obj,fire_img});
            //hislist保存功能：iou过滤-第一次iou与上次差别很大时只保存，不报警
            if(hisList.size() >= 2 )
            {
               ObjectHisSave& lastItem = hisList.at(hisList.size()-1);
               ObjectHisSave& lastPrevItem = hisList.at(hisList.size()-2);
                //与box_det求ioa
                // intersection over union
                inter_area = intersection_area(lastItem, lastPrevItem);
                union_area = lastItem.detObj.rect.area() + lastPrevItem.detObj.rect.area() - inter_area;

                //hislist保存功能：iou过滤-第一次iou与上次差别很大时,删除之前的，只保存，不报警
                if(inter_area / union_area <= 0.5  )
                {
                    hisList.erase(hisList.begin(), hisList.end()-1);
                    ANNIWOLOG(INFO)<<"FireDetection:ignored 2 sampes because iou! ";

                    continue;//不报警
                }else
                {
                    //hislist保存功能：5个连续相同类别才报警一次,否则仅保存.
                    ANNIWOLOG(INFO)<<"FireDetection:samples-hisList.size: "<<hisList.size();
                    
                    if(hisList.size() >= 5) //仅此种情况报警
                    {

                        int cntit=0;
                        std::string debugimgname=getRandomName("");
                        std::vector<float> mobilenetFeaturesStream;
                        
                        cv::Mat prevcutpic;
                        std::vector<float> orbsimilaryVec;
                        for(ObjectHisSave& item:hisList)
                        {
                            //计算相似度
                            if(cntit==0)
                            {
                                prevcutpic=item.cutpic;
                            }else
                            {
                                float similary=100.0;
                                orbsimilary_mainfunc(prevcutpic,item.cutpic,similary);
                                prevcutpic=item.cutpic;
                                orbsimilaryVec.push_back(similary);
                            }
                            

                            std::stringstream buffer;  

                            buffer <<"_"<<cntit;  
                            std::string titlestr(buffer.str());

                            //////////////////////////////////////////////////////////////
                            //获得feature
                            std::vector<float> mobilenetFeature;
                            cv::Mat fire_img3 = item.cutpic;
                            firefeatureExtractor->detect(camID,instanceID, fire_img3, mobilenetFeature);

                            //将多个结果叠起来
                            //a.insert(a.end(), b.begin(), b.end());//b数组从开始到结尾复制到a的尾部
                            mobilenetFeaturesStream.insert(mobilenetFeaturesStream.end(), mobilenetFeature.begin(), mobilenetFeature.end());

                            /////////////////////////////////////////////////////////////////////////////////

                            //磁盘保存序列为素材
                            cv::imwrite(onlineSavePath+debugimgname+titlestr+".jpg",item.cutpic  );
                            cntit++;
                        }

                        //保存后清空.
                        hisList.clear();

                        //要求至少2个相似度小于0.2
                        int lowORBSimCnt=0;
                        std::stringstream orbdebugbuffer;  

                        for(int sc=0; sc<orbsimilaryVec.size(); sc++)
                        {
                            // if(orbsimilaryVec[sc] < 0.20)//严格,例如焦距远，三轮车着火这样的就大于0.3
                            if(orbsimilaryVec[sc] < 0.367)//例如灯光五角星这样的为0.22仍会误报
                            {
                                lowORBSimCnt++;
                            }
                            orbdebugbuffer <<orbsimilaryVec[sc]<<",";  

                        }

                        std::string orbdebugstr(orbdebugbuffer.str());
                        ANNIWOLOG(INFO) << "FireDetection:detect "<<"camID:"<<camID <<"orb for seq:"<<orbdebugstr;

                        if(lowORBSimCnt < 2)
                        {
                            ANNIWOLOG(INFO) << "FireDetection:detect "<<"camID:"<<camID <<"similary not OK, debug still continue.";

                            // continue;
                        }
                        
                        //////////////////////////////////调用lstm分类过滤/////////////////////////////////////////////
                        //进行序列分类判断，仅通过分类判断的才认为是真正的火
                        //序列分类模型检测
                        // 'background',
                        // 'fire',
                        // 'smog'
                        std::vector<float> lstmResults;

                        fireRnnclassier->detect(camID,instanceID, mobilenetFeaturesStream, lstmResults);
                        
                        if(lstmResults.size() >= 3)
                        {
                            //
                            std::vector<std::size_t> gridwhshape = {3};
                            //todo:注意！ auto 类型 xtensor adapt来的，reshape不能用！
                            //               arrange来的，reshape也不能用!!!
                            auto probs= xt::adapt(lstmResults,gridwhshape);
                            auto lstmnetclass=xt::argmax(probs);
                            ANNIWOLOG(INFO)<<"FireDetection: r net:"<<lstmnetclass<<" camID:"<<camID ;
                            int predictcls=lstmnetclass(0);
                            //background and welding ignore!!!
                            if(predictcls == 0 ) //'background'
                            {
                                ANNIWOLOG(INFO) << "FireDetection:detect "<<"camID:"<<camID <<"r net NOT ok,ignore.";
                                continue;
                            }

                        }else
                        {
                            ANNIWOLOG(INFO)<<"FireDetection:r Results.size unexpected! ";

                            ANNIWOCHECK(false);
                        }

                        /////////////////////////////////////////////////////////////////////////////////



                    }else
                    {
                        continue;//不报警
                    }

                }
            }else//第一次装入，不报警.
            {
                continue;
            }

            





            filteredObjects.push_back(obj);

            writer.StartObject();               // Between StartObject()/EndObject(), 

            writer.Key("y1");                
            writer.Int(y1);            
            writer.Key("x1");                
            writer.Int(x1);  
            writer.Key("y2");                
            writer.Int(y2);  
            writer.Key("x2");                
            writer.Int(x2);  
            writer.Key("classItem");                // output a key,
            writer.String(class_names[obj.label].c_str());             // follow by a value.
        

            writer.EndObject();

            jsonObjCnt++;


        }

#ifdef ANNIWO_INTERNAL_DEBUG
        //todo:Below is leave for debugging! 描绘部分!
        cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
        float c_mean = cv::mean(color)[0];
        cv::Scalar txt_color;
        if (c_mean > 0.5){
            txt_color = cv::Scalar(0, 0, 0);
        }else{
            txt_color = cv::Scalar(255, 255, 255);
        }

        cv::rectangle(image, obj.rect, color * 255, 2);

        char text[256];
        sprintf(text, "%s %.1f%%", class_names[obj.label].c_str(), obj.prob * 100);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        cv::Scalar txt_bk_color = color * 0.7 * 255;

        int x = obj.rect.x;
        int y = obj.rect.y + 1;
        if (y > image.rows)
            y = image.rows;

        cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      txt_bk_color, -1);

        cv::putText(image, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
#endif
    }




    writer.EndArray();


    if(jsonObjCnt > 0)
    {

        if(isResultDuplicated(allLastObjects[camID],filteredObjects))
        {
            ANNIWOLOG(INFO) <<"FireDetection:Duplicated results.Ignored.camID:"<<camID;
            allLastObjects[camID]=filteredObjects;

            return;
        }
        //update history results
        allLastObjects[camID]=filteredObjects;


        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/firesmog/" + imagename;



        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/firesmog"};

        getTaskId(globalJsonConfObjPtr,camID,"fire",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"fire","/firesmog",submitUrl);



        ANNIWOLOG(INFO) <<"FireDetection:save file name drawed is:"<<imgPath<<" camID:"<<camID;
        pool->enqueue(saveImgAndPost,camID, taskIdstr, imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()), jsonstrbuf.GetLength(), submitUrl);

    }


}



void FireDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    allLastObjects.clear();
    allHisListMap.clear();
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter)
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f ==  std::string("fire"))
            {
                std::vector<Object> emptyObjArray;
                ANNIWOLOG(INFO) << "FireDetection::initTracks: insert" <<"camID:"<<camID<<" ";
                allLastObjects.insert(std::pair<int, std::vector<Object>  >(camID,emptyObjArray) );

                std::deque<ObjectHisSave> emptyObjArrayX;
                allHisListMap.insert(std::pair<int, std::deque<ObjectHisSave> >(camID,emptyObjArrayX) );


                break;
            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }


    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_FIRE个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_FIRE)
    {
        ANNIWOLOG(INFO) << "FireDetection::initTracks: insert instance" <<"cntID:"<<cntID<<" ";


        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }



    fireclassier->initTracks(globalJsonConfObj);
    firefeatureExtractor->initTracks(globalJsonConfObj);
    fireRnnclassier->initTracks(globalJsonConfObj);



    globalJsonConfObjPtr=&globalJsonConfObj;


    
}

//todo:polygonSafeArea
void FireDetection::detect(  int camID, int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr) 
{    

    std::vector<Object> objects;

    cv::Mat image = img;
    
    cudaSetDevice(gpuNum);

    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_FIRE);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    if (iterCamInstance != executionContexts.end()) 
    {

        yolov4_detection_staff(m_input_datas,camID,instanceID,image,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "FireDetection");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }


    if(objects.size() > 0)
    {
        main_func(camID,instanceID, image, objects,polygonSafeArea_ptr);
    }
    else
    {
        ANNIWOLOG(INFO) << "FireDetection:no objects" ;
    }

    image.release();
    ANNIWOLOG(INFO) << "FireDetection:exit detect()" ;


    return;
}
