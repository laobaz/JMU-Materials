#ifndef __UTILS_HTTPUTIL_HPP__
#define __UTILS_HTTPUTIL_HPP__

#include <string>    // std::string
#include <chrono>
#include <opencv2/opencv.hpp>


class HttpUtil{
    public:
        HttpUtil() {}
        ~HttpUtil() {}

        void  post( const char* str2send, size_t sendlength, const std::string& url);
};

void saveImgAndPost(int camID, const std::string taskId, const std::string imgPath, 
            cv::Mat image, std::chrono::system_clock::time_point eventStartTP,
            const std::string& jsonStrIn, size_t jsonlength, const std::string submitUrl);

extern const std::string ANNIWO_LOG_IMAGES_PATH;

#endif //
