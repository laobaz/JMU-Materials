
#include "httpUtil.hpp"

#include <sstream>

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <chrono>

#include <iostream>
#include <ctime>
#include <iomanip>
#include <string>
#include <sstream>
#include <stdio.h>

#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>
#include <curlpp/Exception.hpp>
#include "subUtils.hpp"

#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"

const std::string ANNIWO_LOG_IMAGES_PATH={"/var/anniwo/images/"};

void  HttpUtil::post( const char* str2send, size_t sendlength, const std::string& url)
{
    // std::istringstream myStream(str2send);
    // int size = myStream.str().size();
        
    char buf[50];
    try
    {
        // curlpp::Cleanup cleaner;
        // curlpp::Easy request;

        // std::list< std::string > headers;
        // headers.push_back("User-Agent: Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko"); 
        // headers.push_back("Content-Type: application/json"); 
        // sprintf(buf, "Content-Length: %d", size); 
        // headers.push_back(buf);
        
        // using namespace curlpp::Options;
        // request.setOpt(new Verbose(true));
        // request.setOpt(new ReadStream(&myStream));
        // request.setOpt(new InfileSize(size));
        // request.setOpt(new Upload(true));
        // request.setOpt(new HttpHeader(headers));
        // request.setOpt(new Url(url.c_str()));
        
        // request.perform();


        curlpp::Cleanup cleaner;
        curlpp::Easy request;
        
        request.setOpt(new curlpp::options::Url(url.c_str())); 
        request.setOpt(new curlpp::options::Verbose(true)); 
        
        std::list< std::string > headers;
        headers.push_back("User-Agent: Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko"); 
        headers.push_back("Content-Type: application/json"); 
        sprintf(buf, "Content-Length: %d", sendlength); 
        headers.push_back(std::string(buf));
        
        request.setOpt(new curlpp::options::HttpHeader(headers)); 
        
        request.setOpt(new curlpp::options::PostFields(str2send));
        request.setOpt(new curlpp::options::PostFieldSize( sendlength ) );
        
        request.perform(); 


    // ANNIWOLOG(INFO) <<"debug:json lenght:"<<sendlength<<"to send json:"<< str2send ;
    }
    catch ( curlpp::LogicError & e )
    {
        ANNIWOLOG(INFO) << e.what() ;
    }

}

void saveImgAndPost(int camID, const std::string taskId, const std::string imgPath, 
                    cv::Mat image, std::chrono::system_clock::time_point eventStartTP,
                    const std::string& jsonStrIn, size_t jsonlength, const std::string submitUrl)
{

        //todo:WHY?CV_IMWRITE_PNG_COMPRESSION not defined???
        // std::vector<int> compression_params;
        // compression_params.push_back(CV_IMWRITE_PNG_COMPRESSION); //PNG格式图片的压缩级别  
        // compression_params.push_back(8);  //这里设置保存的图像质量级别

        // cv::imwrite(imgPath,image,compression_params);


        int imgWidth = image.cols;
        int imgHeight = image.rows;
        int imgDepth = image.channels();

        ANNIWOCHECK(imgWidth>0 && imgHeight>0);

        cv::imwrite(imgPath,image);

        //      res = {
        //     "camID": camID,
        //     "imgPath": imgPath,
        //     "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        //     'info': jsonStrBuf
        // }


        rapidjson::StringBuffer jsonstrbuf;
        rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);

        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("camId");                
        writer.Int(camID); 

        writer.Key("taskId");                
        writer.String(taskId.c_str());  

        writer.Key("imgWidth");                
        writer.Int(imgWidth); 
        
        writer.Key("imgHeight");                
        writer.Int(imgHeight); 

        writer.Key("imgDepth");                
        writer.Int(imgDepth); 

        writer.Key("imgPath");                
        writer.String(imgPath.c_str());  


        writer.Key("startTime");                
        //
        // time2Str
        //
        std::time_t tt = std::chrono::system_clock::to_time_t(eventStartTP); 
        std::ostringstream oss;
        oss << std::put_time(std::localtime(&tt), "%Y-%m-%d %H:%M:%S");
        std::string strTime{oss.str()};
        // std::cout << "strTime:" << strTime << '\n';
        writer.String(strTime.c_str());  



        writer.Key("time");                
        //
        // time2Str
        //
        std::time_t tt2{std::time(nullptr)};
        std::ostringstream oss2;
        oss2 << std::put_time(std::localtime(&tt2), "%Y-%m-%d %H:%M:%S");
        std::string strTime2{oss2.str()};
        // std::cout << "strTime:" << strTime << '\n';
        writer.String(strTime2.c_str());  


        writer.Key("info");         
        writer.RawValue(jsonStrIn.c_str(), jsonlength,  rapidjson::Type::kArrayType);       
        //Wrong here.
        // writer.String(jsonStrIn);  



        writer.EndObject();




        HttpUtil httputilObj;
        ANNIWOLOG(INFO) <<"MESSAGE:"<< jsonstrbuf.GetString() ;
        httputilObj.post(jsonstrbuf.GetString(), jsonstrbuf.GetLength(),submitUrl);
        
        image.release();
}



