#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>
#include <xtensor.hpp>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "jiayouji.hpp"

#include "xunjian_classification.hpp"



static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;



static const int NUM_CLASSES = 5;
static  float BBOX_CONF_THRESH = 0.35;  //config.ini可设置.贵州中石油0.35,成都中海油0.8

//todo
static const std::vector<std::string>  class_names = {
    "oil_person",
    "oiling_machine_open",
    "open_shell",
    "open_shell2",
    "open_shell3"
};



const static std::string model_file={"../models/jyz_xunjian/jyz_jiayouji/jyz_jiayouji_sim.trt"};


const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf

//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);

std::unordered_map<int, std::vector<float> >  JiayoujiDetection::m_input_datas;

static std::unordered_map<int, std::deque<ObjectTimeSave> > allHisListMap ;


static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};
static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;

static int gpuNum=0;



static JiayoujiClassification *jyjClassier = nullptr;

// Default constructor
JiayoujiDetection::JiayoujiDetection () { 

    ANNIWOLOG(INFO) << "JiayoujiDetection(): call initInferContext!" ;
    jyjClassier= new JiayoujiClassification();


    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "JiayoujiDetection(): Success initialized!" ;

}

// Destructor
JiayoujiDetection::~JiayoujiDetection () 
{
    // destroy the engine

    delete engine;
    delete runtime;


}


//结果是否报警判断与历史更新
inline bool isRequireReportJYJ(std::deque<ObjectTimeSave>& lastObjects, const std::vector<Object>& filteredObjects)
{
    float inter_area =0.0;
    float union_area =0.0;
    bool needToReport=false;
    
    if(filteredObjects.size() == 0)
    {
        ANNIWOLOGF(INFO, "JiayoujiDetection:isRequireReportJYJ:  filteredObjects.size 0.");
        return false;
    }


    if(lastObjects.size() == 0)//首次需要报警
    {
        needToReport=true;
    }


    for (size_t i = 0; i < filteredObjects.size(); i++)
    {
        const Object& obj = filteredObjects[i];
        bool isFoundIou=false;
        for (auto& last_det : lastObjects) 
        {
            //与box_det求ioa
            // intersection over union
            inter_area = intersection_area(obj, last_det.detObj);
            union_area = obj.rect.area() + last_det.detObj.rect.area() - inter_area;

            auto durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - last_det.reportedtime).count();


            //iou>1 duplicated box
            if(inter_area / union_area > 0.1  ) //加油机不同于人孔井,加油机间隔较大
            {
                if(durn > 600)//10分钟
                {
                    needToReport=true;//重复且大于10分钟需要报警
                    break;
                }else
                {
                    isFoundIou=true;
                }
            }   

        }
        if(needToReport)
        {
            break;
        }
        if(isFoundIou == false)//找到一个无iou的，说明本次需要报警
        {
            needToReport=true;
            break;
        }

    }

    if(needToReport) //更新历史
    {
        lastObjects.clear();
        for (size_t i = 0; i < filteredObjects.size(); i++)
        {
            const Object& obj = filteredObjects[i];
            ObjectTimeSave hisObj;
            hisObj.detObj=obj;
            hisObj.reportedtime=std::chrono::system_clock::now();
            lastObjects.push_back(hisObj);
        }
    }



    return needToReport;

}



static void PostProcessResults(int camID, int instanceID,  cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{


    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;
    writer.StartArray();    
    std::vector<Object> filteredObjects;


    // //debug
    // std::string imagename=getRandomName();
    // std::string imgPath = "./jiayouji/" + imagename;
    // cv::imwrite(imgPath,image);
    // ANNIWOLOG(INFO) << "JiayoujiDetection:debug save name"<<imagename <<"camID:"<<camID ;    



    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];


        ANNIWOLOGF(INFO, "JiayoujiDetection:camID:%d  %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
            camID, class_names[obj.label].c_str(), obj.prob,
            obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);

        bool openWarning=false;
        // 2,3,4:open_shell
        if(class_names[obj.label] == std::string("open_shell")  || class_names[obj.label] == std::string("open_shell2") || class_names[obj.label] == std::string("open_shell3") )
        {
            int x1=obj.rect.x;
            int y1 = obj.rect.y;
            int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
            int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);


            ANNIWOLOGF(INFO, "JiayoujiDetection check open_shell:camID:%d  %s = confidence:%.5f at x1:%d y1:%d \n",
                camID, class_names[obj.label].c_str(), obj.prob,
                x1, y1);

            // .shell的x1,y1在“oiling_machine_open”内部
            //if cur_class == 'oiling_machine_open':
            for (size_t j = 0; j < objects.size(); j++)
            {
                const Object& objinner = objects[j];

                // 1:'oiling_machine_open'
                if( class_names[objinner.label] == std::string("oiling_machine_open")  )
                {
                    int xx1=objinner.rect.x;
                    int yy1 = objinner.rect.y;
                    int xx2=(objinner.rect.x+objinner.rect.width) > image.cols ? image.cols  : (objinner.rect.x+objinner.rect.width) ;
                    int yy2 =(objinner.rect.y+objinner.rect.height) > image.rows ? image.rows : (objinner.rect.y+objinner.rect.height);


                    ANNIWOLOGF(INFO, "JiayoujiDetection check oiling_machine_open:camID:%d  %s = confidence:%.5f at xx1:%d yy1:%d xx2:%d yy2:%d\n",
                    camID, class_names[objinner.label].c_str(), objinner.prob, xx1, yy1, xx2, yy2);

                    if( x1 >= xx1 &&  x1 <= xx2 &&   y1 >= yy1 &&   y1  <= yy2 ) //
                    {
                        ///////////////////////进行加油机切图分类
                        //保存切图，用于分类
                        int oilingm_h=yy2-yy1;
                        int oilingm_w=xx2-xx1;

                        cv::Mat jiayouji_img(oilingm_h, oilingm_w, CV_8UC3, cv::Scalar(114, 114, 114));
                        image(cv::Rect(xx1, yy1, oilingm_w, oilingm_h)).copyTo(jiayouji_img(cv::Rect(0, 0, oilingm_w, oilingm_h)));




                        ////////////////////////////////////分类过滤/////////////////////////////////////////////
                        //进行分类判断，仅通过分类判断的才认为是真正的加油机巡检
                        //分类模型检测
                        // "wrong",
                        // "right"
                        std::vector<float> mobilenetResults;

                        //
                        jyjClassier->detect(camID,instanceID,jiayouji_img, mobilenetResults);
                        
                        // //debug
                        // std::string imagename=getRandomName();
                        // std::string imgPath = "./jiayouji/" + imagename;
                        // cv::imwrite(imgPath,jiayouji_img);
                        // ANNIWOLOG(INFO) << "JiayoujiDetection:debug save name"<<imagename <<"camID:"<<camID ;    

                        int predictcls=0; //"wrong"
                        if(mobilenetResults.size() >= 2)
                        {
                            //
                            std::vector<std::size_t> gridwhshape = {2};
                            //todo:注意！ auto 类型 xtensor adapt来的，reshape不能用！
                            //               arrange来的，reshape也不能用!!!
                            auto probs= xt::adapt(mobilenetResults,gridwhshape);
                            auto mobilenetclass=xt::argmax(probs);
                            ANNIWOLOG(INFO)<<"JiayoujiDetection: clsnet:"<<mobilenetclass <<",camID:"<<camID ;
                            predictcls=mobilenetclass(0);
                        }

                        ///////////////////////
                        if(predictcls == 1)//"right"
                        {
                            openWarning=true;
                        }

                        break;
                    }

                }
                
            }

            if(!openWarning)
            {
                continue;
            }

            if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
            {
                box_poly.clear();
                box_poly.add(cv::Point(int(x1),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y2)));
                box_poly.add(cv::Point(int(x1),int(y2)));
                _inter.clear();
                intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
                if( _inter.size() ) {
                    float area = _inter.area();
                    // cv::Point center = _inter.getCenter();
                    
                    ANNIWOLOG(INFO) <<"JiayoujiDetection: Area intersected = "<<area<<"camID:"<<camID;

                    if(area > 200.0)
                    // if(area >= box_poly.area()-10.0)//交叠部分等于自身，说明在其内部
                    {
                        // ANNIWOLOGF(INFO,
                        // "JiayoujiDetection: detect:check box:%.2f %.2f  %.2f x %.2f score:%.5f class:%s intersectArea:%0.1f\n",
                        //     obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height, obj.prob, class_names[obj.label], area);
                        ANNIWOLOG(INFO) <<
                            "JiayoujiDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                            <<obj.rect.width<<","<<obj.rect.height<<","
                            << "score:"<<obj.prob<<"class:"<<class_names[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID
                             <<", camID:"<<camID;

                    }else
                    {
                        continue;
                    }


                }else
                {
                    ANNIWOLOG(INFO) <<"JiayoujiDetection: Area intersected None "<<"camID:"<<camID;
                    continue;
                }
            }

            filteredObjects.push_back(obj);

            writer.StartObject();               // Between StartObject()/EndObject(), 

            writer.Key("y1");                
            writer.Int(y1);            
            writer.Key("x1");                
            writer.Int(x1);  
            writer.Key("y2");                
            writer.Int(y2);  
            writer.Key("x2");                
            writer.Int(x2);  
            writer.Key("classItem");                // output a key,
            // writer.String(class_names[obj.label].c_str());             // follow by a value.
            writer.String("oiling_machine_open");             // follow by a value.
            
        

            writer.EndObject();

            jsonObjCnt++;


#ifdef ANNIWO_INTERNAL_DEBUG
            ////////////////////////////////////////////////////////////////////////////////
            //todo:Below is leave for debugging! 描绘部分!
            cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
            float c_mean = cv::mean(color)[0];
            cv::Scalar txt_color;
            if (c_mean > 0.5){
                txt_color = cv::Scalar(0, 0, 0);
            }else{
                txt_color = cv::Scalar(255, 255, 255);
            }

            cv::rectangle(image, obj.rect, color * 255, 2);

            char text[256];
            sprintf(text, "%s %.1f%%", class_names[obj.label].c_str(), obj.prob * 100);

            int baseLine = 0;
            cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

            cv::Scalar txt_bk_color = color * 0.7 * 255;

            int x = obj.rect.x;
            int y = obj.rect.y + 1;
            if (y > image.rows)
                y = image.rows;

            cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                        txt_bk_color, -1);

            cv::putText(image, text, cv::Point(x, y + label_size.height),
                        cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
            ////////////////////////////////////////////////////////////////////////////////
#endif
        }


    }




    writer.EndArray();


    std::unordered_map<int, std::deque<ObjectTimeSave> >::iterator got_id_func_cap = allHisListMap.find(camID);

    if (got_id_func_cap == allHisListMap.end())
    {
        ANNIWOLOG(INFO) << "jiayouji.main_func WARN: allHisListMap,camID:" <<camID;
    }

    std::deque<ObjectTimeSave>& hisList =got_id_func_cap->second;

    if(! isRequireReportJYJ(hisList,filteredObjects))
    {
        ANNIWOLOG(INFO) <<"jiayouji: results.Ignored.camID:"<<camID<<std::endl;

        return;
    }



    if(jsonObjCnt > 0)
    {
        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/xunjian/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/xunjian"};

        getTaskId(globalJsonConfObjPtr,camID,"xunjian",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"xunjian","/xunjian",submitUrl);

        ANNIWOLOG(INFO) <<"jiayouji:save file name drawed is:"<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }


}







void JiayoujiDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{

    jyjClassier->initTracks(globalJsonConfObj);

    allHisListMap.clear();
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);


    globalJsonConfObjPtr=&globalJsonConfObj;
    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("xunjian"))
            {

                std::deque<ObjectTimeSave> emptyObjArray;
                ANNIWOLOG(INFO) << "JiayoujiDetection::initTracks: insert" <<"camID:"<<camID<<" ";
                allHisListMap.insert(std::pair<int, std::deque<ObjectTimeSave> >(camID,emptyObjArray) );

                break;
            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }


    //取得设置的阈值 thesholdsetting
    std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(std::string("jyzxunjian_jiayouji"));

    if (got_theshold == globalINICONFObj.thesholdsetting.end())
    {
        ANNIWOLOG(INFO) <<"JiayoujiDetection::initTracks: f is not thesholdsetting....use default.f: "<<"jyzxunjian_jiayouji" <<" default:"<<BBOX_CONF_THRESH;
    }else
    {
        BBOX_CONF_THRESH=got_theshold->second;
        ANNIWOLOG(INFO) <<"JiayoujiDetection::initTracks: f in thesholdsetting....use.f: "<<"jyzxunjian_jiayouji" <<" value:"<<BBOX_CONF_THRESH;
    }




    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_XUNJIAN个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN)
    {
        ANNIWOLOG(INFO) << "JiayoujiDetection::initTracks: insert instance" <<"cntID:"<<cntID;

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }


 }
//todo:polygonSafeArea
void JiayoujiDetection::detect(  int camID, int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr) 
{    

    std::vector<Object> objects;
    cudaSetDevice(gpuNum);


    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    if (iterCamInstance != executionContexts.end()) 
    {

        yolov4_detection_staff(m_input_datas,camID,instanceID,img,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "JiayoujiDetection");

    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }

    if(objects.size() > 0)
    {
        PostProcessResults(camID,instanceID, img, objects,polygonSafeArea_ptr);
    }
    else
    {
        ANNIWOLOG(INFO) << "JiayoujiDetection:no objects" ;
    }


    
    ANNIWOLOG(INFO) << "JiayoujiDetection:exit detect() for camId:"<<camID;;


    return;
}
