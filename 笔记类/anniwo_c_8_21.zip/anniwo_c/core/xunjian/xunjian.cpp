#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>
#include <unistd.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"

#include "xunjian.hpp"

#include "renkongjing.hpp"
#include "jiayouji.hpp"


static const std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >*  validtypes_map_ptr;

static RenkongjingDetection *rkjDet=nullptr;
static JiayoujiDetection *jiayoujiDet=nullptr;

// Default constructor
XunjianDetection::XunjianDetection () { 

    ANNIWOLOG(INFO) << "XunjianDetection(): Success initialized!" ;
    rkjDet= new RenkongjingDetection();
    jiayoujiDet= new JiayoujiDetection();

}

// Destructor
XunjianDetection::~XunjianDetection () 
{
    delete rkjDet;
    delete jiayoujiDet;
}




void XunjianDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    rkjDet->initTracks(globalJsonConfObj);
    jiayoujiDet->initTracks(globalJsonConfObj);
    validtypes_map_ptr=&globalJsonConfObj.validtypes_map;
  
}
//todo:polygonSafeArea
void XunjianDetection::detect(  int camID,int instanceID,  cv::Mat img, const Polygon* polygonSafeArea_ptr) 
{    

    ANNIWOCHECK(img.data != nullptr);
    cv::Mat image = img;
    
    ANNIWOLOG(INFO) << "XunjianDetection:detect entered"<<"camID:"<<camID ;


////////////////////////////////////////////////
    bool isJiayouji=false;
    bool isRenkongjin=false;
    //todo:以后优化这一块。
    // std::set<std::string> concern_classes;
    //取得关注类型
    //valid types
    //camId,{func,Vector<String>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::const_iterator got_id_func_cap = validtypes_map_ptr->find(camID);

    if (got_id_func_cap == validtypes_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "XunjianDetection:not set in validtypes_conf_map for camID:" <<camID<<"use default classes";
        isJiayouji=true;
        isRenkongjin=true;
    }
    else
    {
        const std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>::const_iterator got_id_func_cap2 = conf_map.find("xunjian");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "XunjianDetection:has but not set xunjian in validtypes_conf_map for camID:" <<camID<<"use default classes";

            isJiayouji=true;
            isRenkongjin=true;

        }
        else
        {
            const AnniwoSafeEreaConcernTypes& typesST = got_id_func_cap2->second;
            if(typesST.validtypes.size() == 0 )
            {
                ANNIWOLOG(INFO) << "XunjianDetection:empty xunjian in validtypes_conf_map for camID:" <<camID<<"use default classes";
                isJiayouji=true;
                isRenkongjin=true;
            }
            else if(typesST.validtypes.size() >= 1)
            {


                ANNIWOLOG(INFO) << "XunjianDetection:used concern_classes from config for camID:" <<camID ;

                for(auto& onetype:typesST.validtypes)
                {

                    if( onetype == std::string("oiling_machine_open") ||
                        onetype == std::string("open_shell") )
                    {
                        isJiayouji=true;
                    }
                    else if( onetype == std::string("manhole_shaft") ||
                             onetype == std::string("manhole_shaft_shell") )
                    {
                        isRenkongjin=true;
                    }
                }


            }

        }
    }



    //日志打印
    // for(auto& onetype:concern_classes)
    // {
    //    ANNIWOLOG(INFO) << "XunjianDetection:concern_classes for camID:" <<camID <<","<< onetype;
    // }

    ANNIWOLOG(INFO) << "XunjianDetection:concern_classes for camID: " <<camID <<",isJiayouji:"<<isJiayouji<<",isRenkongjin:"<<isRenkongjin;



////////////////////////////////////////////////

    if(isJiayouji)
    {
        jiayoujiDet->detect(camID,instanceID,image,polygonSafeArea_ptr);
    }else if(isRenkongjin)
    {
        rkjDet->detect(camID,instanceID,image,polygonSafeArea_ptr);
    }
    
    
    ANNIWOLOG(INFO) << "XunjianDetection:exit detect() for camId:"<<camID;;


    return;
}
