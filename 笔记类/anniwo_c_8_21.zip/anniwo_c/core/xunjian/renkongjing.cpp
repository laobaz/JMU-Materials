#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "renkongjing.hpp"


static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;




static const int NUM_CLASSES = 5;
static  float BBOX_CONF_THRESH = 0.58; //可以从外边设置
// static  float BBOX_CONF_THRESH = 0.35;
static const int NUM_CLASSES_INUSE = 5;

//todo
static const std::vector<std::string>  class_names = {
"manhole_shaft",
"manhole_shaft_shell",
"manhole_shaft_2",
"manhole_shaft_shell_2",
"clothe_blue_stand_2"
};



//todo
const static std::string model_file={"../models/jyz_xunjian/jyz_rkj/jyz_rkj_sim.trt"};



const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf

//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);

std::unordered_map<int, std::vector<float> >  RenkongjingDetection::m_input_datas;

static std::unordered_map<int, std::deque<ObjectTimeSave> > allHisListMap ;

static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};
static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;



// Default constructor
RenkongjingDetection::RenkongjingDetection () { 

    ANNIWOLOG(INFO) << "RenkongjingDetection(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "RenkongjingDetection(): Success initialized!" ;

}

// Destructor
RenkongjingDetection::~RenkongjingDetection () 
{
    // destroy the engine
    delete engine;
    delete runtime;
}


//结果是否报警判断与历史更新
inline bool isRequireReportRKJ(std::deque<ObjectTimeSave>& lastObjects, const std::vector<Object>& filteredObjects)
{
    float inter_area =0.0;
    float union_area =0.0;
    bool needToReport=true;//默认需要报警

    if(filteredObjects.size() == 0)
    {
        ANNIWOLOGF(INFO, "RenkongjingDetection:isRequireReport:  filteredObjects.size 0.");
        return false;
    }
    

    for (size_t i = 0; i < filteredObjects.size(); i++)
    {

        if(!needToReport)//已经判断好不需要报警了
        {
            break;
        }

        const Object& obj = filteredObjects[i];

        for (auto& last_det : lastObjects) 
        {
            //与box_det求ioa
            // intersection over union
            inter_area = intersection_area(obj, last_det.detObj);
            union_area = obj.rect.area() + last_det.detObj.rect.area() - inter_area;

            auto durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - last_det.reportedtime).count();


            ANNIWOLOGF(INFO, "RenkongjingDetection:isRequireReport last_det %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                    class_names[last_det.detObj.label].c_str(), last_det.detObj.prob,
                    last_det.detObj.rect.x, last_det.detObj.rect.y, last_det.detObj.rect.width, last_det.detObj.rect.height);

            ANNIWOLOGF(INFO, "RenkongjingDetection:isRequireReport current obj %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                    class_names[obj.label].c_str(), obj.prob,
                    obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);
            
            ANNIWOLOGF(INFO, "RenkongjingDetection:isRequireReport  inter_area:%.2f , union_area:%.2f,iou::%.2f\n",inter_area,union_area,inter_area/union_area);

            //iou>1 duplicated box
            if(inter_area / union_area > 0.5  ) //加油机不同于人孔井,加油机间隔较大
            {
                if(durn > 600)//10分钟
                {
                    needToReport=true;//重复且大于10分钟需要报警
                    break;
                }else
                {
                    needToReport=false;
                    
                    break;
                }
            }   

        }


    }

    if(needToReport) //更新历史
    {
        lastObjects.clear();
        for (size_t i = 0; i < filteredObjects.size(); i++)
        {
            const Object& obj = filteredObjects[i];
            ObjectTimeSave hisObj;
            hisObj.detObj=obj;
            hisObj.reportedtime=std::chrono::system_clock::now();
            lastObjects.emplace_back(hisObj);
        }
    }



    return needToReport;

}



static void PostProcessResults(int camID,cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{


    cv::Mat image = bgr;
    bgr.release();
    float  inter_area=0.;
    float  gzf_area=0.;
    float  obj_area=0.;

	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;
    writer.StartArray();    
    std::vector<Object> filteredObjects;



    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];

        ANNIWOLOGF(INFO, "RenkongjingDetection:camID:%d  %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                camID, class_names[obj.label].c_str(), obj.prob,
                obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);

// // #ifdef ANNIWO_INTERNAL_DEBUG
//         ////////////////////////////////////////////////////////////////////////////////
//         //todo:Below is leave for debugging! 描绘部分!
//         cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
//         float c_mean = cv::mean(color)[0];
//         cv::Scalar txt_color;
//         if (c_mean > 0.5){
//             txt_color = cv::Scalar(0, 0, 0);
//         }else{
//             txt_color = cv::Scalar(255, 255, 255);
//         }

//         cv::rectangle(image, obj.rect, color * 255, 2);

//         char text[256];
//         sprintf(text, "%s %.1f%%", class_names[obj.label].c_str(), obj.prob * 100);

//         int baseLine = 0;
//         cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

//         cv::Scalar txt_bk_color = color * 0.7 * 255;

//         int x = obj.rect.x;
//         int y = obj.rect.y + 1;
//         if (y > image.rows)
//             y = image.rows;

//         cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
//                     txt_bk_color, -1);

//         cv::putText(image, text, cv::Point(x, y + label_size.height),
//                     cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);

// // #endif

        bool openWarning=false;

        // 0:'manhole_shaft', 2:'manhole_shaft2'
        if(obj.label == 0 || obj.label == 2 )
        {
            ANNIWOLOGF(INFO, "RenkongjingDetection:camID:%d shaft to check shell %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                camID, class_names[obj.label].c_str(), obj.prob,
                obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);


            int x1=obj.rect.x;
            int y1 = obj.rect.y;
            int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
            int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);

            // .shell的x1,y1在“manhole_shaft”内部
            for (size_t j = 0; j < objects.size(); j++)
            {
                const Object& objinner = objects[j];

                // 1:'manhole_shaft_shell'  3:'manhole_shaft_shell_2'
                if( (obj.label == 0 && objinner.label == 1) || (obj.label == 2 && objinner.label == 3) )
                {
                    int xx1=objinner.rect.x;
                    int yy1 = objinner.rect.y;
                    int xx2=(objinner.rect.x+objinner.rect.width) > image.cols ? image.cols  : (objinner.rect.x+objinner.rect.width) ;
                    int yy2 =(objinner.rect.y+objinner.rect.height) > image.rows ? image.rows : (objinner.rect.y+objinner.rect.height);
                   



                    //看看重合.
                    // intersection over union
                    inter_area = intersection_area(obj, objinner);
                    gzf_area = objinner.rect.area();

                    ANNIWOLOGF(INFO, "RenkongjingDetection:camID:%d .shell x1,y1,x2,y2:%d,%d,%d,%d inter,inner:%f,%f\n",camID,xx1,yy1,xx2,yy2,inter_area,gzf_area);

                    if( inter_area/gzf_area > 0.65 )
                    // if( inter_area > 0.0 )//shell在shaft的内部
                    {

                        /////////////////////////////////检查shell是否在设置有效区域内部
                        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
                        {
                            box_poly.clear();
                            box_poly.add(cv::Point(int(xx1),int(yy1)));
                            box_poly.add(cv::Point(int(xx2),int(yy1)));
                            box_poly.add(cv::Point(int(xx2),int(yy2)));
                            box_poly.add(cv::Point(int(xx1),int(yy2)));
                            _inter.clear();
                            intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
                            if( _inter.size() ) {
                                float area = _inter.area();
                                // cv::Point center = _inter.getCenter();
                                
                                ANNIWOLOG(INFO) <<"RenkongjingDetection: shell Area intersected = "<<area<<"camID:"<<camID;

                                if(area > 10.0) //shell在有效区域内
                                {
                                    openWarning=true;
                                    break;

                                }else
                                {
                                    ANNIWOLOG(INFO) <<"RenkongjingDetection:shell ignore Area intersected less than 10. "<<"camID:"<<camID;

                                    continue;
                                }


                            }else
                            {
                                ANNIWOLOG(INFO) <<"RenkongjingDetection:shell Area intersected None "<<"camID:"<<camID;
                                continue;
                            }
                        }else
                        {
                                openWarning=true; //No valid area set
                                break;
                        }
                        /////////////////////////////////

                    }else
                    {//continue
                    }

                }
                
            }





            if(!openWarning)
            {
                ANNIWOLOGF(INFO, "RenkongjingDetection:camID:%d .shell not inside shaft.ignored\n",camID);
                continue;
            }

            if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
            {
                box_poly.clear();
                box_poly.add(cv::Point(int(x1),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y1)));
                box_poly.add(cv::Point(int(x2),int(y2)));
                box_poly.add(cv::Point(int(x1),int(y2)));
                _inter.clear();
                intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
                if( _inter.size() ) {
                    float area = _inter.area();
                    // cv::Point center = _inter.getCenter();
                    
                    ANNIWOLOG(INFO) <<"RenkongjingDetection: Area intersected = "<<area<<"camID:"<<camID;

                    if(area > 10.0) //人孔井弱化在内部的判断
                    {
                        ANNIWOLOG(INFO) <<
                            "RenkongjingDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                            <<obj.rect.width<<","<<obj.rect.height<<","
                            << "score:"<<obj.prob<<"class:"<<class_names[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;

                    }else
                    {
                        ANNIWOLOG(INFO) <<"RenkongjingDetection: ignore Area intersected less than 10. "<<"camID:"<<camID;

                        continue;
                    }


                }else
                {
                    ANNIWOLOG(INFO) <<"RenkongjingDetection: Area intersected None "<<"camID:"<<camID;
                    continue;
                }
            }

            filteredObjects.push_back(obj);

            writer.StartObject();               // Between StartObject()/EndObject(), 

            writer.Key("y1");                
            writer.Int(y1);            
            writer.Key("x1");                
            writer.Int(x1);  
            writer.Key("y2");                
            writer.Int(y2);  
            writer.Key("x2");                
            writer.Int(x2);  
            writer.Key("classItem");                // output a key,
            writer.String("manhole_shaft");             // follow by a value.
        

            writer.EndObject();

            jsonObjCnt++;



        }


    }




    writer.EndArray();

    // //debug
    // std::string imagename=getRandomName();
    // std::string imgPath = "./rkj/" + imagename;
    // cv::imwrite(imgPath,image);
    // ANNIWOLOG(INFO) << "RenkongjingDetection:debug save name"<<imagename <<"camID:"<<camID ;
    ////////////////////////////////////////////////////////////////////////////////

    std::unordered_map<int, std::deque<ObjectTimeSave> >::iterator got_id_func_cap = allHisListMap.find(camID);

    if (got_id_func_cap == allHisListMap.end())
    {
        ANNIWOLOG(INFO) << "RenkongjingDetection.main_func WARN: allHisListMap,camID:" <<camID;
    }

    std::deque<ObjectTimeSave>& hisList =got_id_func_cap->second;

    if(! isRequireReportRKJ(hisList,filteredObjects))
    {
        ANNIWOLOG(INFO) <<"RenkongjingDetection: results.Ignored.camID:"<<camID<<std::endl;

        return;
    }



    if(jsonObjCnt > 0)
    {
        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/xunjian/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/xunjian"};

        getTaskId(globalJsonConfObjPtr,camID,"xunjian",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"xunjian","/xunjian",submitUrl);

        ANNIWOLOG(INFO) <<"RenkongjingDetection:save file name drawed is:"<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }


}







void RenkongjingDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    allHisListMap.clear();
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);


    globalJsonConfObjPtr=&globalJsonConfObj;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("xunjian"))
            {

                std::deque<ObjectTimeSave> emptyObjArray;
                ANNIWOLOG(INFO) << "RenkongjingDetection::initTracks: insert" <<"camID:"<<camID<<" ";
                allHisListMap.insert(std::pair<int, std::deque<ObjectTimeSave> >(camID,emptyObjArray) );

                break;
            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }

    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_XUNJIAN个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_XUNJIAN)
    {
        ANNIWOLOG(INFO) << "RenkongjingDetection::initTracks: insert instance" <<"cntID:"<<cntID;

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }


    //取得设置的阈值 thesholdsetting
    std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(std::string("jyzxunjian_rkj"));

    if (got_theshold == globalINICONFObj.thesholdsetting.end())
    {
        ANNIWOLOG(INFO) <<"RenkongjingDetection::initTracks: f is not thesholdsetting....use default.f: "<<"jyzxunjian_rkj" <<" default:"<<BBOX_CONF_THRESH;
    }else
    {
        BBOX_CONF_THRESH=got_theshold->second;
        ANNIWOLOG(INFO) <<"RenkongjingDetection::initTracks: f in thesholdsetting....use.f: "<<"jyzxunjian_rkj" <<" value:"<<BBOX_CONF_THRESH;
    }


 }
//todo:polygonSafeArea
void RenkongjingDetection::detect(  int camID,int instanceID, cv::Mat image, const Polygon* polygonSafeArea_ptr) 
{    

    std::vector<Object> objects;
    cudaSetDevice(gpuNum);


    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_XUNJIAN);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);



    if (iterCamInstance != executionContexts.end()) 
    {

        yolov4_detection_staff(m_input_datas,camID,instanceID,image,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "RenkongjingDetection");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }
    
    if(objects.size() > 0)
    {
        PostProcessResults(camID, image, objects,polygonSafeArea_ptr);
    }
    else
    {
        ANNIWOLOG(INFO) << "RenkongjingDetection:no objects" <<"camID:"<<camID ;
    }


    
    ANNIWOLOG(INFO) << "RenkongjingDetection:exit detect()" <<"camID:"<<camID ;




    return;
}
