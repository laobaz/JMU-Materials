#ifndef YOLOX_XUNJIAN_H
#define YOLOX_XUNJIAN_H
#include <opencv2/opencv.hpp>
#include "../utils/utils_intersection.hpp"
#include <unordered_set>
#include <unordered_map>


class XunjianDetection  {
    public:
        XunjianDetection() ;
        ~XunjianDetection() ;


        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);

        //todo:polygonSafeArea
        static void detect(  int camID,int instanceID,  cv::Mat img, const Polygon* polygonSafeArea_ptr);

        
};

#endif 

