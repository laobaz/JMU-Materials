#ifndef YOLOX_VEST_CLASSIFICATION_H
#define YOLOX_VEST_CLASSIFICATION_H
#include <opencv2/opencv.hpp>
#include <unordered_set>
#include <unordered_map>
#include "../utils/utils_intersection.hpp"
#include "../common/yolo/yolo_common.hpp"



class VestClassification  {
    public:
        VestClassification() ;
        ~VestClassification() ;

        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);
        //todo:polygonSafeArea
        static void detect(  int camID,int instanceID,  cv::Mat img, std::vector<float>& outresults);
    private:
        static  std::unordered_map<int, std::vector<float> >  m_input_datas;

    // private:
        
};

#endif 

