#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <deque>
#include <algorithm>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>


#include "vest_classification.hpp"


#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"


static const std::vector<std::string>  class_names = {
"weilan_blue",
"weilan_person",
"weilan_vest"
};

static const int mobilenet_out_size=3;


const int batch_size = 1;
const int CROP_INPUT_W=100;
const int CROP_INPUT_H=200;
static std::vector<int> input_shape = {batch_size, CROP_INPUT_W, CROP_INPUT_H, 3};    //yolov4 keras/tf 

static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};

static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;

const static std::string model_file={"../models/safearea/jyz_vest/jyz_gzf_classify_sim.trt"};

std::unordered_map<int, std::vector<float> >  VestClassification::m_input_datas;


// Default constructor
VestClassification::VestClassification () { 
    
    ANNIWOLOG(INFO) << "VestClassification(): Success initialized!" ;

    ANNIWOLOG(INFO) << "VestClassification(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "VestClassification(): Success initialized!" ;

}

// Destructor
VestClassification::~VestClassification () {

    // destroy the engine
    delete engine;
    delete runtime;

}




void VestClassification::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    executionContexts.clear();
    contextlocks.clear();
    //Each IExecutionContext is bound to the same GPU as the engine from which it was created. 
    //When calling execute() or enqueue(), ensure that the thread is associated with the correct device by calling cudaSetDevice().
    cudaSetDevice(gpuNum);

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter)
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f ==  std::string("safeErea"))
            {
                ANNIWOLOG(INFO) << "VestClassification::initTracks: there:" <<"camID:"<<camID<<" ";

                break;
            }
            else
            {
                continue;
            }
        }
    }

    int cntID=0;
    //ANNIWO_NUM_INSTANCE_XUNJIAN
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_SAFEAREA)
    {
        ANNIWOLOG(INFO) << "VestClassification::initTracks: insert thread " <<"cntID:"<<cntID;

        std::vector<float> input_data(batch_size * CHANNELS * CROP_INPUT_W * CROP_INPUT_H);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }


    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_SAFEAREA;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }



}


void VestClassification::detect(  int camID,int instanceID,  cv::Mat img, std::vector<float>& outresults ) 
{    


    ANNIWOCHECK(img.data != nullptr);

    ANNIWOLOG(INFO) << "VestClassification:detect entered"<<"camID:"<<camID ;


    std::unordered_map<int, std::vector<float> >::iterator got_m_input_datas = m_input_datas.find(instanceID);

    if (got_m_input_datas == m_input_datas.end())
    {
        ANNIWOLOG(INFO) << "VestClassification:detect "<<"thread instanceID:"<<instanceID <<"NOT in predictors map!";
        ANNIWOCHECK(false);

        return ;
    }

    cudaSetDevice(gpuNum);

    int img_w = img.cols;
    int img_h = img.rows;
    cv::Mat pr_img = static_resizeLINEAR(img,CROP_INPUT_W,CROP_INPUT_H);
    ANNIWOLOG(INFO)  << "VestClassification static_resized image" <<"camID:"<<camID <<"instanceID:"<<instanceID ;


    //python: bgr_cropimg = preprocess_inputInception(bgr_cropimg)
    //python代码中用的bgr输入!
    blobFromImageAndNorm_resnetv2style(pr_img,m_input_datas[instanceID]);

    std::vector<float> out_data( mobilenet_out_size, 0.0);


    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_SAFEAREA);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    ANNIWOCHECK(iterCamInstance != executionContexts.end()) ;

    // run inference
    auto start = std::chrono::system_clock::now();
    
    int inputStreamSize = batch_size * CHANNELS * CROP_INPUT_W * CROP_INPUT_H;

    TrtGPUInfer(*iterCamInstance->second,gpuNum, *iterCamInstancelock->second, m_input_datas[instanceID].data(), out_data.data(), mobilenet_out_size,
                inputStreamSize,  "input_1", "dense_2","VestClassification:" );
    
    auto end = std::chrono::system_clock::now();

    ANNIWOLOG(INFO) <<"VestClassification:infer time:" << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms,"<<"camID:"<<camID ;

    outresults=out_data;

    std::stringstream buffer;  
    for(float item:outresults)
    {
        buffer <<item<<",";  
    }
    std::string contents(buffer.str());

    ANNIWOLOG(INFO) << "VestClassification:exit detect()" <<"camID:"<<camID<<"res result:"<<contents;

    return;
}
