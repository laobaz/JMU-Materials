#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include<set>

#include <opencv2/opencv.hpp>
#include <dirent.h>

#include "safeArea.hpp"

#include "utils.h"
#include "vest_classification.hpp"

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"

#include "../personbase/basePerson.hpp"

#include "../common/yolo/yolo_common.hpp"



#include <uuid/uuid.h>
#include <unordered_map>

#include <xtensor.hpp>
#include <xtensor/xnpy.hpp>





static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;






////////////

static std::unordered_map<int, std::unordered_map<int, int > > reporthistoryArray ;
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoStay>  >* stay_conf_map_ptr;
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >*  validtypes_map_ptr;

static std::unordered_map<int, std::vector<Object> > allLastObjects ; //防止低级错误的iou过滤

static VestClassification *vestClassier=nullptr;



static  std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  > trackStayMap;



// Default constructor
safeEreaDetection::safeEreaDetection () { 

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        vestClassier= new VestClassification();
    }
    
    
    ANNIWOLOG(INFO) << "safeEreaDetection(): Success initialized!" ;

}



// Destructor
safeEreaDetection::~safeEreaDetection () 
{

    if(vestClassier)
    {
        delete vestClassier;
    }

}

//通过trackid报警历史，停留时间来判断新出现的需要报警的人/车数目.与类型无关。
static int deDuplicateTrackResults(int camID, cv::Mat img, std::vector<Object>& offend_boxes_det)
{
    int orig_img_w = img.cols;
    int orig_img_h = img.rows;

    cv::Mat temp = img;
    int newpersonvehicleCnt=0;

    AnniwoStay stayconfig;
    stayconfig.isMotionless=false;
    stayconfig.staySec=-1;

    //取得停留时间设置
    //stayconfig
    //camId,{func,<isMotionless,stay in seconds>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoStay> >::const_iterator got_id_func_cap = stay_conf_map_ptr->find(camID);

    if (got_id_func_cap == stay_conf_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "not found in stay_conf_map,camID:" <<camID;
    }
    else
    {
        const std::unordered_map<std::string, AnniwoStay>& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoStay>::const_iterator got_id_func_cap2 = conf_map.find("safeErea");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "not found safeErea in stay_conf_map,camID:" <<camID;
        }
        else
        {
            stayconfig = got_id_func_cap2->second ;
        }
    }
    bool bIsStayConfigCheckOK=false;//停留时间判断用。


    for (auto& obj : offend_boxes_det) {
        int trackID = (int)obj.trackID;
        if(trackID == -1)
        {
            newpersonvehicleCnt++;

            //停留时间:首次进入不报警，除非当无逗留时间配置的时候
            if (stayconfig.staySec <= 0)
            {
                bIsStayConfigCheckOK = true;
            }
        }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
        {

            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"safeEreaDetection: camID Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);

                if (got_it2 == perCamIDhistory.end())//Not reported to this camID
                {
                    float inter_area =0.0;
                    float union_area =0.0;
                    
                    //停留时间:在区域内trackid是新的，相当于第一次跟踪上,没有配置逗留时间;
                    if (stayconfig.staySec <= 0)
                    {
                        ANNIWOLOG(INFO) <<
                            "safeEreaDetection.detect no stayconfig,has trackID but new. camID:"<<camID;
                        bIsStayConfigCheckOK=true;
                    }
                    else
                    {
                        std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  >::iterator got_id_func_cap = trackStayMap.find(camID);

                        if (got_id_func_cap == trackStayMap.end())
                        {
                            ANNIWOLOG(INFO) << "safeEreaDetection.detect WARN: trackStayMap,camID:" <<camID;
                        }
                        else
                        {
                            std::unordered_map<int, AnniwoTrackRecord>& track_stay_map =got_id_func_cap->second;
                            std::unordered_map<int, AnniwoTrackRecord>::iterator got_id_func_cap2 = track_stay_map.find(trackID);
                            if (got_id_func_cap2 == track_stay_map.end())
                            {
                                //map中未记录该track_id
                                ANNIWOLOG(INFO) << "safeEreaDetection.detect not found in track_stay_map,new add trackID:"<<trackID<<"camID:" <<camID;
                                //todo:何时清空？？
                                track_stay_map.insert(std::pair<int, AnniwoTrackRecord>(trackID,{obj,std::chrono::system_clock::now()}));
                            }
                            else
                            {   
                                int durn=-1;
                                // got_id_func_cap2->second 是开始时间
                                //如果开始时间是设置的…0…值,是已经报过了则不报。
                                if(got_id_func_cap2->second.startPoint > std::chrono::system_clock::from_time_t(0))
                                {
                                    if(stayconfig.isMotionless)//要检测到静止之后开始计时
                                    {
                                        //与box_det求ioa
                                        // intersection over union
                                        inter_area = intersection_area(obj, got_id_func_cap2->second.detresult);
                                        union_area = obj.rect.area() + got_id_func_cap2->second.detresult.rect.area() - inter_area;


                                        //本次检测框与上一次IOU > 0.85 认为是静止
                                        if(inter_area / union_area > 0.85  ) //认为是静止了，那么上次的startPoint OK.
                                        {
                                            durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - got_id_func_cap2->second.startPoint).count();

                                        }else
                                        {
                                            got_id_func_cap2->second.startPoint=std::chrono::system_clock::now();//非静止，更新上次的startPoint.
                                        }

                                        got_id_func_cap2->second.detresult=obj;


                                    }else
                                    {
                                        durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - got_id_func_cap2->second.startPoint).count();
                                    }

                                    ANNIWOLOG(INFO) <<"safeEreaDetection.detect:isMotionless:"<<stayconfig.isMotionless<<" trackID "<<trackID<<" durn:"<<durn<<" camID:"<<camID;

                                    if(durn > stayconfig.staySec)
                                    {
                                        bIsStayConfigCheckOK = true;
                                        //#对一个trackid对应的物体，如超时后报警过一次，
                                        //deepsort逻辑:\出了跟踪区域(以miss 100次为准)后删除track
                                        got_id_func_cap2->second.startPoint=std::chrono::system_clock::from_time_t(0);

                                    }

                                }

                            }
                        }
                    }
                    //////////////
                    if(bIsStayConfigCheckOK)
                    {
                        newpersonvehicleCnt++;
                        perCamIDhistory.insert(std::pair<int,int>(trackID,1) );
                    }

                }
                else
                {
                    ANNIWOLOG(INFO) <<"safeEreaDetection: found tracked&reported..trackID:"<<trackID<<"camID:"<<camID<<std::endl;
                }
            }

        }
    }

    if(newpersonvehicleCnt <= 0 )
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:DEBUG: no new person, camID:"<<camID;
        return newpersonvehicleCnt;
    }
    if( !bIsStayConfigCheckOK )
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:DEBUG: no because stay config not ok, camID:"<<camID;
        return 0;
    }


    if(offend_boxes_det.size() <= 0)
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:filteredObjects size 0,camID:"<<camID;
    }else
    {
        if(isResultDuplicated(allLastObjects[camID],offend_boxes_det))
        {
            ANNIWOLOG(INFO) <<"WindowDetection:Duplicated results.Ignored.camID:"<<camID<<std::endl;
            allLastObjects[camID]=offend_boxes_det;

            return 0;
        }
    }

    //update history results
    allLastObjects[camID]=offend_boxes_det;


    for (auto& obj : offend_boxes_det) {
        // int trackID = (int)obj.trackID;

        int x = obj.rect.x;
        int y = obj.rect.y;
        int width = obj.rect.width;
        int height = obj.rect.height;

        ANNIWOLOG(INFO) <<"safeEreaDetection:DEBUG: obj x1:"<<x<<"y1:"<<y<<"width:"<<width<<"height:"<<height<<"camID:"<<camID;
        ANNIWOLOG(INFO) <<"safeEreaDetection:DEBUG: obj orig_img_w:"<<orig_img_w <<"orig_img_h:"<<orig_img_h<<"camID:"<<camID;

#ifdef ANNIWO_INTERNAL_DEBUG
        //todo:Below is leave for debugging!
        cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
        float c_mean = cv::mean(color)[0];
        cv::Scalar txt_color;
        if (c_mean > 0.5){
            txt_color = cv::Scalar(0, 0, 0);
        }else{
            txt_color = cv::Scalar(255, 255, 255);
        }

        cv::rectangle(img, obj.rect, color * 255, 2);

        char text[256];
        sprintf(text, "%s %.1f%% tid:%d", person_base_class_namesCOCO[obj.label].c_str(), obj.prob * 100, trackID);
        ANNIWOLOGF(INFO,"safeEreaDetection:%s %.1f tid:%d x:%d y:%d w:%d h:%d ,camID:%d\n", \
            person_base_class_namesCOCO[obj.label].c_str(), obj.prob, trackID,x,y,width,height,camID);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        cv::Scalar txt_bk_color = color * 0.7 * 255;

        x = obj.rect.x;
        y = obj.rect.y + 1;
        if (y > img.rows)
            y = img.rows;

        cv::rectangle(img, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      txt_bk_color, -1);

        cv::putText(img, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
#endif
    }

    return newpersonvehicleCnt;
}

//objects是基于person_base_class_namesJYZ
void safeEreaDetection::mainfunc2(int camID,int instanceID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{
    std::vector<Object>  objectsCloned = objects;

    std::vector<Object> offendPersonVehicleObjects;

    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int offendnewPersonCnt=0;
    writer.StartArray();    



    int img_w = image.cols;
    int img_h = image.rows;


    //todo:以后优化这一块。
    std::set<std::string> concern_classes;
    std::set<std::string> exclude_classes;
    //取得关注类型
    //valid types
    //camId,{func,Vector<String>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::const_iterator got_id_func_cap = validtypes_map_ptr->find(camID);

    //  "person",
    //  "car",
    //  "motor",
    //  "bus",
    //  "truck",
    //  "tank_truck",
    //  "electrically_operated_car",
    //  "work_clothe_blue",
    //  "reflective_vest",
    //  "rider",
    //  "cement_truck"
    for(auto& clsn : person_base_class_namesJYZ)
    {
        if(    clsn  == std::string("person")
            || clsn == std::string("car")
            || clsn == std::string("motor")
            // || clsn == std::string("bus")   #bus易产生误报，电子围栏场景通常很少出现bus,故去除.
            || clsn == std::string("truck")
            || clsn == std::string("rider")
            || clsn == std::string("tank_truck")
            || clsn == std::string("electrically_operated_car")
            || clsn == std::string("cement_truck")
        )
        {
            concern_classes.insert(clsn);
        }
    }


    if (got_id_func_cap == validtypes_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "safeEreaDetection:not set in validtypes_conf_map for camID:" <<camID<<"use default classes";
        //use default all
    }
    else
    {
        const std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >::const_iterator got_id_func_cap2 = conf_map.find("safeErea");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "safeEreaDetection:not set safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";

            //use default all
        }
        else
        {
            const AnniwoSafeEreaConcernTypes& typesST = got_id_func_cap2->second;
            if(typesST.validtypes.size() == 0 )
            {
                ANNIWOLOG(INFO) << "safeEreaDetection:empty safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";
                //use default all

            }
            else if(typesST.validtypes.size() >= 1)
            {

                ANNIWOLOG(INFO) << "safeEreaDetection:used concern_classes from config for camID:" <<camID ;
                bool isVest=false;
                bool isworkclothesInside=false;
                concern_classes.clear();
                for(auto& onetype:typesST.validtypes)
                {
                    if(onetype == "person")
                    {
                        concern_classes.insert("person");
                    }
                    else if( onetype == "car")
                    {
                        concern_classes.insert("car");
                        // concern_classes.insert("motor");
                        // concern_classes.insert("bus");
                        // concern_classes.insert("truck");

                        // concern_classes.insert("tank_truck");
                        // concern_classes.insert("electrically_operated_car");
                        // concern_classes.insert("cement_truck");
                        // concern_classes.insert("rider");

                    }else
                    {
                        concern_classes.insert(onetype);
                    }


                }

                exclude_classes.clear();
                for(auto& onetype:typesST.excludeTypes)
                {
                    exclude_classes.insert(onetype);
                }

            }

        }
    }



    //日志打印
    for(auto& onetype:concern_classes)
    {
       ANNIWOLOG(INFO) << "safeEreaDetection:concern_classes for camID:" <<camID <<","<< onetype;
    }
    
    for(auto& onetype:exclude_classes)
    {
       ANNIWOLOG(INFO) << "safeEreaDetection:exclude_classes for camID:" <<camID <<","<< onetype;
    }
    


///////////////////////////////////////////////////////////////////////////////////////////////////////////
    float  inter_area=0.;
    float  gzf_area=0.;
    float  obj_area=0.;
    std::vector<int> clothes_classes;


    bool isClassToReport=false;//类型判断用

    for (size_t i = 0; i < objectsCloned.size(); i++)
    {
        const Object& obj = objectsCloned[i];
        clothes_classes.clear();


        //经常检测不到person,但有工作服，反光背心等
        if( person_base_class_namesJYZ[obj.label] == "person"
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_yellow")
        || person_base_class_namesJYZ[obj.label] == std::string("reflective_vest")
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_wathet") )
        {
            // #给这个人穿上衣服
            //  "person",
            //  "car",
            //  "motor",
            //  "bus",
            //  "truck",
            //  "tank_truck",
            //  "electrically_operated_car",
            //  "work_clothe_blue",
            //  "reflective_vest",
            //  "rider",
            //  "cement_truck"
            for(auto& gzf_obj:objectsCloned)
            {
                if(
                   person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
                || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_yellow")
                || person_base_class_namesJYZ[obj.label] == std::string("reflective_vest")
                || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_wathet")
                )
                {
                    //看看重合.
                    // intersection over union
                    inter_area = intersection_area(obj, gzf_obj);
                    gzf_area = gzf_obj.rect.area();
                    obj_area = obj.rect.area();

                    if( inter_area/gzf_area > 0.7 ||
                        inter_area/obj_area > 0.7 )
                    {
                        clothes_classes.push_back(gzf_obj.label);
                        gzf_obj.trackID = obj.trackID;   //给工作服赋予该人员的trackID,因为工作服无法跟踪
                    }

                }

            }

        }

        //日志打印
        for(auto& onelabel:clothes_classes)
        {
             ANNIWOLOG(INFO) << "safeEreaDetection:clothes_classes for this box of camID:" <<camID <<","<< onelabel;
        }

        //关注类别过滤,目前是传什么就报什么！！！
        isClassToReport=false;
        for(auto& onetype:concern_classes)
        {
            if(onetype == person_base_class_namesJYZ[obj.label])
            {
                isClassToReport=true;
                break;
            }

        }

        if(!isClassToReport)
        {
            continue;
        }

        ANNIWOLOG(INFO) <<
        "safeEreaDetection: detect. box:"<<obj.rect.x<<","<< obj.rect.y<<","
        <<obj.rect.width<<","<<obj.rect.height<<","
        << "score:"<<obj.prob<<"class:"<<person_base_class_namesJYZ[obj.label].c_str()<<","<<"trackid:"<<obj.trackID <<" camID:"<<camID;

        //人下部
        float x1=obj.rect.x;
        float y1 = obj.rect.y;
        float x2=(obj.rect.x+obj.rect.width) > img_w ? img_w : (obj.rect.x+obj.rect.width) ;
        float y2 =(obj.rect.y+obj.rect.height) > img_h ? img_h: (obj.rect.y+obj.rect.height);
        
        float y1_ = y1;
        if(person_base_class_namesJYZ[obj.label] == "person"
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_yellow")
        || person_base_class_namesJYZ[obj.label] == std::string("reflective_vest")
        || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_wathet")
        )  //人员要求小腿到脚部分在设定区域内
        {
            y1_ = (obj.rect.y+obj.rect.height/4.0*3.0) > y2 ? y2: (obj.rect.y+obj.rect.height/4.0*3.0);
        }



        float area = 0.0;
        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1_)));
            box_poly.add(cv::Point(int(x2),int(y1_)));
            box_poly.add(cv::Point(int(x2),int(y2)));
            box_poly.add(cv::Point(int(x1),int(y2)));
            _inter.clear();
            intersectPolygonSHPC(*polygonSafeArea_ptr,box_poly,_inter);
            //此处无交集时候size==0?
            if( _inter.size() ) {
                area = _inter.area();
                ANNIWOLOG(INFO) <<"safeEreaDetection: Area half object intersected = "<<area<<"camID:"<<camID;

                if(area > 768.0)
                {
                    //通过，在下面执行正常逻辑
                    ANNIWOLOG(INFO) <<
                        "safeEreaDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<person_base_class_namesJYZ[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;

                }else
                {
                    ANNIWOLOG(INFO) <<
                        "safeEreaDetection: detect.Ignore checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<person_base_class_namesJYZ[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    //忽略这个对象!
                    continue;
                }

            }else
            {
                ANNIWOLOG(INFO) <<"safeEreaDetection: Area intersected None: "<<area<<"camID:"<<camID;
                continue;

            }
        }else
        {
            ANNIWOLOG(INFO) <<"safeEreaDetection: Area not setting! "<<area<<"camID:"<<camID;
        }

        //check exclude types
        isClassToReport=true;

        if(
            (   person_base_class_namesJYZ[obj.label] == "person"
                || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
                || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_yellow")
                || person_base_class_namesJYZ[obj.label] == std::string("reflective_vest")
                || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_wathet")
            ) && exclude_classes.size() > 0 
        )//person类别,检测框可能重合，检查excludetypes
        {
            for(int i=0; i < clothes_classes.size(); i++)
            {
                if(isClassToReport)
                {
                    for(auto& onetype:exclude_classes)
                    {
                        if( onetype  ==  person_base_class_namesJYZ[clothes_classes[i]] )
                        {
                            isClassToReport=false;
                            ANNIWOLOG(INFO) <<"safeEreaDetection: found in exclude types setting:"<<onetype<<" camID:"<<camID;

                            break;
                        }

                    }
                }else
                {
                    break;
                }
                 
            }
            
        }

        if(!isClassToReport)
        {
            ANNIWOLOG(INFO) <<"safeEreaDetection: Ignored by exclude types setting."<<"camID:"<<camID;
            continue;
        }
        
        Object objPerson;
        objPerson.rect.x=obj.rect.x;
        objPerson.rect.y=obj.rect.y;
        objPerson.rect.width =obj.rect.width;
        objPerson.rect.height=obj.rect.height;
        objPerson.trackID=obj.trackID;
        objPerson.prob= obj.prob;
        objPerson.label = obj.label;
        strncpy((char*)objPerson.uuid, (char*)obj.uuid, sizeof(uuid_t));


        offendPersonVehicleObjects.emplace_back(objPerson);

        //Only record and report  which inside the area!
        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("y1");                
        writer.Int(y1);            
        writer.Key("x1");                
        writer.Int(x1);  
        writer.Key("y2");                
        writer.Int(y2);  
        writer.Key("x2");                
        writer.Int(x2);  
        writer.Key("classItem");                // output a key,
        //类别名要加上工作服.
        //python:self.coco_jyz_car_combined_classes[cl]+","+','.join(clothes_classes)

        if(person_base_class_namesJYZ[obj.label] == "person")//person类别
        {
            std::stringstream buffer;  
            buffer << person_base_class_namesJYZ[obj.label].c_str(); 
            for(int i=0; i < clothes_classes.size(); i++)
            {
                const std::string& pt=person_base_class_namesJYZ[clothes_classes[i]] ;

                buffer << ","<<pt.c_str(); 
                 
            }
            std::string vecValuestr(buffer.str());

            writer.String(vecValuestr.c_str());             
        }else
        {
            writer.String(person_base_class_namesJYZ[obj.label].c_str()); 
        }

        if(area > 0.0 )
        {
            writer.Key("intersectera");
            writer.Double(area);
        }

        writer.EndObject();  



    }


    writer.EndArray();

/////////////TRACKING PART//////////////////////////////////

    if(offendPersonVehicleObjects.size() > 0 )
    {

        offendnewPersonCnt = deDuplicateTrackResults(camID,image,offendPersonVehicleObjects);

    }else
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:no offendPersonVehicleObjects"<<"camID:"<<camID<<" "<<std::endl;
        return;

    }

/////////////TRACKING PART END//////////////////////////////////


    if(offendnewPersonCnt > 0)
    {
        /////////DEBUG图片输出
        // anniwo_debug_draw_objects(image, offendPersonVehicleObjects, "./", true);


        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/safeErea/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/intrusion"};

        getTaskId(globalJsonConfObjPtr,camID,"safeErea",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"safeErea","/intrusion",submitUrl);

        ANNIWOLOG(INFO) <<"safeEreaDetection:save file name drawed is:"<<"camID:"<<camID<<" "<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);
    }else
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:no offendnewPersonCnt"<<"camID:"<<camID<<" "<<std::endl;
        return;


    }



}


 void safeEreaDetection::mainfunc(int camID, int instanceID,  cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{

    std::vector<Object> offendPersonVehicleObjects;

    cv::Mat image = bgr;
    bgr.release();
    
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int offendnewPersonCnt=0;
    writer.StartArray();    



    int img_w = image.cols;
    int img_h = image.rows;


    
    std::set<std::string> concern_classes;
    //取得关注类型
    //valid types
    //camId,{func,AnniwoSafeEreaConcernTypes}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::const_iterator got_id_func_cap = validtypes_map_ptr->find(camID);

    if (got_id_func_cap == validtypes_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "safeEreaDetection:not set in validtypes_conf_map for camID:" <<camID<<"use default classes";
        concern_classes.insert("person");
        concern_classes.insert("car");
        concern_classes.insert("bicycle");
        concern_classes.insert("motorcycle");
        concern_classes.insert("bus"); 
        concern_classes.insert("truck");
    }
    else
    {
        const std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>::const_iterator got_id_func_cap2 = conf_map.find("safeErea");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "safeEreaDetection:not set safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";

            concern_classes.insert("person");
            concern_classes.insert("car");
            concern_classes.insert("bicycle");
            concern_classes.insert("motorcycle");
            concern_classes.insert("bus"); 
            concern_classes.insert("truck");
        }
        else
        {
            const AnniwoSafeEreaConcernTypes& typesST = got_id_func_cap2->second;
            if(typesST.validtypes.size() == 0 )
            {
                ANNIWOLOG(INFO) << "safeEreaDetection:empty safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";
                concern_classes.insert("person");
                concern_classes.insert("car");
                concern_classes.insert("bicycle");
                concern_classes.insert("motorcycle");
                concern_classes.insert("bus"); 
                concern_classes.insert("truck");
            }
            else  if(typesST.validtypes.size() >= 1)
            {
                ANNIWOLOG(INFO) << "safeEreaDetection:used concern_classes from config for camID:" <<camID ;

                for(auto& onetype:typesST.validtypes)
                {
                    if(onetype == "person")
                    {
                        concern_classes.insert("person");
                    }
                    else if( onetype == "car")
                    {
                        concern_classes.insert("car");
                        concern_classes.insert("bicycle");
                        concern_classes.insert("motorcycle");
                        concern_classes.insert("bus"); 
                        concern_classes.insert("truck");
                    }
                    else
                    {
                        concern_classes.insert(onetype);
                    }

                }
            }
        }
    }



    //日志打印
    for(auto& onetype:concern_classes)
    {
       ANNIWOLOG(INFO) << "safeEreaDetection:concern_classes for camID:" <<camID << onetype;
    }

///////////////////////////////////////////////////////////////////////////////////////////////////////////
    bool isClassToReport=false;//类型判断用

    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];


        //关注类别过滤
        isClassToReport=false;
        for(auto& onetype:concern_classes)
        {
            if(onetype == person_base_class_namesCOCO[obj.label])
            {
                isClassToReport=true;
                break;
            }
            
        }
        if(!isClassToReport)
        {
            continue;
        }


        ANNIWOLOG(INFO) <<
        "safeEreaDetection: detect. box:"<<obj.rect.x<<","<< obj.rect.y<<","
        <<obj.rect.width<<","<<obj.rect.height<<","
        << "score:"<<obj.prob<<"class:"<<person_base_class_namesCOCO[obj.label].c_str()<<","<<"trackid:"<<obj.trackID <<" camID:"<<camID;

        float x1=obj.rect.x;
        float y1 = obj.rect.y;
        float x2=(obj.rect.x+obj.rect.width) > img_w ? img_w : (obj.rect.x+obj.rect.width) ;
        float y2 =(obj.rect.y+obj.rect.height) > img_h ? img_h: (obj.rect.y+obj.rect.height);


        

        float area = 0.0;
        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y2)));
            box_poly.add(cv::Point(int(x1),int(y2)));
            _inter.clear();
            intersectPolygonSHPC(*polygonSafeArea_ptr,box_poly,_inter);
            //此处无交集时候size==0?
            if( _inter.size() ) {
                area = _inter.area();
                // cv::Point center = _inter.getCenter();
                // ANNIWOLOGF(INFO,"safeEreaDetection: Area intersected = %0.1f ,camID:%d\n",area,camID);
                ANNIWOLOG(INFO) <<"safeEreaDetection: Area intersected = "<<area<<"camID:"<<camID;

                if(area > 768.0)
                {

                    ANNIWOLOG(INFO) <<
                        "safeEreaDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<person_base_class_namesCOCO[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;

                }else
                {
                    ANNIWOLOG(INFO) <<
                        "safeEreaDetection: detect.Ignore checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<person_base_class_namesCOCO[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    continue;
                }

            }else
            {
                // ANNIWOLOGF(INFO,"safeEreaDetection: Area intersected None. ,camID:%d\n",area,camID);
                ANNIWOLOG(INFO) <<"safeEreaDetection: Area intersected None: "<<area<<"camID:"<<camID;
                continue;

            }
        }else
        {
            ANNIWOLOG(INFO) <<"safeEreaDetection: Warn.No erea setting! "<<"camID:"<<camID;
        }


        Object objPerson;
        objPerson.rect.x=obj.rect.x;
        objPerson.rect.y=obj.rect.y;
        objPerson.rect.width =obj.rect.width;
        objPerson.rect.height=obj.rect.height;
        objPerson.trackID=obj.trackID;
        objPerson.prob= obj.prob;
        objPerson.label = obj.label;
        strncpy((char*)objPerson.uuid, (char*)obj.uuid, sizeof(uuid_t));


        offendPersonVehicleObjects.emplace_back(objPerson);

        //Only record and report  which inside the area!
        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("y1");                
        writer.Int(y1);            
        writer.Key("x1");                
        writer.Int(x1);  
        writer.Key("y2");                
        writer.Int(y2);  
        writer.Key("x2");                
        writer.Int(x2);  
        writer.Key("classItem");                // output a key,
        writer.String(person_base_class_namesCOCO[obj.label].c_str());             // follow by a value.
        if(area > 0.0 )
        {
            writer.Key("intersectera");
            writer.Double(area);
        }

        writer.EndObject();  
        




    }


    writer.EndArray();

/////////////TRACKING PART//////////////////////////////////

    if(offendPersonVehicleObjects.size() > 0 )
    {

        offendnewPersonCnt = deDuplicateTrackResults(camID,image,offendPersonVehicleObjects);

    }else
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:no offendPersonVehicleObjects"<<"camID:"<<camID<<" "<<std::endl;
        return;

    }

/////////////TRACKING PART END//////////////////////////////////


    if(offendnewPersonCnt > 0)
    {

        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/safeErea/" + imagename;

        
        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/intrusion"};

        getTaskId(globalJsonConfObjPtr,camID,"safeErea",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"safeErea","/intrusion",submitUrl);

        ANNIWOLOG(INFO) <<"safeEreaDetection:save file name drawed is:"<<"camID:"<<camID<<" "<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);
    }else
    {
        ANNIWOLOG(INFO) <<"safeEreaDetection:no offendnewPersonCnt"<<"camID:"<<camID<<" "<<std::endl;
        return;


    }



}




void safeEreaDetection::initTracks(
    const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    stay_conf_map_ptr=&globalJsonConfObj.stay_conf_map;
    validtypes_map_ptr=&globalJsonConfObj.validtypes_map;

    globalJsonConfObjPtr=&globalJsonConfObj;

    allLastObjects.clear();

    // static const std::unordered_map<int,std::unordered_map<int, std::chrono::system_clock::time_point>  > trackStayMap;
    trackStayMap.clear();
    reporthistoryArray.clear();

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        vestClassier->initTracks(globalJsonConfObj);

    }

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("safeErea") )
            {
                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "safeEreaDetection::initTracks:reporthistory insert" <<"camID:"<<camID<<" ";
                reporthistoryArray.insert(std::pair<int, std::unordered_map<int, int >  >(camID,trackidhits) );


                std::unordered_map<int, AnniwoTrackRecord > emptymp;
                trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(camID,emptymp) );

                std::vector<Object> emptyObjArray;
                ANNIWOLOG(INFO) << "safeEreaDetection::initTracks:allLast insert" <<"camID:"<<camID<<" ";
                allLastObjects.insert(std::pair<int, std::vector<Object>  >(camID,emptyObjArray) );


                break;
            }
            else
            {
                continue;
            }
        }
    }


}
//todo:polygonSafeArea
void safeEreaDetection::detect(  int camID, int instanceID, cv::Mat img,const Polygon* polygonSafeArea_ptr,const std::vector<Object>& results) 
{    
    if(results.size() > 0)
    {
        cv::Mat image = img;
        

        if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
        {
            ANNIWOLOG(INFO) << "safeEreaDetection: domain is jiayouzhan" <<"camID:"<<camID<<" ";

            std::vector<Object>  resultsCloned = results;
    
            for (size_t i = 0; i < resultsCloned.size(); i++)
            {
                Object& obj = resultsCloned[i];

                //经常检测不到person,但有工作服，反光背心等
                if( person_base_class_namesJYZ[obj.label] == "person"
                   || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
                // || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_yellow")
                // || person_base_class_namesJYZ[obj.label] == std::string("reflective_vest")
                // || person_base_class_namesJYZ[obj.label] == std::string("work_clothe_wathet") 
                )
                {

                    int x1=obj.rect.x;
                    int y1 = obj.rect.y;
                    int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
                    int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);

                    //判断是否为反光衣
                    ///////////////////////进行加油机切图分类
                    //保存切图，用于分类
                    int oilingm_h=y2-y1;
                    int oilingm_w=x2-x1;

                    cv::Mat cut_img(oilingm_h, oilingm_w, CV_8UC3, cv::Scalar(114, 114, 114));
                    image(cv::Rect(x1, y1, oilingm_w, oilingm_h)).copyTo(cut_img(cv::Rect(0, 0, oilingm_w, oilingm_h)));




                    ////////////////////////////////////分类过滤/////////////////////////////////////////////
                    //进行分类判断，仅通过分类判断的才认为是真正的反光背心
                    //分类模型检测
                    // "wrong",
                    // "right"
                    std::vector<float> mobilenetResults;

                    //
                    vestClassier->detect(camID,instanceID,cut_img, mobilenetResults);
                    
                    // //debug
                    // std::string imagename=getRandomName();
                    // std::string imgPath = "./jiayouji/" + imagename;
                    // cv::imwrite(imgPath,cut_img);
                    // ANNIWOLOG(INFO) << "JiayoujiDetection:debug save name"<<imagename <<"camID:"<<camID ;    

                    int predictcls=0; //"wrong"
                    if(mobilenetResults.size() >= 3)
                    {
                        //
                        std::vector<std::size_t> gridwhshape = {3};
                        //todo:注意！ auto 类型 xtensor adapt来的，reshape不能用！
                        //               arrange来的，reshape也不能用!!!
                        auto probs= xt::adapt(mobilenetResults,gridwhshape);
                        auto mobilenetclass=xt::argmax(probs);
                        ANNIWOLOG(INFO)<<"safeEreaDetection vest: clsnet:"<<mobilenetclass <<",camID:"<<camID ;
                        predictcls=mobilenetclass(0);
                    }else
                    {
                        ANNIWOCHECK(false);
                    }

                    ///////////////////////
                    if( person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue")
                        && predictcls == 2)//"weilan_vest"
                    {
                        ANNIWOLOG(INFO) << "safeEreaDetection: convert "<<person_base_class_namesJYZ[obj.label]<<" to reflective_vest." <<"camID:"<<camID<<" ";

                        obj.label=7;//"reflective_vest"
                        ANNIWOCHECK(person_base_class_namesJYZ[obj.label] == std::string("reflective_vest"));

                    }
                    if( person_base_class_namesJYZ[obj.label] == std::string("person")
                        && predictcls == 0)//"weilan_blue"
                    {
                        ANNIWOLOG(INFO) << "safeEreaDetection: convert "<<person_base_class_namesJYZ[obj.label]<<" to work_clothe_blue." <<"camID:"<<camID<<" ";
                        obj.label=0;//"work_clothe_blue"
                        ANNIWOCHECK(person_base_class_namesJYZ[obj.label] == std::string("work_clothe_blue"));

                    }

                }
            }


            //工作服判断放在safeArea里边。加油站人车放到basePerson里边
            mainfunc2(camID,instanceID, image, resultsCloned,polygonSafeArea_ptr);
        }else
        {
            mainfunc(camID,instanceID,  image, results,polygonSafeArea_ptr);

        }

        image.release();
    }
    else
    {
        ANNIWOLOG(INFO) << "safeEreaDetection:no objects" <<"camID:"<<camID<<" ";
    }


    ANNIWOLOG(INFO) << "safeEreaDetection:exit detect()" <<"camID:"<<camID<<" ";
    
    return;
}
