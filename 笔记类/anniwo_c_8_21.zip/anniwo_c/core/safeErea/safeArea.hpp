#ifndef YOLOX_SAFEAREA_H
#define YOLOX_SAFEAREA_H
#include <opencv2/opencv.hpp>
#include "../utils/utils_intersection.hpp"
#include "../common/yolo/yolo_common.hpp"



class safeEreaDetection  {
    public:
        safeEreaDetection() ;
        ~safeEreaDetection() ;

        void initTracks(
            const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);

        //todo:polygonSafeArea
        static void detect(  int camID, int instanceID,cv::Mat img,  const Polygon* polygonSafeArea_ptr,const std::vector<Object>& results);

    private:
        static void mainfunc2(int camID,int instanceID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr);
        static void mainfunc(int camID,int instanceID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr);
        

        
};

#endif // YOLOX_DEMO_H

