#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include <dirent.h>


#include "helmet.hpp"

#include "utils.h"

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"

#include "../personbase/basePerson.hpp"

#include "../common/yolo/yolo_common.hpp"




#include "../common/mot/include/deepsort.h"
#include <uuid/uuid.h>






static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;


// static const int NUM_CLASSES = 20;  //yolox
static const int NUM_CLASSES = 4;  //
static const int NUM_CLASSES_INUSE = 4;

static  float BBOX_CONF_THRESH = 0.3;   //ini可设置
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);




//使用vector<char*>有问题。
static const std::vector<std::string>  class_names = {
"person",
"normal_head",
"helmet_head",
"helmet_head_indistinct"
};
static std::unordered_map<int, std::unordered_map<int, int > > reporthistoryArray ;


const static std::string model_file={"../models/helmet/best_model_helmet_sim.trt"};

static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};

static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;



const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf


std::unordered_map<int, std::vector<float> >  HelmetDetection::m_input_datas;


// Default constructor
HelmetDetection::HelmetDetection () { 

    ANNIWOLOG(INFO) << "HelmetDetection(): call initInferContext!" ;

    gpuNum = initInferContext(
                    model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "HelmetDetection(): Success initialized!" ;


}

// Destructor
HelmetDetection::~HelmetDetection () {
    // destroy the engine

    delete engine;
    delete runtime;

}


static int PostProcessResults(int camID,rapidjson::Writer<rapidjson::StringBuffer>& writer,cv::Mat img,  std::vector<Object>& helmetObjects,const std::vector<Object>& personObjects,const Polygon* polygonSafeArea_ptr) {
    int orig_img_w = img.cols;
    int orig_img_h = img.rows;

    cv::Mat temp = img;

    int nowearCnt=0;
    // int x=0;
    // int y=0;

    float inter_area  = 0.0;
    float person_area = 0.0;
    float helmet_area = 0.0;
    float boxsize = 0.0;

    std::vector<Object>  helmetObjectsFiltered;
    bool isThisPersonNotWearHelmet=false;
    bool isThisPersonDistinct=false;

    for (auto& person_det : personObjects) {

        if(! isPerson(person_det.label))
            continue;


        int trackID = person_det.trackID;

        //判断该人是否是normal head.
        isThisPersonNotWearHelmet=false;
        isThisPersonDistinct=false;


        //人过滤安全帽框过滤，剩下安全帽
        for (size_t i = 0; i < helmetObjects.size(); i++)
        {
            Object& obj = helmetObjects[i];

            if(obj.label > NUM_CLASSES_INUSE || class_names[obj.label] == std::string("person") )
            {
                continue;
            }



            if(class_names[obj.label] == std::string("helmet_head_indistinct"))//yolo安全帽里边的人,模糊安全帽的类别忽略.
            {
                ANNIWOLOGF(INFO, "HelmetDetection:camID:%d   %s at x:%.2f y:%.2f w:%.2f  h:%.2f helmet head indistinct ignored\n",
                camID, class_names[obj.label].c_str(), 
                obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);
                continue;
            }

            // if(class_names[obj.label] == std::string("person_indistinct"))//yolo安全帽里边的,模糊人
            //  {
            //     //看看person是否和当前框重合.
            //     // intersection over union
            //     inter_area = intersection_area(obj, person_det);
            //     // person_area = person_det.rect.area();
            //     helmet_area = obj.rect.area();
            //     // float IoU = inter_area / union_area
            //     if (inter_area / helmet_area >= 0.9 )
            //     {
            //         isThisPersonDistinct=true;
            //         ANNIWOLOGF(INFO, "HelmetDetection:camID:%d   %s at x:%.2f y:%.2f w:%.2f  h:%.2f person indistinct ignored\n",
            //         camID, class_names[obj.label].c_str(), 
            //         obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);
            //     }
                
            //     break;//该person模糊，被忽略
            //  }


            boxsize = obj.rect.width*obj.rect.height;
            if (boxsize < 8.0) // 像素太小
            {
                continue;
            }
            if(obj.prob < BBOX_CONF_THRESH)
            {
                continue;
            }


            //与box_det求ioa
            // intersection over union
            inter_area = intersection_area(obj, person_det);
            person_area = person_det.rect.area();
            helmet_area = obj.rect.area();
            // float IoU = inter_area / union_area
            if (inter_area / person_area < 0.3  && inter_area / helmet_area > 0.9 )
            {
                //判断有没有带安全帽
                if( isThisPersonNotWearHelmet==false && class_names[obj.label] == std::string("normal_head") )
                {
                    isThisPersonNotWearHelmet = true;
                }

                if(class_names[obj.label] == std::string("normal_head") )
                {
                    obj.trackID = trackID;
                    helmetObjectsFiltered.push_back(obj);

                    ANNIWOLOGF(INFO, "HelmetDetection:camID:%d   %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n",
                    camID,  class_names[obj.label].c_str(), obj.prob,
                    obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);
                }



            }
                
        }

        if( isThisPersonNotWearHelmet&& (!isThisPersonDistinct) )
        {
            nowearCnt++;
        }
    }

    //
    if(nowearCnt <= 0)
    {
        ANNIWOLOG(INFO) <<"HelmetDetection:No person not wear helmet, no draw"<<"camID:"<<camID<<std::endl;
        return 0;
    }

    //todo:Below is leave for debugging!
#ifdef ANNIWO_INTERNAL_DEBUG
    for (auto& person_det : personObjects) {
        int trackID = (int)person_det.trackID;

        cv::Scalar color = cv::Scalar(color_list[person_det.label][0], color_list[person_det.label][1], color_list[person_det.label][2]);
        float c_mean = cv::mean(color)[0];
        cv::Scalar txt_color;
        if (c_mean > 0.5){
            txt_color = cv::Scalar(0, 0, 0);
        }else{
            txt_color = cv::Scalar(255, 255, 255);
        }

        cv::rectangle(img, person_det.rect, color * 255, 2);

        char text[256];
        sprintf(text, "%s %.1f%% tid:%d", getPersonCarbaseClassName(person_det.label).c_str(), person_det.prob * 100, trackID);
        ANNIWOLOGF(INFO,"HelmetDetection:%s %.1f tid:%d x:%.2f y:%.2f w:%.2f  h:%.2f camID:%d\n", getPersonCarbaseClassName(person_det.label).c_str(), person_det.prob, trackID,person_det.rect.x,person_det.rect.y,person_det.rect.width,person_det.rect.height,camID);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        cv::Scalar txt_bk_color = color * 0.7 * 255;

        x = person_det.rect.x;
        y = person_det.rect.y + 1;
        if (y > img.rows)
            y = img.rows;

        cv::rectangle(img, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      txt_bk_color, -1);

        cv::putText(img, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
    }
#endif

    writer.StartArray();    

    bool hasNewNotReported=false;
    for (auto& helmet_det : helmetObjectsFiltered) {
        
        float x1=helmet_det.rect.x;
        float y1 = helmet_det.rect.y;
        float x2=(helmet_det.rect.x+helmet_det.rect.width) > orig_img_w ? orig_img_w : (helmet_det.rect.x+helmet_det.rect.width) ;
        float y2 =(helmet_det.rect.y+helmet_det.rect.height) > orig_img_h ? orig_img_h: (helmet_det.rect.y+helmet_det.rect.height);
        int trackID = helmet_det.trackID;


/////////////////标识报过一次.
        if(trackID == -1)
        {
            hasNewNotReported=true;  //报警但不记录
        }else
        {
            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"HelmetDetection: Final check report. Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);

                if (got_it2 == perCamIDhistory.end())//new to this camID
                {
                    if(class_names[helmet_det.label] == std::string("normal_head") )
                    {
                        perCamIDhistory.insert(std::pair<int,int>(trackID,1) );
                        hasNewNotReported=true;
                    }
                }
                else
                {
                    got_it2->second++;
                    ANNIWOLOG(INFO) <<"HelmetDetection: Final check report. found reported.trackID:"<<trackID<<"camID:"<<camID<<std::endl;
                }
            }
        }


/////////////////



        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("y1");                
        writer.Int(y1);            
        writer.Key("x1");                
        writer.Int(x1);  
        writer.Key("y2");                
        writer.Int(y2);  
        writer.Key("x2");                
        writer.Int(x2);  
        writer.Key("classItem");                // output a key,
        writer.String(class_names[helmet_det.label].c_str());             // follow by a value.

        writer.EndObject();

        //todo:Below is leave for debugging!
#ifdef ANNIWO_INTERNAL_DEBUG
        cv::Scalar color = cv::Scalar(color_list[helmet_det.label][0], color_list[helmet_det.label][1], color_list[helmet_det.label][2]);
        float c_mean = cv::mean(color)[0];
        cv::Scalar txt_color;
        if (c_mean > 0.5){
            txt_color = cv::Scalar(0, 0, 0);
        }else{
            txt_color = cv::Scalar(255, 255, 255);
        }

        cv::rectangle(img, helmet_det.rect, color * 255, 2);

        char text[256];
        sprintf(text, "%s %.1f%% ", class_names[helmet_det.label].c_str(), helmet_det.prob * 100);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        cv::Scalar txt_bk_color = color * 0.7 * 255;

        x = helmet_det.rect.x;
        y = helmet_det.rect.y + 1;
        if (y > img.rows)
            y = img.rows;

        cv::rectangle(img, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      txt_bk_color, -1);

        cv::putText(img, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
#endif
    }

    writer.EndArray();

    if(hasNewNotReported)
    {
        return nowearCnt;
    }else
    {
        ANNIWOLOG(INFO) <<"HelmetDetection: NO hasNewNotReported"<<"camID:"<<camID<<std::endl;
        return 0;
    }


}

static void mainfunc(int camID, cv::Mat bgr, std::vector<Object>& helmetObjects, const std::vector<Object>& in_personObjects, const Polygon* polygonSafeArea_ptr)
{


    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;



    if(in_personObjects.size() > 0)
    {

        jsonObjCnt = PostProcessResults(camID,writer,image,helmetObjects,in_personObjects,polygonSafeArea_ptr);

    }


    //
    if(jsonObjCnt > 0)
    {

        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/helmet/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/helmet"};

        getTaskId(globalJsonConfObjPtr,camID,"helmet",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"helmet","/helmet",submitUrl);


        ANNIWOLOG(INFO) <<"HelmetDetection:save file name drawed is:"<<"camID:"<<camID<<" "<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);
    }


}






void HelmetDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{


    //取得设置的阈值 thesholdsetting
    std::unordered_map<std::string, float  >::iterator  got_theshold= globalINICONFObj.thesholdsetting.find(std::string("helmet"));

    if (got_theshold == globalINICONFObj.thesholdsetting.end())
    {
        ANNIWOLOG(INFO) <<"HelmetDetection::initTracks: f is not thesholdsetting....use default.f: "<<"helmet" <<" default:"<<BBOX_CONF_THRESH;
    }else
    {
        BBOX_CONF_THRESH=got_theshold->second;
        ANNIWOLOG(INFO) <<"HelmetDetection::initTracks: f in thesholdsetting....use.f: "<<"helmet" <<" value:"<<BBOX_CONF_THRESH;
    }



    reporthistoryArray.clear();
    executionContexts.clear();
    contextlocks.clear();

    cudaSetDevice(gpuNum);


    globalJsonConfObjPtr=&globalJsonConfObj;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter)
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("helmet") )
            {
                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "HelmetDetection::initTracks: reporthistory insert" <<"camID:"<<camID<<" ";
                reporthistoryArray.insert(std::pair<int, std::unordered_map<int, int >  >(camID,trackidhits) );

                break;
            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_HELMET;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }



    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_FIRE个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_HELMET)
    {
        ANNIWOLOG(INFO) << "HelmetDetection::initTracks: insert thread" <<"cntID:"<<cntID<<" ";

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

        ////////////////////////

        cntID++;
    }

}

//todo:polygonSafeArea
void HelmetDetection::detect(  int camID,int instanceID,  cv::Mat img,const Polygon* polygonSafeArea_ptr,const std::vector<Object>& person_det_results) 
{    

    int newpersonCnt=0;

    Polygon _inter;
    Polygon box_poly;

    cv::Mat image = img;
    


    std::vector<Object> person_det_resultsInside;
    for (auto& obj : person_det_results) {

        if( ! isPerson(obj.label) )
            continue;
    
        int x1=obj.rect.x;
        int y1 = obj.rect.y;
        int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
        // int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);
        int y2up =(obj.rect.y+obj.rect.height/4) > image.rows ? image.rows : (obj.rect.y+obj.rect.height/4);

        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y2up)));
            box_poly.add(cv::Point(int(x1),int(y2up)));
            _inter.clear();
            intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
            if( _inter.size() ) {
                float area = _inter.area();
                // cv::Point center = _inter.getCenter();
                // ANNIWOLOGF(INFO,"HelmetDetection: Area intersected = %0.1f \n",area);
                ANNIWOLOG(INFO) <<"HelmetDetection: Area intersected = "<<area<<"camID:"<<camID;

                if(area <= 10.0)
                {

                    ANNIWOLOG(INFO) <<
                        "HelmetDetection: detect.Ignored not in valid area:check box:"<<obj.rect.x<<","<< obj.rect.y<<","<< obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<class_names[obj.label].c_str()<<"intersectArea:"<<area<<" camID:"<<camID;

                    continue;

                }else
                {

                    std::stringstream buffer;  
                    for(int i=0; i < polygonSafeArea_ptr->size(); i++)
                    {
                        const cv::Point& pt=polygonSafeArea_ptr->pt[i];
                        buffer << pt.x<<","<<pt.y<<" ";  
                    }
                    std::string text(buffer.str());

                    ANNIWOLOG(INFO) << "HelmetDetection: detect:area inter biggger than 10,camId:" 
                    <<camID<<"obj label:"<<obj.label
                    <<"x1,y1,x2,y2up:"<<x1<<","<<y1<<","<<x2<<","<<y2up<<" validArea:"<<text;


                    person_det_resultsInside.push_back(obj);
                }


            }else
            {
                ANNIWOLOG(INFO) << "HelmetDetection: detect:_inter.size else,camId:" <<camID<<" _inter.size():"<<_inter.size();
                continue;
            }
        }else//use all
        {
            ANNIWOLOG(INFO) << "HelmetDetection: detect: use all person_det_resultsInside.push_back,camId:" <<camID<<" polygonSafeArea_ptr:"<<polygonSafeArea_ptr;

            person_det_resultsInside.push_back(obj);
        }

        int trackID = (int)obj.trackID;
        if(trackID == -1)
        {
            newpersonCnt++;
        }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
        {

            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO)<<"HelmetDetection: Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);

                if (got_it2 == perCamIDhistory.end())//new to this camID,有一个新的则需要检测.
                {
                    newpersonCnt++;
                }else
                {
                    //找到一个之前报过的，需要检测是否超时? 目前deepsort里边有超时。
                    ANNIWOLOG(INFO) <<"HelmetDetection: found tracked&reported..trackID:"<<trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;

                }
            }

        }
    }

    //临时
    if(newpersonCnt <= 0 || person_det_resultsInside.size() <= 0)
    {
        ANNIWOLOG(INFO) << "HelmetDetection:  no new person exit detect()" <<"camID:"<<camID;
        return;
    }


    
    cudaSetDevice(gpuNum);

    std::vector<Object> objects;

    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_HELMET);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);

    
    if (iterCamInstance != executionContexts.end()) 
    {
        yolov4_detection_staff(m_input_datas,camID,instanceID,image,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,objects,BBOX_CONF_THRESH,NUM_CLASSES,
            "HelmetDetection");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }

    if(objects.size() > 0)
    {
        mainfunc(camID, image,objects, person_det_resultsInside,polygonSafeArea_ptr);
    }
    else
    {
        // //这一帧没有检测结果，有可能跟踪丢了，所以下一帧需要作为新的人.
        // std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

        // if (got_it == reporthistoryArray.end())
        // {
        //     loggerObj << WARNING <<"HelmetDetection: No result:Not in history map!!!"<<"camID:"<<camID<<std::endl;
        // }
        // else
        // {
        //     std::unordered_map<int, int >& perCamIDhistory = got_it->second;
        //     perCamIDhistory.clear();
        // }
        ANNIWOLOG(INFO) << "HelmetDetection:no helmet objects"<<"camID:"<<camID  <<"instanceID:"<<instanceID ;
    }



    image.release();
    ANNIWOLOG(INFO) << "HelmetDetection:exit detect()" <<"camID:"<<camID<<" " <<"instanceID:"<<instanceID ;
    
    return;
}
