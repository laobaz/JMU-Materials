#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <dirent.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"

#include <algorithm>

#include "../common/logging.h"

//todo:
#include "../common/ppyoloe/utils.h"

#include "convery.hpp"
#include "../personbase/basePerson.hpp"



static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;

mmdeploy::Detector* ConveryDetection::m_detptr=nullptr;

static std::unordered_map<int, std::unordered_map<int, int > > reporthistoryArray ;



const static std::string model_dir = {"../models/convery/"};


const int batch_size = 1;

//全局 mmdeploy 内部使用
nvinfer1::ILogger* pAnniwoNvlogger=nullptr;
std::mutex* pAnniwog_mtx4GpuQueue=nullptr;

std::vector<std::string> labels = {"Iron_frame","conveyer_belt","conveyor_end","wheels"};
const double CONFIDENCE_THRESHOLD=0.8;


//https://www.zhihu.com/question/38642943?sort=created
inline int get2LinesIntersectX(int x1,int y1,int x2,int y2, int x3, int y3, int x4, int y4)
{
  int fenmu=(x1*y2-y1*x2)*(x3-x4) -  (x1-x2)*(x3*y4-y3*x4);
  int fenzi=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4);
  return std::round(fenmu*1.0/fenzi+0.5);

}

inline  int get2LinesIntersectY(int x1,int y1,int x2,int y2, int x3, int y3, int x4, int y4)
{
  int fenmu=(x1*y2-y1*x2)*(y3-y4) -  (y1-y2)*(x3*y4-y3*x4);
  int fenzi=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4);
  return std::round(fenmu*1.0/fenzi+0.5);
}




// Default constructor
ConveryDetection::ConveryDetection ()
{ 
#ifdef __aarch64__
    ANNIWOLOG(INFO) << "ConveryDetection():NOT DEFINED FOR aarch64!" ;
    ANNIWOCHECK(false);
#else
    pAnniwog_mtx4GpuQueue =   &g_mtx4GpuQueue ;
    pAnniwoNvlogger =  &gLogger_test.getTRTLogger();

    mmdeploy::Model model(model_dir.c_str());
    m_detptr= new mmdeploy::Detector(model, mmdeploy::Device{"cuda", 0});
#endif
    ANNIWOLOG(INFO) << "ConveryDetection(): Success initialized!" ;
}

// Destructor
ConveryDetection::~ConveryDetection () 
{
}





void ConveryDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    reporthistoryArray.clear();

    globalJsonConfObjPtr=&globalJsonConfObj;

    // std::vector<int> converyCamIDs;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("convery"))
            {

                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "ConveryDetection::initTracks: insert" <<"camID:"<<camID<<" ";
                reporthistoryArray.insert(std::pair<int, std::unordered_map<int, int >  >(camID,trackidhits) );

// //////////////////Predictor clone to each camID    
//                 converyCamIDs.push_back(camID);
// ////////////////////////

                break;
            }
            else
            {
                continue;
            }
        }
    }

    // m_detptr->initMultiPredictors(globalINICONFObj.ANNIWO_NUM_THREAD_CONVERY);
 }
//todo:polygonSafeArea
void ConveryDetection::detect(  int camID,int instanceID,  cv::Mat img, const Polygon* polygonSafeArea_ptr,const std::vector<Object>& in_person_results) 
{    

    ANNIWOCHECK(img.data != nullptr);

    ANNIWOLOG(INFO) << "ConveryDetection:detect entered"<<"camID:"<<camID<<" polygonSafeArea_ptr:"<<polygonSafeArea_ptr;

    int orig_img_w = img.cols;
    int orig_img_h = img.rows;


    //////
    int newpersonCnt=0;
    Polygon _inter;
    Polygon box_poly;
    std::vector<Object> person_det_resultsInside;
    for (auto& obj : in_person_results) {
        if( ! isPerson(obj.label) )
            continue;
    
        int x1=obj.rect.x;
        int y1 = obj.rect.y;
        int x2=(obj.rect.x+obj.rect.width) > img.cols ? img.cols : (obj.rect.x+obj.rect.width) ;
        int y2 =(obj.rect.y+obj.rect.height) > img.rows ? img.rows : (obj.rect.y+obj.rect.height);

        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y2)));
            box_poly.add(cv::Point(int(x1),int(y2)));
            _inter.clear();
            intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
            if( _inter.size() ) {
                float area = _inter.area();
                // cv::Point center = _inter.getCenter();
                // ANNIWOLOGF(INFO,"HelmetDetection: Area intersected = %0.1f \n",area);

                if(area <= 10.0)
                {
                    
                    ANNIWOLOG(INFO) <<
                        "ConveryDetection: detect.Ignored as not in valid area box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<getPersonCarbaseClassName(obj.label)<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    continue;

                }
                else
                {
                    std::stringstream buffer;  
                    for(int i=0; i < polygonSafeArea_ptr->size(); i++)
                    {
                        const cv::Point& pt=polygonSafeArea_ptr->pt[i];
                        buffer << pt.x<<","<<pt.y<<" ";  
                    }
                    std::string text(buffer.str());

                    ANNIWOLOG(INFO) << "ConveryDetection: detect:area inter biggger than 10,camId:" <<camID<<" validArea:"<<text;

                    person_det_resultsInside.push_back(obj);
                }


            }else
            {
                ANNIWOLOG(INFO) << "ConveryDetection: detect:_inter.size else,camId:" <<camID<<" _inter.size():"<<_inter.size();
                continue;

            }
        }else//use all
        {
            ANNIWOLOG(INFO) << "ConveryDetection: detect: use all person_det_resultsInside.push_back,camId:" <<camID<<" polygonSafeArea_ptr:"<<polygonSafeArea_ptr;

            person_det_resultsInside.push_back(obj);
        }

        int trackID = (int)obj.trackID;
        if(trackID == -1)
        {
            newpersonCnt++;
        }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
        {

            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"ConveryDetection: Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);
                
                if (got_it2 == perCamIDhistory.end())//new to this camID
                {
                    newpersonCnt++;
                    perCamIDhistory.insert(std::pair<int,int>(trackID,1) );
                }
                else
                {
                    //同一个人已经报过了
                    ANNIWOLOG(INFO) <<"ConveryDetection: found tracked&reported..trackID:"<<trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;
                }
            }

        }
    }

    if(newpersonCnt <= 0 || person_det_resultsInside.size() <= 0)
    {
        ANNIWOLOG(INFO) << "ConveryDetection:exit no new person detect()" <<"camID:"<<camID;
        return;
    }

///////////////////////

    // run inference
    auto start = std::chrono::system_clock::now();
    auto dets = m_detptr->Apply(img);
    // m_detptr->Predict(batch_imgs, CONFIDENCE_THRESHOLD, 0, 1, &result, &bbox_num, &det_times,instanceID,camID);

    auto end = std::chrono::system_clock::now();
    ANNIWOLOG(INFO) <<"ConveryDetection:infer time:" << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms,"<<"camID:"<<camID ;


    ANNIWOLOG(INFO) <<"ConveryDetection:dets.before size="<<(int)dets.size();


    std::vector<ConveryPartsInfo> converyInfos;

    std::vector<PaddleDetection::ObjectResult>  im_results;  
    int detect_num = 0;

    //循环一遍，找出有几个convery.
    for (int i = 0; i < dets.size(); ++i) 
    {
        const auto& box = dets[i].bbox;
        const auto& mask = dets[i].mask;



        // skip detections with invalid bbox size (bbox height or width < 1)
        if ((box.right - box.left) < 1 || (box.bottom - box.top) < 1) {
            continue;
        }

        // skip detections less than specified score CONFIDENCE_THRESHOLD
        if (dets[i].score < CONFIDENCE_THRESHOLD) {
            continue;
        }

        ANNIWOLOGF(INFO,"ConveryDetection: box %d, left=%.2f, top=%.2f, right=%.2f, bottom=%.2f, label=%d, score=%.4f\n",
                i, box.left, box.top, box.right, box.bottom, dets[i].label_id, dets[i].score);

        PaddleDetection::ObjectResult item;

        item.class_id=dets[i].label_id;
        item.confidence= dets[i].score;
        item.rect.push_back((int)box.left);  //x1
        item.rect.push_back((int)box.top);  //y1
        item.rect.push_back((int)box.right); //x2
        item.rect.push_back((int)box.bottom) ;//y2



        // generate mask overlay if model exports masks
        if (mask != nullptr) 
        {
            ANNIWOLOGF(INFO, "ConveryDetection:mask %d, height=%d, width=%d\n", i, mask->height, mask->width);

            cv::Mat imgMask(mask->height, mask->width, CV_8UC1, &mask->data[0]);
            auto x0 = std::max(std::floor(box.left) - 1, 0.f);
            auto y0 = std::max(std::floor(box.top) - 1, 0.f);
            cv::Rect roi((int)x0, (int)y0, mask->width, mask->height);


            detect_num += 1;
            im_results.push_back(item);

            ////////////////////////////////////////////////////
            if( labels[item.class_id] == std::string("conveyer_belt") )
            {
                int end1_row_id=-1;
                int end1_col_id=-1;
                int end2_row_id=-1;
                int end2_col_id=-1;

                bool bfound1 = false;
                /**Mat_<uchar>对应的是CV_8U，

                Mat_<char>对应的是CV_8S，

                Mat_<int>对应的是CV_32S，

                Mat_<float>对应的是CV_32F，

                Mat_<double>对应的是CV_64F*/
                //找上头的x,y
                for (int row_id = 0; row_id < imgMask.rows; ++row_id) {
                    if(bfound1)
                    {
                        break;
                    }
                    for (int col_id = 0; col_id < imgMask.cols; ++col_id) {
                        if(imgMask.at<unsigned char>(row_id, col_id) > 0.5)
                        {
                            end1_row_id=row_id;
                            end1_col_id=col_id;
                            bfound1=true;
                            break;
                        }
                    }
                }
                //找下头的x,y
                bool bfound2 = false;
                for (int row_id = imgMask.rows-1; row_id >= 0; row_id--) {
                    if(bfound2)
                    {
                        break;
                    }
                    for (int col_id = imgMask.cols-1; col_id >= 0; col_id--) {
                        if(imgMask.at<unsigned char>(row_id, col_id) > 0.5)
                        {
                            end2_row_id=row_id;
                            end2_col_id=col_id;
                            bfound2=true;
                            break;
                        }
                    }
                }

                if(bfound1 && bfound2)
                {
                    //上头的x,y小于下头的x,y
                    if(end1_row_id<end2_row_id && end1_col_id<end2_col_id)
                    {
                        im_results[im_results.size() - 1].extra.isGroundEndRight=true;
                        //ground end is on the right
                    }
                    else if(end1_row_id<end2_row_id && end1_col_id>end2_col_id)////上头的x大于下头的x;
                    {
                        im_results[im_results.size() - 1].extra.isGroundEndRight=false;
                        //ground end is on the left
                    }

                    //conveyer_belt,取其低点.与wheels,conveyor_end一起取一个低点groundpoint_down1
                    ConveryPartsInfo  newInfo;
                    newInfo.conveyer_beltIndex=im_results.size() - 1;
                    
                    //conery end 第一个点
                    //点一：尾巴的底部中点，与另外两个的底部中点一起取最右下角点
                    newInfo.bpoint1x=-1;
                    newInfo.bpoint1y=-1;

                    //conery wheel/iron frame第二个点
                    //点二：尾巴的底部中点，与另外两个的底部中点一起取最左上角点
                    newInfo.bpoint2x=-1;
                    newInfo.bpoint2y=-1;
                    
                    converyInfos.emplace_back(newInfo);

                }else
                {
                    ANNIWOLOGF(INFO,"ConveryDetection: Ignored not found double end.");

                }

            }

            ////////////////////////////////////////////////////
            // split the RGB channels, overlay mask to a specific color channel
            // cv::Mat ch[3];
            // split(img, ch);
            // int col = 0;  // int col = i % 3;
            // cv::bitwise_or(imgMask, ch[col](roi), ch[col](roi));
            // merge(ch, 3, img);
        }



        // cv::rectangle(img, cv::Point{(int)box.left, (int)box.top},
        //           cv::Point{(int)box.right, (int)box.bottom}, cv::Scalar{0, 255, 0});
    }

    // cv::imwrite("output_detection.png", img);

    if(converyInfos.size() <= 0)
    {
        ANNIWOLOG(INFO) << "ConveryDetection:no convery." <<" camID:"<<camID;
        // goto detectEndflag;
        ANNIWOLOG(INFO) << "ConveryDetection:exit detect()" <<" camID:"<<camID;
        return;

    }else if(im_results.size() > 1)
    {
        for( int r=0; r<converyInfos.size(); r++ )
        {
            ANNIWOCHECK(converyInfos[r].conveyer_beltIndex >=0  && converyInfos[r].conveyer_beltIndex <= im_results.size());
        }
        ANNIWOLOG(INFO) << "ConveryDetection:debug detect()" <<" camID:"<<camID;
    }

//     // get labels and colormap
    auto colormap = PaddleDetection::GenerateColorMap(labels.size());
    //临时变量
    int minydist=123456789;
    int blongIdx=-1;
    int r=0;

    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);

    //循环一遍，分配部件到convery
    //分出几个运粮机，并通过ycenter据运粮带底边的远近进行分配,对ironframe要用左侧x1的距离比较。
    for (int j = 0; j < im_results.size(); j++) 
    {
        PaddleDetection::ObjectResult item = im_results[j];


        ANNIWOLOGF(INFO,"ConveryDetection:class=%d confidence=%.4f rect=[%d %d %d %d]\n",
            item.class_id,
            item.confidence,
            item.rect[0], //x1
            item.rect[1], //y1
            item.rect[2], //x2
            item.rect[3]);//y2

        if(labels[item.class_id] == std::string("Iron_frame") ) //Iron_frame
        {
            // Rectangle coordinates of detected object: left, right, top, down
            // Iron_frameIndex=j;
            minydist=123456789;
            blongIdx=-1;
            r=0;
            for( ; r<converyInfos.size(); r++ )
            {
                ANNIWOCHECK(converyInfos[r].conveyer_beltIndex >=0  && converyInfos[r].conveyer_beltIndex <= im_results.size());
                //x2<convery's x1  或 x1>convery's x2
                if((item.rect[2] < im_results[converyInfos[r].conveyer_beltIndex].rect[0]) || (item.rect[0] > im_results[converyInfos[r].conveyer_beltIndex].rect[2])) //在运粮机带子的x1,x2之外
                {
                    ANNIWOLOGF(INFO,"Ignore Iron_frame outside wheel!camID:%d",camID);
                    continue;
                }

                //convery's y2  - item's y2
                int tmpdist=123456789;
                if(im_results[converyInfos[r].conveyer_beltIndex].extra.isGroundEndRight)
                {//对ironframe要用左侧x1的距离比较。
                    tmpdist = std::abs(im_results[converyInfos[r].conveyer_beltIndex].rect[0] - item.rect[0]);
                }else
                {
                    tmpdist = std::abs(im_results[converyInfos[r].conveyer_beltIndex].rect[2] - item.rect[2]);
                }
                if(tmpdist < minydist )
                {
                    minydist=tmpdist;
                    blongIdx=r;
                }
            }
            assert(blongIdx>-1);
            converyInfos[blongIdx].Iron_frameIndex=j;

        }
        else if( labels[item.class_id] == std::string("conveyor_end") )//conveyor_end
        {
            // conveyor_endIndex=j;
            minydist=123456789;
            blongIdx=-1;
            r=0;
            for( ; r<converyInfos.size(); r++ )
            {
                //convery's y2  - item's y2
                int tmpdist = std::abs(im_results[converyInfos[r].conveyer_beltIndex].rect[3] - item.rect[3]);
                if(tmpdist < minydist )
                {
                    minydist=tmpdist;
                    blongIdx=r;
                }
            }
            assert(blongIdx>-1);
            converyInfos[blongIdx].conveyor_endIndex=j;

        }else if(labels[item.class_id] == std::string("wheels") )//wheels
        {              
            // wheels1Index=j;
            minydist=123456789;
            blongIdx=-1;
            r=0;
            
            for( ; r<converyInfos.size(); r++ )
            {
                if(item.rect[2] < im_results[converyInfos[r].conveyer_beltIndex].rect[0] || item.rect[0] > im_results[converyInfos[r].conveyer_beltIndex].rect[2]) //在运粮机带子的x1,x2之外
                {
                    ANNIWOLOGF(INFO,"Ignore outside wheel!  camID:%d",camID);
                    continue;
                }
                //convery's y2  - item's y2
                int tmpdist = std::abs(im_results[converyInfos[r].conveyer_beltIndex].rect[3] - item.rect[3]);
                if(tmpdist < minydist )
                {
                minydist=tmpdist;
                blongIdx=r;
                }
            }

            if(blongIdx ==  -1)
            {
                continue;
            }

            if(converyInfos[blongIdx].wheels1Index == -1)
            {
                converyInfos[blongIdx].wheels1Index=j;
            }
            else if(converyInfos[blongIdx].wheels2Index == -1)
            {
                converyInfos[blongIdx].wheels2Index=j;
            }

        }


    }

    //DEBUG 
    ANNIWOLOG(INFO) << " The number of detected convery: " << converyInfos.size() <<" camID:"<<camID ;

    // Visualization result
    cv::Mat vis_img = PaddleDetection::VisualizeResult(
        img, im_results, labels, colormap, false);


    //////////////////////////此处取地面两个点////////////////////////////
    writer.StartArray();    
    bool isRequireReport=false;
    newpersonCnt=0;
    for(r=0; r<converyInfos.size(); r++ )
    {
        if(converyInfos[r].Iron_frameIndex > -1  && converyInfos[r].conveyor_endIndex > -1 && converyInfos[r].wheels1Index > -1)  //三个地面目标（有可能两个轮子）
        {
            ANNIWOLOGF(INFO,"Ground objects more than 2 !!!camID:%d\n",camID);
        }
        else
        {
            char a = (converyInfos[r].Iron_frameIndex > -1)?1:0;
            char b = (converyInfos[r].conveyor_endIndex > -1)?1:0; 
            char c = (converyInfos[r].wheels1Index > -1)?1:0;

            if(converyInfos[r].wheels1Index <= -1  && converyInfos[r].Iron_frameIndex <= -1)
            {
                ANNIWOLOGF(INFO,"ground have no wheel and iron frame,ignored!!! camID:%d\n",camID);
                continue;
            }

            if(a + b + c >= 2) //至少两个地面目标
            {
                ANNIWOLOGF(INFO,"Ground objects only have 2,results might be not exact!!!camID:%d\n",camID);

            }else if(a + b + c >= 1)
            {
                ANNIWOLOGF(INFO,"ground object is one, result may NOT be correct!!!camID:%d\n",camID);
            }else
            {
                ANNIWOLOGF(INFO,"ground object is 0, result may NOT be correct,ignored!!!camID:%d\n",camID);
                continue;
            }

        } 



        if(converyInfos[r].conveyer_beltIndex >= -1)
        {
            if(im_results[converyInfos[r].conveyer_beltIndex].extra.isGroundEndRight)//在右边
            {
                if(converyInfos[r].conveyor_endIndex > -1)
                {
                    //x1, y1, x2, y2
                    //left,top,right,bottom
                    int converEndbottomMiddle=int((im_results[converyInfos[r].conveyor_endIndex].rect[2]+im_results[converyInfos[r].conveyor_endIndex].rect[0])/2.0+0.5);
                    converyInfos[r].bpoint1x=converEndbottomMiddle;
                    converyInfos[r].bpoint1y=im_results[converyInfos[r].conveyor_endIndex].rect[3];

                    // //底端有时候不准，不参与左上的赋值;左值初始化为运粮机的高端
                    // converyInfos[r].bpoint2x=im_results[converyInfos[r].conveyer_beltIndex].rect[0];
                    converyInfos[r].bpoint2x=12345678;
                    converyInfos[r].bpoint2y=12345678;

                }else//无end,用convery的右下角点初始化
                {
                    converyInfos[r].bpoint1x=im_results[converyInfos[r].conveyer_beltIndex].rect[2];
                    converyInfos[r].bpoint1y=im_results[converyInfos[r].conveyer_beltIndex].rect[3];

                    // //底端有时候不准，不参与左上的赋值
                    // converyInfos[r].bpoint2x=im_results[converyInfos[r].conveyer_beltIndex].rect[0];
                    converyInfos[r].bpoint2x=12345678;
                    converyInfos[r].bpoint2y=12345678;
                }

                if(converyInfos[r].Iron_frameIndex > -1)
                {
                    int ifbottommiddlex = int( (im_results[converyInfos[r].Iron_frameIndex].rect[2]+im_results[converyInfos[r].Iron_frameIndex].rect[0])/2.0+0.5);
                    converyInfos[r].bpoint1x = std::max(converyInfos[r].bpoint1x,ifbottommiddlex);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,im_results[converyInfos[r].Iron_frameIndex].rect[3]);

                    converyInfos[r].bpoint2x=std::min(converyInfos[r].bpoint2x,ifbottommiddlex);
                    converyInfos[r].bpoint2y=std::min(converyInfos[r].bpoint2y,im_results[converyInfos[r].Iron_frameIndex].rect[3]);
                }
                if(converyInfos[r].wheels1Index > -1 && converyInfos[r].wheels2Index > -1)
                {
                    int midBottomx=int((im_results[converyInfos[r].wheels1Index].rect[2]+im_results[converyInfos[r].wheels2Index].rect[2])/2.0 + 0.5);
                    int midBottomy=int((im_results[converyInfos[r].wheels1Index].rect[3]+im_results[converyInfos[r].wheels2Index].rect[3])/2.0 + 0.5);

                    converyInfos[r].bpoint1x = std::max(converyInfos[r].bpoint1x,midBottomx);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,midBottomy);

                    converyInfos[r].bpoint2x = std::min(converyInfos[r].bpoint2x,midBottomx);
                    converyInfos[r].bpoint2y=std::min(converyInfos[r].bpoint2y,midBottomy);

                }else if(converyInfos[r].wheels1Index > -1)
                {
                    int midBottomx=int((im_results[converyInfos[r].wheels1Index].rect[0]+im_results[converyInfos[r].wheels1Index].rect[2])/2.0+0.5);
                    converyInfos[r].bpoint1x = std::max(converyInfos[r].bpoint1x,midBottomx);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,im_results[converyInfos[r].wheels1Index].rect[3]);

                    converyInfos[r].bpoint2x = std::min(converyInfos[r].bpoint2x,midBottomx);
                    converyInfos[r].bpoint2y=std::min(converyInfos[r].bpoint2y,im_results[converyInfos[r].wheels1Index].rect[3]);

                }


            }else//在左边
            {

                if(converyInfos[r].conveyor_endIndex > -1)
                {
                    //x1, y1, x2, y2
                    //left,top,right,bottom
                    int converEndbottomMiddle=int((im_results[converyInfos[r].conveyor_endIndex].rect[2]+im_results[converyInfos[r].conveyor_endIndex].rect[0])/2.0+0.5);
                    converyInfos[r].bpoint1x=converEndbottomMiddle;
                    converyInfos[r].bpoint1y=im_results[converyInfos[r].conveyor_endIndex].rect[3];

                    // //不参与右上角赋值，右值为运粮机的高端
                    // converyInfos[r].bpoint2x=im_results[converyInfos[r].conveyer_beltIndex].rect[2];
                    converyInfos[r].bpoint2x=0;
                    converyInfos[r].bpoint2y=123456;

                }else//无end,用convery的左下角点初始化
                {
                    converyInfos[r].bpoint1x=im_results[converyInfos[r].conveyer_beltIndex].rect[0];
                    converyInfos[r].bpoint1y=im_results[converyInfos[r].conveyer_beltIndex].rect[3];

                    // //不参与右上角赋值
                    // converyInfos[r].bpoint2x=im_results[converyInfos[r].conveyer_beltIndex].rect[2];
                    converyInfos[r].bpoint2x=0;
                    converyInfos[r].bpoint2y=123456;
                }

                if(converyInfos[r].Iron_frameIndex > -1)
                {
                    int ifbottommiddlex = int((im_results[converyInfos[r].Iron_frameIndex].rect[2]+im_results[converyInfos[r].Iron_frameIndex].rect[0])/2.0+0.5);
                    converyInfos[r].bpoint1x = std::min(converyInfos[r].bpoint1x,ifbottommiddlex);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,im_results[converyInfos[r].Iron_frameIndex].rect[3]);

                    converyInfos[r].bpoint2x=std::max(converyInfos[r].bpoint2x,ifbottommiddlex);
                    converyInfos[r].bpoint2y=std::min(converyInfos[r].bpoint2y,im_results[converyInfos[r].Iron_frameIndex].rect[3]);
                }
                if(converyInfos[r].wheels1Index > -1 && converyInfos[r].wheels2Index > -1)
                {
                    int midBottomx=int((im_results[converyInfos[r].wheels1Index].rect[2]+im_results[converyInfos[r].wheels2Index].rect[2])/2.0 + 0.5);
                    int midBottomy=int((im_results[converyInfos[r].wheels1Index].rect[3]+im_results[converyInfos[r].wheels2Index].rect[3])/2.0 + 0.5);

                    converyInfos[r].bpoint1x = std::min(converyInfos[r].bpoint1x,midBottomx);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,midBottomy);

                    converyInfos[r].bpoint2x = std::max(converyInfos[r].bpoint2x,midBottomx);
                    converyInfos[r].bpoint2y=std::min(converyInfos[r].bpoint2y,midBottomy);

                }else if(converyInfos[r].wheels1Index > -1)
                {
                    int midBottomx=int((im_results[converyInfos[r].wheels1Index].rect[0]+im_results[converyInfos[r].wheels1Index].rect[2])/2.0+0.5);
                    converyInfos[r].bpoint1x = std::min(converyInfos[r].bpoint1x,midBottomx);
                    converyInfos[r].bpoint1y=std::max(converyInfos[r].bpoint1y,im_results[converyInfos[r].wheels1Index].rect[3]);

                    converyInfos[r].bpoint2x = std::max(converyInfos[r].bpoint2x,midBottomx);
                    converyInfos[r].bpoint2y= std::min(converyInfos[r].bpoint2y,im_results[converyInfos[r].wheels1Index].rect[3]);

                }

            }

////////////////////////////////////////////////////
            //变量用于判断人是否在运粮机里边并且脚面离底线不远
            Polygon converydownarea_poly;
            converydownarea_poly.clear();

/////////////////////////////////////////////////////

            //画出多边形
            int lineType = 5;
            //定义points，包含5个点
            std::vector<cv::Point> points;
            points.emplace_back( cv::Point(converyInfos[r].bpoint1x,converyInfos[r].bpoint1y )  );
            converydownarea_poly.add( cv::Point(converyInfos[r].bpoint1x,converyInfos[r].bpoint1y ) );

            points.emplace_back( cv::Point(converyInfos[r].bpoint2x,converyInfos[r].bpoint2y ) );
            converydownarea_poly.add( cv::Point(converyInfos[r].bpoint2x,converyInfos[r].bpoint2y ) );
            
            int converybottomY=-1;
            
            if(im_results[converyInfos[r].conveyer_beltIndex].extra.isGroundEndRight)//尾巴在右边
            {

                int x1 = im_results[converyInfos[r].conveyer_beltIndex].rect[0]; //convery rect x1
                int y1 = im_results[converyInfos[r].conveyer_beltIndex].rect[1]; //convery rect y1
                int x2 = im_results[converyInfos[r].conveyer_beltIndex].rect[0];
                int y2 = converyInfos[r].bpoint1y;  //任取一个
                int x3 = converyInfos[r].bpoint1x;
                int y3 = converyInfos[r].bpoint1y;
                int x4 = converyInfos[r].bpoint2x;
                int y4 = converyInfos[r].bpoint2y;

                int px = get2LinesIntersectX(x1,y1,x2,y2,x3,y3,x4,y4);
                int py = get2LinesIntersectY(x1,y1,x2,y2,x3,y3,x4,y4);

                points.emplace_back( cv::Point(px,py ) );
                converydownarea_poly.add( cv::Point(px,py) );


                //左上点(x1,y1) 右下点(x2,y2)
                points.emplace_back( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[0],im_results[converyInfos[r].conveyer_beltIndex].rect[1]) );
                converydownarea_poly.add( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[0],im_results[converyInfos[r].conveyer_beltIndex].rect[1]) );

                points.emplace_back( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[2],im_results[converyInfos[r].conveyer_beltIndex].rect[3]) );
                converydownarea_poly.add( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[2],im_results[converyInfos[r].conveyer_beltIndex].rect[3]) );

                converybottomY=im_results[converyInfos[r].conveyer_beltIndex].rect[3];

            }else
            {

                int x1 = im_results[converyInfos[r].conveyer_beltIndex].rect[2];  //convery rect x2
                int y1 = im_results[converyInfos[r].conveyer_beltIndex].rect[1];  //convery rect y1
                int x2 = im_results[converyInfos[r].conveyer_beltIndex].rect[2];
                int y2 = converyInfos[r].bpoint1y;  //任取一个
                int x3 = converyInfos[r].bpoint1x;
                int y3 = converyInfos[r].bpoint1y;
                int x4 = converyInfos[r].bpoint2x;
                int y4 = converyInfos[r].bpoint2y;

                int px = get2LinesIntersectX(x1,y1,x2,y2,x3,y3,x4,y4);
                int py = get2LinesIntersectY(x1,y1,x2,y2,x3,y3,x4,y4);

                points.emplace_back( cv::Point(px,py ) );
                converydownarea_poly.add( cv::Point(px,py) );


                //右上点(x2,y1)和左下点(x1,y2)
                points.emplace_back( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[2],im_results[converyInfos[r].conveyer_beltIndex].rect[1] ) );
                converydownarea_poly.add( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[2],im_results[converyInfos[r].conveyer_beltIndex].rect[1] ) );

                points.emplace_back( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[0],im_results[converyInfos[r].conveyer_beltIndex].rect[3] ) );
                converydownarea_poly.add( cv::Point(im_results[converyInfos[r].conveyer_beltIndex].rect[0],im_results[converyInfos[r].conveyer_beltIndex].rect[3]) );


                converybottomY=im_results[converyInfos[r].conveyer_beltIndex].rect[3];
            }


            /*img表示绘制画布，图像

            pts表示多边形的点

            isClosed表示是否闭合，默认闭合

            color表示颜色

            thickness表示线宽，必须是正数

            lineType表示线渲染类型

            shift表示相对位移
            */

            cv::polylines(vis_img, points, true, cv::Scalar(0, 255, 0), 1, 8, 0);

//-------------------------------
            for (size_t i = 0; i < in_person_results.size(); i++)
            {
                const Object& obj = in_person_results[i];
                
                if( ! isPerson(obj.label) )
                    continue;

                
                // ANNIWOLOGF(INFO, "SmokeDetection::detect:camID:%d in_person_results %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f tid:%d\n",camID, getPersonCarbaseClassName(obj.label), obj.prob,
                //     obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height,obj.trackID);


                int person_x1 = int(std::max(.0f, obj.rect.x));
                int person_y1 = int(std::max(.0f, obj.rect.y));
                int person_x2 = int(std::min(obj.rect.x+obj.rect.width, orig_img_w*1.0f));
                int person_y2 = int(std::min(obj.rect.y+obj.rect.height, orig_img_h*1.0f));

                //人员是否在框内
                //判断人是否在运粮机里边并且脚面离底线不远
                Polygon _inter;
                Polygon box_poly;
                box_poly.clear();
                _inter.clear();

                box_poly.add(cv::Point(int(person_x1),int(person_y1)));
                box_poly.add(cv::Point(int(person_x2),int(person_y1)));
                box_poly.add(cv::Point(int(person_x2),int(person_y2)));
                box_poly.add(cv::Point(int(person_x1),int(person_y2)));
                box_poly.add(cv::Point(int(person_x1),int(person_y2)));
                intersectPolygonSHPC(converydownarea_poly,box_poly,_inter);
                //此处无交集时候size==0?
                if( _inter.size() )
                {
                    float area = _inter.area();
                    ANNIWOLOG(INFO) <<"convery: Area intersected = "<<area<<"camID:"<<camID;

                    if(area >= box_poly.area() )//交叠部分等于自身，说明在其内部;
                    {
                        ANNIWOLOG(INFO) <<
                            "convery: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                            <<obj.rect.width<<","<<obj.rect.height<<","
                            << "score:"<<obj.prob<<"class:"<<getPersonCarbaseClassName(obj.label)<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                        
                        //需要报警
                        //todo: 且要求脚在底线附近
                        if(std::abs(converybottomY - person_y2) <= 50)
                        {
                            isRequireReport=true;
                        }else
                        {
                            ANNIWOLOG(INFO) <<"convery:  less than 50. person IGNORED.converybottomY: "<<converybottomY <<"camID:"<<camID;
                        }
                        

                        writer.StartObject();               // Between StartObject()/EndObject(), 

                        writer.Key("y1");                
                        writer.Int(person_y1);            
                        writer.Key("x1");                
                        writer.Int(person_x1);  
                        writer.Key("y2");                
                        writer.Int(person_y2);  
                        writer.Key("x2");                
                        writer.Int(person_x2);  
                        writer.Key("classItem");                // output a key,
                        writer.String(getPersonCarbaseClassName(obj.label).c_str());             // follow by a value.
                    

                        writer.EndObject();


                        
                        if(obj.trackID == -1)
                        {
                            //此时报警但不记录
                            newpersonCnt++;
                        }else
                        {
                            //记录已报警过的trackID
                            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

                            std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                            std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(obj.trackID);
                            
                            if (got_it2 == perCamIDhistory.end())//new to this camID
                            {
                                perCamIDhistory.insert(std::pair<int,int>(obj.trackID,1) );
                                newpersonCnt++;

                            }
                            else
                            {
                                got_it2->second++;
                                ANNIWOLOG(INFO) <<"SmokeDetection: Warning:found reported. IGNORED.trackID:"<<obj.trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;
                            }
                        }


                    }
                    // else
                    // {
                    //     ANNIWOLOG(INFO) <<
                    //         "convery: detect.Ignore checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                    //         <<obj.rect.width<<","<<obj.rect.height<<","
                    //         << "score:"<<obj.prob<<"class:"<<getPersonCarbaseClassName(obj.label)<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    //     //忽略这个对象!
                    //     continue;
                    // }

                }else
                {
                    ANNIWOLOG(INFO) <<"ConveryDetection: Area intersected None: "<<"camID:"<<camID;
                    continue;

                }

            }


        }
        else
        {
            ANNIWOCHECK(false);
        }

    }
     writer.EndArray();



    //////////////////////////////////////////////////////
    if(newpersonCnt <= 0)
    {
        ANNIWOLOG(INFO) << "ConveryDetection:no unreported person" <<" camID:"<<camID;
        // goto detectEndflag;
        ANNIWOLOG(INFO) << "ConveryDetection:exit detect()" <<" camID:"<<camID;
        return;
    }

    std::string output_path("/var/anniwo/images/convery/");
    if(isRequireReport )
    {
        static int dbugoutpicCnt=0;

        std::stringstream buffer;  

        buffer <<camID<<"_img_"<<dbugoutpicCnt++<<".jpg";  

        std::string text(buffer.str());

        output_path+=text;
        cv::imwrite(output_path, vis_img);
        ANNIWOLOGF(INFO, "ConveryDetection:Visualized output saved as %s\n", output_path.c_str());



        ////
        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/convery/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/convery"};

        getTaskId(globalJsonConfObjPtr,camID,"convery",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"convery","/convery",submitUrl);

        ANNIWOLOG(INFO) <<"converyDetection:save file name drawed is:"<<imgPath<<",camID:"<<camID<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,img,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }



// detectEndflag:
    ANNIWOLOG(INFO) << "ConveryDetection:exit detect()" <<" camID:"<<camID;
    return;
}
