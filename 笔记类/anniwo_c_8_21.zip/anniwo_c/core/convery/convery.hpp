#ifndef PPDET_CONVERY_H
#define PPDET_CONVERY_H
#include <opencv2/opencv.hpp>
#include "../utils/utils_intersection.hpp"
#include "mmdeploy/detector.hpp"

#include <unordered_set>
#include <unordered_map>


class ConveryDetection  {
    public:
        ConveryDetection() ;
        ~ConveryDetection() ;

        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);
        static void detect(  int camID,int instanceID,  cv::Mat img, const Polygon* polygonSafeArea_ptr,const std::vector<Object>& in_person_results);
    
    private:
        static mmdeploy::Detector  *m_detptr;

        
};

class ConveryPartsInfo
{
public:
    ConveryPartsInfo()
    {
            bpoint1x=0;
            bpoint1y=0;
            bpoint2x=0;
            bpoint2y=0;

            Iron_frameIndex=-1;
            conveyer_beltIndex=-1;
            conveyor_endIndex=-1;
            wheels1Index=-1;
            wheels2Index=-1;
    }

    int bpoint1x=0;
    int bpoint1y=0;
    int bpoint2x=0;
    int bpoint2y=0;

    int Iron_frameIndex=-1;
    int conveyer_beltIndex=-1;
    int conveyor_endIndex=-1;
    int wheels1Index=-1;
    int wheels2Index=-1;
};

#endif 

