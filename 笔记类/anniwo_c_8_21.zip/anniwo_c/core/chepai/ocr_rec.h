// Copyright (c) 2020 PaddlePaddle Authors. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "opencv2/core.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/imgproc.hpp"

#include <chrono>
#include <iomanip>
#include <iostream>
#include <ostream>
#include <vector>

#include <cstring>
#include <fstream>
#include <numeric>

// #include <ocr_cls.h>
#include "preprocess_op.h"
#include "utility.h"


namespace AnniwoOCR {

class CRNNRecognizer {
public:
  explicit CRNNRecognizer(const std::string &model_dir, const string &label_path,
                          const int &rec_batch_num, const int &rec_img_h,
                          const int &rec_img_w, const int contextCnt) {
    // this->use_gpu_ = use_gpu;
    // this->gpu_id_ = gpu_id;
    // this->gpu_mem_ = gpu_mem;
    // this->cpu_math_library_num_threads_ = cpu_math_library_num_threads;
    // this->use_mkldnn_ = use_mkldnn;
    // this->use_tensorrt_ = use_tensorrt;
    // this->precision_ = precision;
    this->rec_batch_num_ = rec_batch_num;
    this->rec_img_h_ = rec_img_h;
    this->rec_img_w_ = rec_img_w;
    std::vector<int> rec_image_shape = {3, rec_img_h, rec_img_w};
    this->rec_image_shape_ = rec_image_shape;

    this->label_list_ = Utility::ReadDict(label_path);
    this->label_list_.insert(this->label_list_.begin(),
                             "#"); // blank char for ctc
    this->label_list_.push_back(" ");

    m_contextCnt=contextCnt;

    LoadModel(model_dir);
  }

  ~CRNNRecognizer();

  // Load Paddle inference model
  void LoadModel(const std::string &model_dir);

  void Run(std::vector<cv::Mat> img_list, std::vector<std::string> &rec_texts,
           std::vector<float> &rec_text_scores, std::vector<double> &times);
  


private:

  std::vector<std::string> label_list_;

  std::vector<float> mean_ = {0.5f, 0.5f, 0.5f};
  std::vector<float> scale_ = {1 / 0.5f, 1 / 0.5f, 1 / 0.5f};
  bool is_scale_ = true;
  int rec_batch_num_;

  int rec_img_h_ ;
  int rec_img_w_ ;
  std::vector<int> rec_image_shape_ ;
  std::vector<int> predict_shape = {1,40,68};
  // pre-process
  CrnnResizeImg resize_op_;
  Normalize normalize_op_;
  PermuteBatch permute_op_;

  int m_contextCnt;

}; // class CrnnRecognizer

} // namespace AnniwoOCR
