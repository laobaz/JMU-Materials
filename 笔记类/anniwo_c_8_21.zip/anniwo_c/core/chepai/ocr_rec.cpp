
#include "ocr_rec.h"


#include <chrono>
#include <iostream>
#include <memory>
#include <vector>
#include <numeric>

///////////////from yolox/////////////
#include <fstream>
#include <sstream>
#include <opencv2/opencv.hpp>
#include <dirent.h>
#include <cstddef>
#include <vector>
//////////////////////////////////////


#include <xtensor.hpp>
#include <xtensor/xnpy.hpp>

#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>

#include <dirent.h>
#include <NvInfer.h>
#include <cuda_runtime_api.h>

#include "../common/logging.h"
#include <uuid/uuid.h>

#include "../utils/subUtils.hpp"




using namespace nvinfer1;

static IRuntime* runtime{nullptr};
static ICudaEngine* engine{nullptr};


static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;

///////////////////////////////////////////////////////////////////////////

static const char* INPUT_BLOB_NAME = "x";
static const char* OUTPUT_BLOB_NAME = "softmax_2.tmp_0";
void doInference(IExecutionContext& context, std::mutex& mutexlock,  float* input, float* output,int input_size,int output_size) {
    // const nvinfer1::ICudaEngine& engine= IExecutionContext& context();
    nvinfer1::ICudaEngine&  enginelocal = *engine;

    // Pointers to input and output device buffers to pass to engine.
    // Engine requires exactly IEngine::getNbBindings() number of buffers.
    assert(enginelocal.getNbBindings() == 2);
    void* buffers[2];

    // In order to bind the buffers, we need to know the names of the input and output tensors.
    // Note that indices are guaranteed to be less than IEngine::getNbBindings()
    const int inputIndex = enginelocal.getBindingIndex(INPUT_BLOB_NAME);

    assert(enginelocal.getBindingDataType(inputIndex) == nvinfer1::DataType::kFLOAT);
    const int outputIndex = enginelocal.getBindingIndex(OUTPUT_BLOB_NAME);
    assert(enginelocal.getBindingDataType(outputIndex) == nvinfer1::DataType::kFLOAT);
    

    // Create GPU buffers on device
    CHECK(cudaMalloc(&buffers[inputIndex], input_size* sizeof(float)));
    CHECK(cudaMalloc(&buffers[outputIndex], output_size*sizeof(float)));

    // Create stream
    cudaStream_t stream;
    CHECK(cudaStreamCreate(&stream));

    // DMA input batch data to device, infer on the batch asynchronously, and DMA output back to host
    CHECK(cudaMemcpyAsync(buffers[inputIndex], input, input_size* sizeof(float), cudaMemcpyHostToDevice, stream));

    std::unique_lock<std::mutex> gpuQueueLock(mutexlock, std::defer_lock);
    // ANNIWOLOG(INFO)  << "inference: Wait lock..." ;
    gpuQueueLock.lock();

    context.enqueueV2((void**)buffers, stream, nullptr);
    
    CHECK(cudaMemcpyAsync(output, buffers[outputIndex], output_size * sizeof(float), cudaMemcpyDeviceToHost, stream));
    cudaStreamSynchronize(stream);

    gpuQueueLock.unlock();

    // Release stream and buffers
    cudaStreamDestroy(stream);
    CHECK(cudaFree(buffers[inputIndex]));
    CHECK(cudaFree(buffers[outputIndex]));

}


//////////////////////////////////////////////////////////////////////////



namespace AnniwoOCR {

CRNNRecognizer::~CRNNRecognizer()
{



  executionContexts.clear();
  contextlocks.clear();

  // destroy the engine
  delete engine;
  delete runtime;


  engine=nullptr;
  runtime=nullptr;
}

void CRNNRecognizer::Run(std::vector<cv::Mat> img_list,
                         std::vector<std::string> &rec_texts,
                         std::vector<float> &rec_text_scores,
                         std::vector<double> &times) {
  std::chrono::duration<float> preprocess_diff =
      std::chrono::steady_clock::now() - std::chrono::steady_clock::now();
  std::chrono::duration<float> inference_diff =
      std::chrono::steady_clock::now() - std::chrono::steady_clock::now();
  std::chrono::duration<float> postprocess_diff =
      std::chrono::steady_clock::now() - std::chrono::steady_clock::now();

  int img_num = img_list.size();
  std::vector<float> width_list;
  for (int i = 0; i < img_num; i++) {
    width_list.push_back(float(img_list[i].cols) / img_list[i].rows);
  }
  std::vector<int> indices = Utility::argsort(width_list);

  for (int beg_img_no = 0; beg_img_no < img_num;
       beg_img_no += this->rec_batch_num_) {
    auto preprocess_start = std::chrono::steady_clock::now();
    int end_img_no = min(img_num, beg_img_no + this->rec_batch_num_);
    int batch_num = end_img_no - beg_img_no;
    int imgH = this->rec_image_shape_[1];
    int imgW = this->rec_image_shape_[2];
    float max_wh_ratio = imgW * 1.0 / imgH;

#ifdef ANNIWO_INTERNAL_DEBUG
    ANNIWOLOG(INFO)  << "imgW,imgH,before max_wh_ratio:" << imgW <<"," << imgH<<"," << max_wh_ratio;
#endif

    

    for (int ino = beg_img_no; ino < end_img_no; ino++) {
      int h = img_list[indices[ino]].rows;
      int w = img_list[indices[ino]].cols;
      float wh_ratio = w * 1.0 / h;
      max_wh_ratio = max(max_wh_ratio, wh_ratio);

#ifdef ANNIWO_INTERNAL_DEBUG
      ANNIWOLOG(INFO)  << "wh_ratio,max_wh_ratio:" << wh_ratio <<","<<max_wh_ratio;
#endif

    }



    int batch_width = imgW;
    std::vector<cv::Mat> norm_img_batch;
    for (int ino = beg_img_no; ino < end_img_no; ino++) {
      cv::Mat srcimg;
      img_list[indices[ino]].copyTo(srcimg);
      cv::Mat resize_img;
      this->resize_op_.Run(srcimg, resize_img, max_wh_ratio,
                           this->rec_image_shape_);
      this->normalize_op_.Run(&resize_img, this->mean_, this->scale_,
                              this->is_scale_);
      norm_img_batch.push_back(resize_img);
      batch_width = max(resize_img.cols, batch_width);

#ifdef ANNIWO_INTERNAL_DEBUG
     ANNIWOLOG(INFO)  << "batch_width,resize_img.cols:" << batch_width <<","<<resize_img.cols;
#endif

    }

    assert(batch_num == 1);
    assert(imgH == 48);
    assert(batch_width == 320);

    int input_num=batch_num * 3 * imgH * batch_width;

    std::vector<float> input(input_num, 0.0f);
    this->permute_op_.Run(norm_img_batch, input.data());
    auto preprocess_end = std::chrono::steady_clock::now();
    preprocess_diff += preprocess_end - preprocess_start;



    // Inference.
    // auto input_names = this->predictor_->GetInputNames();
    // auto input_t = this->predictor_->GetInputHandle(input_names[0]);
    // input_t->Reshape({batch_num, 3, imgH, batch_width});
    auto inference_start = std::chrono::steady_clock::now();
    // input_t->CopyFromCpu(input.data());
    // this->predictor_->Run();


    std::vector<float> predict_batch;


    int out_num = this->predict_shape[0] * this->predict_shape[1] * this->predict_shape[2];

    predict_batch.resize(out_num);

    ///////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////
    int choiceIntVal = randIntWithinScale(m_contextCnt);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);
		ANNIWOCHECK(iterCamInstance != executionContexts.end()) ;

    // run inference
    auto start = std::chrono::system_clock::now();
    cudaSetDevice(gpuNum);

    doInference(*iterCamInstance->second,*iterCamInstancelock->second,input.data(), predict_batch.data(),input_num, out_num);

    auto end = std::chrono::system_clock::now();

    std::cout<< "infer time:" << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms" << std::endl;

    // std::cout<< "output num is " << predict_batch.size();

    // std::cout<<" out_data is predict_batch:";
    // int printCnt=0;
    // for(auto item:predict_batch)
    // {
    //     printCnt++;
    //     std::cout<<item<<",";   
    //     if(printCnt > 24)
    //     {
    //         break;
    //     }

    // }
    // std::cout<<std::endl;



    ///////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////


    auto inference_end = std::chrono::steady_clock::now();
    inference_diff += inference_end - inference_start;

    // ctc decode
    auto postprocess_start = std::chrono::steady_clock::now();
    for (int m = 0; m < this->predict_shape[0]; m++) {
      std::string str_res;
      int argmax_idx;
      int last_index = 0;
      float score = 0.f;
      int count = 0;
      float max_value = 0.0f;

      for (int n = 0; n < this->predict_shape[1]; n++) {
        // get idx
        argmax_idx = int(Utility::argmax(
            &predict_batch[(m * this->predict_shape[1] + n) * this->predict_shape[2]],
            &predict_batch[(m * this->predict_shape[1] + n + 1) * this->predict_shape[2]]));
        // get score
        max_value = float(*std::max_element(
            &predict_batch[(m * this->predict_shape[1] + n) * this->predict_shape[2]],
            &predict_batch[(m * this->predict_shape[1] + n + 1) * this->predict_shape[2]]));

        if (argmax_idx > 0 && (!(n > 0 && argmax_idx == last_index))) {
          score += max_value;
          count += 1;
          str_res += label_list_[argmax_idx];
        }
        last_index = argmax_idx;
      }
      score /= count;
      if (isnan(score)) {
        continue;
      }
      rec_texts[indices[beg_img_no + m]] = str_res;
      rec_text_scores[indices[beg_img_no + m]] = score;
    }
    auto postprocess_end = std::chrono::steady_clock::now();
    postprocess_diff += postprocess_end - postprocess_start;
  }
  times.push_back(double(preprocess_diff.count() * 1000));
  times.push_back(double(inference_diff.count() * 1000));
  times.push_back(double(postprocess_diff.count() * 1000));



}

void CRNNRecognizer::LoadModel(const std::string &model_dir) 
{

  executionContexts.clear();
  contextlocks.clear();

  gpuNum = initInferContext(
                  model_dir.c_str(), 
                  &runtime,
                  &engine);
		
    cudaSetDevice(gpuNum);


    for(int i=0;i<m_contextCnt;i++)
		{
			TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
			std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

			executionContexts.insert(std::move(tmpitem));


			std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
			std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

			contextlocks.insert(std::move(tmplockitem));
		}


}

} // namespace AnniwoOCR
