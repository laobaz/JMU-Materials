#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>
// #include "opencv2/imgproc.hpp"
// #include "opencv2/imgcodecs.hpp"


#include <dirent.h>

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "../common/logging.h"
#include "../personbase/basePerson.hpp"

#include "chepai.hpp"
#include "ocr_rec.h"


static std::string submitUrlPrefix = {"http://localhost:7008/safety-event-local/socketEvent/"};
static std::string submitUrl = submitUrlPrefix + "chepai";



static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;
// static const float BBOX_CONF_THRESH = 0.65;
static const float BBOX_CONF_THRESH = 0.43;

static std::unordered_map<int, std::unordered_map<int, int > > reporthistoryArray ;


static const int NUM_CLASSES = 1;


// static const std::vector<std::string>  class_names = {
// "manhole_shaft",
// "triangular_pyramid",
// "fire_extinguisher_35",
// "fire_extinguisher_5",
// "oil_machine",
//     "bus",
//     "car",
//     "cat",
//     "chair",
//     "cow",
//     "diningtable",
//     "dog",
//     "horse",
//     "motorbike",
//     "person",
//     "pottedplant",
//     "sheep",
//     "sofa",
//     "train",
//     "tvmonitor"
// };


const static std::string model_file={"../models/chepai/rec/OCR_model_fixedInputV3_sim.trt"};
const static std::string dict_path={"../models/chepai/rec/keys_chepai.txt"};


//
const static std::string det_model_file={"../models/chepai/det/plate_ppyoloe_crn_s_300e_coco.trt"};
const static std::string det_config_path={"../models/chepai/det/infer_cfg.yml"};



// const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //pytorch/paddle



PaddleDetection::ObjectDetector* ChepaiDetection::m_detptr=nullptr;
AnniwoOCR::CRNNRecognizer  *ChepaiDetection::recognizer = nullptr;


ChepaiDetection::ChepaiDetection () { 

    ANNIWOLOG(INFO) << "ChepaiDetection()" ;

    m_detptr=new PaddleDetection::ObjectDetector(det_config_path,det_model_file,globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI);


    int FLAGS_rec_batch_num = 1;
    int FLAGS_rec_img_h = 48;
    int FLAGS_rec_img_w = 320;
    recognizer = new AnniwoOCR::CRNNRecognizer(
        model_file, dict_path,
        FLAGS_rec_batch_num, FLAGS_rec_img_h, FLAGS_rec_img_w, globalINICONFObj.ANNIWO_NUM_INSTANCE_CHEPAI);

    ANNIWOLOG(INFO) << "ChepaiDetection(): Success initialized!" ;
}

// Destructor
ChepaiDetection::~ChepaiDetection () 
{
    // destroy the detector/recognizer
    if(m_detptr)
    {
        delete m_detptr;
        m_detptr=nullptr;
    } 
    if(recognizer)
    {
        delete recognizer;
        recognizer=nullptr;
    } 

}


void PostProcessResults(int camID,const cv::Mat bgr, const std::vector<Object>& vehicle_resultsInside, Object& chepaiTarget,const AnniwoOCR::OCRPredictResult& ocr_result)
{


    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;


    // 2.在history里边判断是否已经报过  
    int trackID = (int)chepaiTarget.trackID;
    if(trackID == -1)
    {
        jsonObjCnt++;
    }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
    {

        std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

        if (got_it == reporthistoryArray.end())
        {
            ANNIWOLOG(INFO) <<"ChepaiDetection-PostProcessResults: Not in history map!!!"<<"camID:"<<camID<<std::endl;
        }
        else
        {
            std::unordered_map<int, int >& perCamIDhistory = got_it->second;
            std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);
            
            if (got_it2 == perCamIDhistory.end())//new to this camID
            {
                jsonObjCnt++;
                perCamIDhistory.insert(std::pair<int,int>(trackID,1) );

            }
            else
            {
                //同一个人已经报过了
                ANNIWOLOG(INFO) <<"ChepaiDetection-PostProcessResults: found tracked&reported..trackID:"<<trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;
            }
        }

    }


    //3.如果没有报过则报警
    if(jsonObjCnt>0)
    {
        writer.StartArray();    

        int x1=chepaiTarget.rect.x;
        int y1 = chepaiTarget.rect.y;
        int x2=(chepaiTarget.rect.x+chepaiTarget.rect.width);
        int y2 =(chepaiTarget.rect.y+chepaiTarget.rect.height);



        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("y1");                
        writer.Int(y1);            
        writer.Key("x1");                
        writer.Int(x1);  
        writer.Key("y2");                
        writer.Int(y2);  
        writer.Key("x2");                
        writer.Int(x2);  
        writer.Key("classItem");                // output a key,
        writer.String("chepai");             // follow by a value.
        writer.Key("wenzi");
        writer.String(ocr_result.text.c_str());          

        writer.EndObject();

        writer.EndArray();

    }



    if(jsonObjCnt > 0)
    {
        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/chepai/" + imagename;


        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/chepai"};

        getTaskId(globalJsonConfObjPtr,camID,"chepai",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"chepai","/chepai",submitUrl);


        ANNIWOLOG(INFO) <<"chepaiDetection:save file name drawed is:"<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,
        bgr,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }


}







void ChepaiDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    reporthistoryArray.clear();

    globalJsonConfObjPtr=&globalJsonConfObj;

    // std::vector<int> converyCamIDs;

    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("chepai"))
            {

                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "ChepaiDetection::initTracks: insert" <<"camID:"<<camID<<" ";
                reporthistoryArray.insert(std::pair<int, std::unordered_map<int, int >  >(camID,trackidhits) );

                break;
            }
            else
            {
                continue;
            }
        }
    }


    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_ZXY个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_CHEPAI)
    {
        ANNIWOLOG(INFO) << "ChepaiDetection::initTracks: insert instance" <<"cntID:"<<cntID;

        cntID++;
    }

 }
//todo:polygonSafeArea_ptr 与 使用车辆的跟踪trackId结果来去重。 
//如果trackId相同并且在该trackId的车辆内部检测到相同的ocr则去重.
void ChepaiDetection::detect(  int camID,int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr,const std::vector<Object>& person_det_results) 
{    
    int orig_img_w = img.cols;
    int orig_img_h = img.rows;



/////////////////////////////////////////////////////////////
    int newVehicleCnt=0;
    Polygon _inter;
    Polygon box_poly;
    std::vector<Object> vehicle_det_results;
    for (auto& obj : person_det_results) 
    {
        if( ! isVehicle(obj.label) )
            continue;
    
        vehicle_det_results.push_back(obj);

        int trackID = (int)obj.trackID;
        if(trackID == -1)
        {
            newVehicleCnt++;
        }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
        {

            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"ChepaiDetection: Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);
                
                if (got_it2 == perCamIDhistory.end())//new to this camID
                {
                    newVehicleCnt++;
                }
                else
                {
                    //同一个人已经报过了
                    ANNIWOLOG(INFO) <<"ChepaiDetection: found tracked&reported..trackID:"<<trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;
                }
            }

        }
    }

    // if(newVehicleCnt <= 0 || vehicle_det_results.size() <= 0)
    if(newVehicleCnt <= 0 )
    {
        ANNIWOLOG(INFO) << "ChepaiDetection:exit no new vehicle detect()" <<"camID:"<<camID;
        return;
    }else
    {
        ANNIWOLOG(INFO) << "ChepaiDetection:new vehicle count:" <<"camID:"<<camID<<","<<newVehicleCnt;

    }

///////////////////////////////////////////////////////////////////


    std::vector<Object> objects;
    
    ppyoloe_det_stuff(m_detptr,camID, instanceID, img, /*out*/objects, BBOX_CONF_THRESH,NUM_CLASSES,"ChepaiDetection");
    ANNIWOLOG(INFO) << "ChepaiDetection: chepai count:" <<objects.size()<<","<<"camID:"<<camID;


    Object& obj = objects[0]; 
    bool isInsideVehicle=false;

    for(int idx=0;idx<objects.size();idx++)//找一个在车内部的车牌目标
    {
        obj = objects[idx];  

        //要求车牌在设定范围内部
        int x1=obj.rect.x;
        int y1 = obj.rect.y;
        int x2=(obj.rect.x+obj.rect.width) > img.cols ? img.cols : (obj.rect.x+obj.rect.width) ;
        int y2 =(obj.rect.y+obj.rect.height) > img.rows ? img.rows : (obj.rect.y+obj.rect.height);

        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y2)));
            box_poly.add(cv::Point(int(x1),int(y2)));
            _inter.clear();
            intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
            if( _inter.size() ) {
                float area = _inter.area();

                if(area <= 10.0)
                {
                    
                    ANNIWOLOG(INFO) <<
                        "ChepaiDetection: detect.Ignored as not in valid area box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<obj.label<<","<<"area:"<<area<<" camID:"<<camID;
                    continue;
                }
                else
                {
                    std::stringstream buffer;  
                    for(int i=0; i < polygonSafeArea_ptr->size(); i++)
                    {
                        const cv::Point& pt=polygonSafeArea_ptr->pt[i];
                        buffer << pt.x<<","<<pt.y<<" ";  
                    }
                    std::string text(buffer.str());

                    ANNIWOLOG(INFO) << "ChepaiDetection: detect:area inter biggger than 10,camId:" <<camID<<" validArea:"<<text;

                }


            }else
            {
                ANNIWOLOG(INFO) << "ChepaiDetection: detect:_inter.size else,camId:" <<camID<<" _inter.size():"<<_inter.size();
                continue;

            }
        }
        else
        {
           //No valid area setting
        }
        //////////////////////////////////////////////////////////////////////////////////


        //todo:1.取得该车牌的对应车的trackId  2.仅仅使用第一个在车内的牌子
        for(auto& vehicle_obj:vehicle_det_results)
        {
            //看看与车牌重合.
            // intersection over union
            float inter_area = intersection_area(obj, vehicle_obj);
            float chepaiobj_area = obj.rect.area();

            if( inter_area/chepaiobj_area > 0.9)
            {
                obj.trackID=vehicle_obj.trackID;
                isInsideVehicle=true;
                break;
            }
        }

        if(isInsideVehicle)
        {

            //抠图进行车牌文字识别
            ANNIWOLOGF(INFO, "ChepaiDetection::detect:camID:%d resultsInside %d = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f \n",camID, obj.label, obj.prob,
                obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height);


            int person_x = int(std::max(.0f, obj.rect.x));
            int person_y = int(std::max(.0f, obj.rect.y));
            int person_w = int(std::min(obj.rect.width, orig_img_w*1.0f));
            int person_h = int(std::min(obj.rect.height, orig_img_h*1.0f));


            //扩为67/27. 修改时必须保持比例小于320/48.
            int cha = 67-person_w;
            if(cha > 1) //扩宽到67
            {
                person_w=67;
                person_x = int(std::max(0, person_x-cha/2));
            }

            cha = 27-person_h;
            if(cha > 1) //扩高到27
            {
                person_h=27;
                person_y = int(std::max(0, person_y-cha/2)); //上下各扩差的1/2
            }

            //限制长宽比!!!
            if(person_w*1.0f/person_h > 320*1.0f/48)
            {
                ANNIWOLOG(INFO) << "ChepaiDetection::detect:ignore ratio plate: "<<person_w*1.0f/person_h;
                continue;
            }


            cv::Mat Chepai_plate_img(person_h, person_w, CV_8UC3, cv::Scalar(114, 114, 114));
            img(cv::Rect(person_x, person_y, person_w, person_h)).copyTo(Chepai_plate_img(cv::Rect(0, 0, person_w, person_h)));
            ANNIWOCHECK(Chepai_plate_img.data != nullptr);

            //DEBUG
            // if(camID == 5)
            // {
            //     std::string debugimgname=getRandomName("");
            //     cv::imwrite(debugimgname+".jpg", Chepai_plate_img );   
            // }


            //////////////////////////////////////////////////
            //判断是否模糊
            // Declare the variables we are going to use

            // Check if image is loaded fine
            if(Chepai_plate_img.empty()){
                ANNIWOLOG(INFO) << "ChepaiDetection::detect:Error opening imag";
                ANNIWOLOG(INFO) << "ChepaiDetection:exit detect()" <<"camID:"<<camID <<"instanceID:"<<instanceID ;

                return ;
            }

            cv::Mat  Chepai_plate_img_blured,src_gray, dst;
            int kernel_size = 3;
            int scale = 1;
            int delta = 0;
            int ddepth = CV_16S;        


            
            // Reduce noise by blurring with a Gaussian filter ( kernel size = 3 )
            cv::GaussianBlur( Chepai_plate_img, Chepai_plate_img_blured, cv::Size(3, 3), 0, 0, cv::BORDER_DEFAULT );

            cv::cvtColor( Chepai_plate_img_blured, src_gray, cv::COLOR_BGR2GRAY ); // Convert the image to grayscale

            cv::Laplacian( src_gray, dst, ddepth, kernel_size, scale, delta, cv::BORDER_DEFAULT );



            // Get the standard deviation
            cv::Mat mean, stddev;
            cv::meanStdDev(dst,mean, stddev);

            double sd = mean.at<double>(0, 0);//返回第一通道标准差
            sd = pow(sd,2.0); //方差

            auto laplacianValue = sd;  


            if( laplacianValue < 2.)
            {
                ANNIWOLOGF(INFO, "ChepaiDetection::detect:Ignore chepai because vague value:%f,camID:%d", laplacianValue, camID);

                continue ;
            }
            
            //////////////////////////////////////////////////

            
            ANNIWOLOGF(INFO, "ChepaiDetection::detect:camID:%d person_w:%d person_h:%d Chepai_plate_img.cols:%d Chepai_plate_img.rows:%d\n",camID,person_w,person_h,Chepai_plate_img.cols,Chepai_plate_img.rows );
            std::vector<cv::Mat> img_list;

            img_list.push_back(Chepai_plate_img);

            std::vector<AnniwoOCR::OCRPredictResult> ocr_results;

            AnniwoOCR::OCRPredictResult tmpres;
            ocr_results.emplace_back(tmpres);



            std::vector<std::string> rec_texts(img_list.size(), ""); //只有一个!!!
            std::vector<float> rec_text_scores(img_list.size(), 0);
            std::vector<double> rec_times;
            recognizer->Run(img_list, rec_texts, rec_text_scores, rec_times);
            // output rec results
            for (int i = 0; i < rec_texts.size(); i++) 
            {
                ocr_results[i].text = rec_texts[i];
                ocr_results[i].score = rec_text_scores[i];


                std::string::size_type startpos = 0;
                for (int posi=0; startpos!= std::string::npos; posi++)
                {
                    startpos = ocr_results[i].text.find('\r');   //找到'.'的位置
                    if( startpos != std::string::npos ) //std::string::npos表示没有找到该字符
                    {
                        if(posi == 0)
                        {
                            ocr_results[i].text.replace(startpos,1," "); //实施替换，注意后面一定要用""引起来，表示字符串
                        }else
                        {
                            ocr_results[i].text.replace(startpos,1,""); //实施替换，注意后面一定要用""引起来，表示字符串
                        }
                    }


                }

                if(ocr_results[0].score > 0.8 && ocr_results[i].text.length() >= 10   )
                {
                    //vehicle_det_results 用车辆跟踪结果来判断是否重复
                    PostProcessResults(camID,img, vehicle_det_results, objects[0],ocr_results[0]);
                }else
                {
                    ANNIWOLOG(INFO) << "ChepaiDetection Ignored low. score:"<<ocr_results[i].score  <<",length:"<<ocr_results[i].text.length() <<"camID:"<<camID <<"instanceID:"<<instanceID ;
                }

                ANNIWOLOG(INFO) <<u8"ChepaiDetection:result text order:"<<ocr_results[i].text<<u8" result score:"<< ocr_results[i].score ;

            }


        }
    }

    
    ANNIWOLOG(INFO) << "ChepaiDetection:exit detect() objects.size():" << objects.size() <<"camID:"<<camID <<"instanceID:"<<instanceID ;


    return;
}
