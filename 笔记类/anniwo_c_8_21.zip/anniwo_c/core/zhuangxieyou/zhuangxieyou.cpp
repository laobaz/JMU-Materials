#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include<set>

#include <opencv2/opencv.hpp>
#include <dirent.h>

#include "zhuangxieyou.hpp"


#include "zxy_items.hpp"

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"

#include "../personbase/basePerson.hpp"

#include "../common/yolo/yolo_common.hpp"
#include "../common/mot/include/deepsort.h"

#include "zxy_absence.hpp"

#include <uuid/uuid.h>
#include <unordered_map>




static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;





////////////

static std::unordered_map<int, std::unordered_map<int, int > > reporthistoryArray ;
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoStay>  >* stay_conf_map_ptr;
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >*  validtypes_map_ptr;

static std::unordered_map<int, std::vector<Object> > allLastObjects ; //防止低级错误的iou过滤
//camID, isStart
static std::unordered_map<int, bool > thisTimeReportArray ; //记录本次检测是否报警的布尔值
static std::unordered_map<int, bool > iSStayConfigCheckOKArray ; //记录是否有检测到油罐车停止满足条件，满足后启动报警的布尔值;无油罐车时候置为false



static ZxyItems *zxyItemsDet=nullptr;
static ZxyAbsence *absenceObjPtr=nullptr;

//临时记录结构，用于检查该trackid对应的目标停留时间是否已经达到阈值
// {camID,{trackid,stayStart}}



static  std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  > trackStayMap;


const static std::string deepsort_model_file_path_model={"../models/safearea/dstk_model/deepsort_sim.trt"};

const static std::string deepsort_model_file_path_model2={"../models/safearea/dstk_model2/carRreid_sim.trt"};

const int reidbatchsize=8;

static DeepSort* DS = nullptr;



// Default constructor
ZxyDetection::ZxyDetection () { 

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        zxyItemsDet= new ZxyItems();
        absenceObjPtr=new ZxyAbsence();

                
    }else
    {
        ANNIWOLOG(INFO) << "ZxyDetection():Not use zhuangxieyou in other than jiayouzhan domain!" ;
        ANNIWOCHECK(false);
    }
    
    
    ANNIWOLOG(INFO) << "ZxyDetection(): Success initialized!" ;

}



// Destructor
ZxyDetection::~ZxyDetection () 
{

    if(zxyItemsDet)
    {
        delete zxyItemsDet;
    }
    if(absenceObjPtr)
    {
        delete absenceObjPtr;
    }

}

//通过trackid报警历史，停留时间来判断新出现的需要报警的人/车数目.与类型无关。
//卸油区和卸油区离岗：检查tank_truck停留时间
static int deDuplicateTrackResults(int camID, cv::Mat img,std::vector<Object>& offendPersonVehicleNoTypefilter, std::vector<Object>& offend_boxes_det,int& outDurn)
{
    int orig_img_w = img.cols;
    int orig_img_h = img.rows;

    int newpersonvehicleCnt=0;

    AnniwoStay stayconfig;
    stayconfig.isMotionless=false;
    stayconfig.staySec=-1;

    //取得停留时间设置
    //stayconfig
    //camId,{func,<isMotionless,stay in seconds>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoStay> >::const_iterator got_id_func_cap = stay_conf_map_ptr->find(camID);

    if (got_id_func_cap == stay_conf_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "not found in stay_conf_map,camID:" <<camID;
    }
    else
    {
        const std::unordered_map<std::string, AnniwoStay>& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoStay>::const_iterator got_id_func_cap2 = conf_map.find("zhuangxieyou");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "not found zhuangxieyou in stay_conf_map,camID:" <<camID;
        }
        else
        {
            stayconfig = got_id_func_cap2->second ;
        }
    }


    int durn=-1;
    outDurn=-1;
    for (auto& obj : offend_boxes_det) {

        int trackID = (int)obj.trackID;

        if(trackID == -1)
        {
            newpersonvehicleCnt++;

            if(class_names_xieyouitems[obj.label] == std::string("tank_truck"))//装卸油仅油罐车检查停留设置
            {
                //停留时间:首次进入不报警，除非当无逗留时间配置的时候
                if (stayconfig.staySec <= 0)
                {
                    iSStayConfigCheckOKArray[camID] = true;
                    thisTimeReportArray[camID]=true;
                }
            }

        }else//对于已经有id的对象需要看是否已经报警过。如果已经报警过则忽略。否则认为是新的并记录
        {

            std::unordered_map<int, std::unordered_map<int, int > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"ZxyDetection: camID Not in history map!!!"<<"camID:"<<camID<<std::endl;
            }
            else
            {
                std::unordered_map<int, int >& perCamIDhistory = got_it->second;
                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(trackID);

                if (got_it2 == perCamIDhistory.end())//Not reported to this camID
                {
                    float inter_area =0.0;
                    float union_area =0.0;

                    if(class_names_xieyouitems[obj.label] == std::string("tank_truck"))//卸油区准备仅油罐车检查停留设置
                    {
                        //停留时间:在区域内trackid是新的，相当于第一次跟踪上,没有配置逗留时间;
                            if (stayconfig.staySec <= 0)
                            {
                                ANNIWOLOG(INFO) <<
                                    "ZxyDetection.detect no stayconfig,has trackID but new. camID:"<<camID;
                                 iSStayConfigCheckOKArray[camID] =true;
                            }
                            else
                            {
                                std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecord>  >::iterator got_id_func_cap = trackStayMap.find(camID);

                                if (got_id_func_cap == trackStayMap.end())
                                {
                                    ANNIWOLOG(INFO) << "ZxyDetection.detect WARN: trackStayMap,camID:" <<camID;
                                }
                                else
                                {
                                    std::unordered_map<int, AnniwoTrackRecord>& track_stay_map =got_id_func_cap->second;
                                    std::unordered_map<int, AnniwoTrackRecord>::iterator got_id_func_cap2 = track_stay_map.find(trackID);
                                    if (got_id_func_cap2 == track_stay_map.end())
                                    {
                                        //map中未记录该track_id
                                        ANNIWOLOG(INFO) << "ZxyDetection.detect not found in track_stay_map,new add trackID:"<<trackID<<"camID:" <<camID;
                                        //todo:何时清空？？
                                        track_stay_map.insert(std::pair<int, AnniwoTrackRecord>(trackID,{obj,std::chrono::system_clock::now()}));
                                    }
                                    else
                                    {   
                                        // got_id_func_cap2->second 是开始时间
                                        //如果开始时间是设置的…0…值,是已经报过了则不报。
                                        if(got_id_func_cap2->second.startPoint > std::chrono::system_clock::from_time_t(0))
                                        {
                                            if(stayconfig.isMotionless)//要检测到静止之后开始计时
                                            {
                                                //与box_det求ioa
                                                // intersection over union
                                                inter_area = intersection_area(obj, got_id_func_cap2->second.detresult);
                                                union_area = obj.rect.area() + got_id_func_cap2->second.detresult.rect.area() - inter_area;


                                                //本次检测框与上一次IOU > 0.85 认为是静止
                                                if(inter_area / union_area > 0.85  ) //认为是静止了，那么上次的startPoint OK.
                                                {
                                                    durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - got_id_func_cap2->second.startPoint).count();

                                                }else
                                                {
                                                    got_id_func_cap2->second.startPoint=std::chrono::system_clock::now();//非静止，更新上次的startPoint.
                                                }

                                                got_id_func_cap2->second.detresult=obj;


                                            }else
                                            {
                                                durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - got_id_func_cap2->second.startPoint).count();
                                            }

                                            ANNIWOLOG(INFO) <<"ZxyDetection.detect:isMotionless:"<<stayconfig.isMotionless<<" trackID "<<trackID<<" durn:"<<durn<<" camID:"<<camID;

                                            if(durn > stayconfig.staySec)
                                            {
                                                 iSStayConfigCheckOKArray[camID]  = true;
                                                //#对一个trackid对应的物体，如超时后报警过一次，
                                                //deepsort逻辑:\出了跟踪区域(以miss 100次为准)后删除track
                                                got_id_func_cap2->second.startPoint=std::chrono::system_clock::from_time_t(0);
                                                ANNIWOLOG(INFO) <<"ZxyDetection.detect:iSStayConfig triggered:"<<iSStayConfigCheckOKArray[camID]<<" trackID "<<trackID<<" durn:"<<durn<<" camID:"<<camID;


                                            }

                                        }

                                    }
                                }
                            }
                            //////////////
                    }

                    
                    
                    
                    if( iSStayConfigCheckOKArray[camID]  )
                    {
                        if(class_names_xieyouitems[obj.label] == std::string("tank_truck"))
                        {
                            
                            thisTimeReportArray[camID]=true;

                            newpersonvehicleCnt++;
                            perCamIDhistory.insert(std::pair<int,int>(trackID,1) );
                        }else
                        {
                            if(thisTimeReportArray[camID]==true)
                            {
                                newpersonvehicleCnt++;
                                perCamIDhistory.insert(std::pair<int,int>(trackID,1) );
                            }
                        }

                    }

                }
                else
                {
                    if(class_names_xieyouitems[obj.label] == std::string("tank_truck"))//卸油区准备仅油罐车在的时候报警
                    {
                        thisTimeReportArray[camID]=true;
                    }
                    ANNIWOLOG(INFO) <<"ZxyDetection: found tracked&reported..trackID:"<<trackID<<"camID:"<<camID<<"thisTimeReport:"<<thisTimeReportArray[camID];
                }
            }

        }
    }

    if(thisTimeReportArray[camID]==false)//本次无油罐车
    {
        iSStayConfigCheckOKArray[camID] = false;//因为没有检测到油罐车，开始报警开关重置

        absenceObjPtr->stop(camID);//停止离岗计时检查

        ANNIWOLOG(INFO) <<"ZxyDetection.detect:iSStayConfig untriggered:"<<iSStayConfigCheckOKArray[camID]<<" camID:"<<camID;
        return 0;
    }


    if(newpersonvehicleCnt <= 0 )
    {
        ANNIWOLOG(INFO) <<"ZxyDetection: No new person, camID:"<<camID <<"thisTimeReport:"<<thisTimeReportArray[camID]<<"stayCheckOK:"<<iSStayConfigCheckOKArray[camID];
        return newpersonvehicleCnt;
    }
    if( ! iSStayConfigCheckOKArray[camID] )
    {
        ANNIWOLOG(INFO) <<"ZxyDetection:Not report because stay config not ok, camID:"<<camID;
        return 0;
    }else
    {
        //达到报警条件(是油罐车达到超时条件iSStayConfigCheckOKArray)之后才开始进行人员离岗判断
        absenceObjPtr->startOrcheck(camID,img,offendPersonVehicleNoTypefilter); //检查是否有离岗,传入对象是仅仅做了valid area过滤的，未进行类型过滤
    }


    if(offend_boxes_det.size() <= 0)
    {
        ANNIWOLOG(INFO) <<"ZxyDetection:filteredObjects size 0,camID:"<<camID;
    }else
    {
        if(isResultDuplicated(allLastObjects[camID],offend_boxes_det))
        {
            ANNIWOLOG(INFO) <<"ZxyDetection:Duplicated results.Ignored.camID:"<<camID<<std::endl;
            allLastObjects[camID]=offend_boxes_det;

            return 0;
        }
    }

    //update history results
    allLastObjects[camID]=offend_boxes_det;


    for (auto& obj : offend_boxes_det) {
        int trackID = (int)obj.trackID;

        int x = obj.rect.x;
        int y = obj.rect.y;
        int width = obj.rect.width;
        int height = obj.rect.height;

        ANNIWOLOG(INFO) <<"ZxyDetection:DEBUG: obj x1:"<<x<<"y1:"<<y<<"width:"<<width<<"height:"<<height<<"camID:"<<camID;
        ANNIWOLOG(INFO) <<"ZxyDetection:DEBUG: obj orig_img_w:"<<orig_img_w <<"orig_img_h:"<<orig_img_h<<"camID:"<<camID;

    //     // todo:Below is leave for debugging!
    //     cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
    //     float c_mean = cv::mean(color)[0];
    //     cv::Scalar txt_color;
    //     if (c_mean > 0.5){
    //         txt_color = cv::Scalar(0, 0, 0);
    //     }else{
    //         txt_color = cv::Scalar(255, 255, 255);
    //     }

    //     cv::rectangle(img, obj.rect, color * 255, 2);

    //     char text[256];
    //     sprintf(text, "%s %.1f%% tid:%d", class_names_xieyouitems[obj.label].c_str(), obj.prob * 100, trackID);
    //     ANNIWOLOGF(INFO,"ZxyDetection:%s %.1f tid:%d x:%d y:%d w:%d h:%d ,camID:%d\n", \
    //         class_names_xieyouitems[obj.label].c_str(), obj.prob, trackID,x,y,width,height,camID);

    //     int baseLine = 0;
    //     cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

    //     cv::Scalar txt_bk_color = color * 0.7 * 255;

    //     x = obj.rect.x;
    //     y = obj.rect.y + 1;
    //     if (y > img.rows)
    //         y = img.rows;

    //     cv::rectangle(img, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
    //                   txt_bk_color, -1);

    //     cv::putText(img, text, cv::Point(x, y + label_size.height),
    //                 cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);


    }

    //debug
    // std::string imagename=getRandomName();
    // std::string imgPath = "./xieyou/" + imagename;
    // cv::imwrite(imgPath,img);
    // ANNIWOLOG(INFO) << "ZxyDetection:debug save name"<<imagename <<"camID:"<<camID ;
    
    outDurn=durn;
    return newpersonvehicleCnt;
}

//objects是基于class_names_xieyouitems
void mainfuncZXY(int camID,int instanceID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr)
{

    std::vector<Object> offendPersonVehicleObjects;
    std::vector<Object> offendPersonVehicleNoTypefilter; //不进行concern type和exclude type过滤，进进行valid area过滤的

    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int offendnewPersonCnt=0;
    writer.StartArray();    



    int img_w = image.cols;
    int img_h = image.rows;


    //todo:以后优化这一块。
    std::set<std::string> concern_classes;
    std::set<std::string> exclude_classes;
    //取得关注类型
    //valid types
    //camId,{func,Vector<String>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::const_iterator got_id_func_cap = validtypes_map_ptr->find(camID);


    if (got_id_func_cap == validtypes_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "ZxyDetection:not set in validtypes_conf_map for camID:" <<camID<<"use default classes";
        //use default all
    }
    else
    {
        const std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >::const_iterator got_id_func_cap2 = conf_map.find("zhuangxieyou");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "ZxyDetection:not set safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";

            //use default all
        }
        else
        {
            const AnniwoSafeEreaConcernTypes& typesST = got_id_func_cap2->second;
            if(typesST.validtypes.size() == 0 )
            {
                ANNIWOLOG(INFO) << "ZxyDetection:empty in validtypes_conf_map for camID:" <<camID<<"at least tank_truck should be there!";

                ANNIWOCHECK(false);

            }
            else if(typesST.validtypes.size() >= 1)
            {

                ANNIWOLOG(INFO) << "ZxyDetection:used concern_classes from config for camID:" <<camID ;


                concern_classes.clear();
                for(auto& onetype:typesST.validtypes)
                {
                    concern_classes.insert(onetype);
                }

                exclude_classes.clear();
                for(auto& onetype:typesST.excludeTypes)
                {
                    exclude_classes.insert(onetype);
                }

            }

        }
    }



    //日志打印
    for(auto& onetype:concern_classes)
    {
       ANNIWOLOG(INFO) << "ZxyDetection:concern_classes for camID:" <<camID <<","<< onetype;
    }
    
    for(auto& onetype:exclude_classes)
    {
       ANNIWOLOG(INFO) << "ZxyDetection:exclude_classes for camID:" <<camID <<","<< onetype;
    }
    


///////////////////////////////////////////////////////////////////////////////////////////////////////////
    float  inter_area=0.;
    float  gzf_area=0.;
    float  obj_area=0.;
    std::vector<int> clothes_classes;


    bool isClassToReport=false;//类型判断用

    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];





        ANNIWOLOG(INFO) <<
        "ZxyDetection: detect. box:"<<obj.rect.x<<","<< obj.rect.y<<","
        <<obj.rect.width<<","<<obj.rect.height<<","
        << "score:"<<obj.prob<<"class:"<<class_names_xieyouitems[obj.label].c_str()<<","<<"trackid:"<<obj.trackID <<" camID:"<<camID;

        //人下部
        float x1=obj.rect.x;
        float y1 = obj.rect.y;
        float x2=(obj.rect.x+obj.rect.width) > img_w ? img_w : (obj.rect.x+obj.rect.width) ;
        float y2 =(obj.rect.y+obj.rect.height) > img_h ? img_h: (obj.rect.y+obj.rect.height);
        
        float y1_ = y1;
        float y2_ = y2;
        if(class_names_xieyouitems[obj.label] == "person"
        // || class_names_xieyouitems[obj.label] == std::string("work_clothe_blue")
        // || class_names_xieyouitems[obj.label] == std::string("work_clothe_yellow")
        )  //人员要求小腿到脚部分在设定区域内
        {
            y1_ = (obj.rect.y+obj.rect.height/4.0*3.0) > y2 ? y2: (obj.rect.y+obj.rect.height/4.0*3.0);
        }

        if(class_names_xieyouitems[obj.label] == "tank_truck")  //油罐车要求上部2/3在设定区域内
        {
            y2_ = (obj.rect.y+obj.rect.height/3.0*2.0) > y2 ? y2: (obj.rect.y+obj.rect.height/3.0*2.0);
        }


        float area = 0.0;
        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1_)));
            box_poly.add(cv::Point(int(x2),int(y1_)));
            box_poly.add(cv::Point(int(x2),int(y2_)));
            box_poly.add(cv::Point(int(x1),int(y2_)));
            _inter.clear();
            intersectPolygonSHPC(*polygonSafeArea_ptr,box_poly,_inter);
            //此处无交集时候size==0?
            if( _inter.size() ) {
                area = _inter.area();
                ANNIWOLOG(INFO) <<"ZxyDetection: Area half object intersected = "<<area<<"camID:"<<camID;

                if(area > 768.0)
                {
                    //通过，在下面执行正常逻辑
                    ANNIWOLOG(INFO) <<
                        "ZxyDetection: detect.checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<class_names_xieyouitems[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;

                }else
                {
                    ANNIWOLOG(INFO) <<
                        "ZxyDetection: detect.Ignore checkSafeArea box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<class_names_xieyouitems[obj.label].c_str()<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    //忽略这个对象!
                    continue;
                }

            }else
            {
                ANNIWOLOG(INFO) <<"ZxyDetection: Area intersected None: "<<area<<"camID:"<<camID;
                continue;

            }
        }else
        {
            ANNIWOLOG(INFO) <<"ZxyDetection: Area not setting. "<<area<<"camID:"<<camID;
        }


//***********************
        Object objPersonNoTypefilter;
        objPersonNoTypefilter.rect.x=obj.rect.x;
        objPersonNoTypefilter.rect.y=obj.rect.y;
        objPersonNoTypefilter.rect.width =obj.rect.width;
        objPersonNoTypefilter.rect.height=obj.rect.height;
        objPersonNoTypefilter.trackID=obj.trackID;
        objPersonNoTypefilter.prob= obj.prob;
        objPersonNoTypefilter.label = obj.label;
        strncpy((char*)objPersonNoTypefilter.uuid, (char*)obj.uuid, sizeof(uuid_t));


        offendPersonVehicleNoTypefilter.emplace_back(objPersonNoTypefilter);
//***********************




        //关注类别过滤,目前是传什么就报什么！！！
        isClassToReport=false;
        for(auto& onetype:concern_classes)
        {
            if(onetype == class_names_xieyouitems[obj.label])
            {
                isClassToReport=true;
                break;
            }

        }

        if(!isClassToReport)
        {
            ANNIWOLOG(INFO) <<"ZxyDetection: Ignored by concern types setting."<<"camID:"<<camID;
            continue;
        }


        clothes_classes.push_back(obj.label);

        //check exclude types
        isClassToReport=true;

        if(exclude_classes.size() > 0 )
        {
            for(int i=0; i < clothes_classes.size(); i++)
            {
                if(isClassToReport)
                {
                    for(auto& onetype:exclude_classes)
                    {
                        if( onetype  ==  class_names_xieyouitems[clothes_classes[i]] )
                        {
                            isClassToReport=false;
                            ANNIWOLOG(INFO) <<"ZxyDetection: found in exclude types setting:"<<onetype<<" camID:"<<camID;

                            break;
                        }

                    }
                }else
                {
                    break;
                }
                 
            }
            
        }

        if(!isClassToReport)
        {
            ANNIWOLOG(INFO) <<"ZxyDetection: Ignored by exclude types setting."<<"camID:"<<camID;
            continue;
        }
        
        Object objPerson;
        objPerson.rect.x=obj.rect.x;
        objPerson.rect.y=obj.rect.y;
        objPerson.rect.width =obj.rect.width;
        objPerson.rect.height=obj.rect.height;
        objPerson.trackID=obj.trackID;
        objPerson.prob= obj.prob;
        objPerson.label = obj.label;
        strncpy((char*)objPerson.uuid, (char*)obj.uuid, sizeof(uuid_t));


        offendPersonVehicleObjects.emplace_back(objPerson);


    }



/////////////TRACKING PART//////////////////////////////////
    int durn=-1;
    if(offendPersonVehicleObjects.size() > 0 )
    {
        offendnewPersonCnt = deDuplicateTrackResults(camID,image,offendPersonVehicleNoTypefilter,offendPersonVehicleObjects,/*out*/durn);
    }else
    {
        ANNIWOLOG(INFO) <<"ZxyDetection:no offendPersonVehicleObjects"<<"camID:"<<camID<<" "<<std::endl;
        return;

    }

/////////////TRACKING PART END//////////////////////////////////


    if(offendnewPersonCnt > 0)
    {

        ////////////////////////////////////

        ANNIWOLOG(INFO) << "ZxyDetection: zxy_items. itemsResults size:"<<offendPersonVehicleObjects.size()  <<"camID:"<<camID<<" ";
        isClassToReport=false;
        for(auto& offendObj:offendPersonVehicleObjects)
        {
            for(auto& onetype:concern_classes)
            {
                if(onetype == class_names_xieyouitems[offendObj.label])
                {
                    isClassToReport=true;

                    float x1=offendObj.rect.x;
                    float y1 = offendObj.rect.y;
                    float x2=(offendObj.rect.x+offendObj.rect.width) > img_w ? img_w : (offendObj.rect.x+offendObj.rect.width) ;
                    float y2 =(offendObj.rect.y+offendObj.rect.height) > img_h ? img_h: (offendObj.rect.y+offendObj.rect.height);


                    writer.StartObject();               // Between StartObject()/EndObject(), 

                    writer.Key("y1");                
                    writer.Int(y1);            
                    writer.Key("x1");                
                    writer.Int(x1);  
                    writer.Key("y2");                
                    writer.Int(y2);  
                    writer.Key("x2");                
                    writer.Int(x2);  
                    writer.Key("classItem");                // output a key,
                    writer.String(class_names_xieyouitems[offendObj.label].c_str()); 
                    writer.Key("staytime");                // output a key,
                    writer.Int(durn); 
                    writer.EndObject();  


                    ANNIWOLOG(INFO) << "ZxyDetection: ." <<"camID:"<<camID<<" ";
                    break;
                }

            }

        }



        

        writer.EndArray();


        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/zhuangxieyou/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/zhuangxieyou"};

        getTaskId(globalJsonConfObjPtr,camID,"zhuangxieyou",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"zhuangxieyou","/zhuangxieyou",submitUrl);

        ANNIWOLOG(INFO) <<"ZxyDetection:save file name drawed is:"<<"camID:"<<camID<<" "<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);
    }else
    {
        writer.EndArray();
        ANNIWOLOG(INFO) <<"ZxyDetection:no offendnewPersonCnt"<<"camID:"<<camID<<" "<<std::endl;
        return;


    }
}





void ZxyDetection::initTracks(
    const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    stay_conf_map_ptr=&globalJsonConfObj.stay_conf_map;
    validtypes_map_ptr=&globalJsonConfObj.validtypes_map;

    globalJsonConfObjPtr=&globalJsonConfObj;

    allLastObjects.clear();

    // static const std::unordered_map<int,std::unordered_map<int, std::chrono::system_clock::time_point>  > trackStayMap;
    trackStayMap.clear();
    reporthistoryArray.clear();
    
    thisTimeReportArray.clear();
    iSStayConfigCheckOKArray.clear();



    if(DS)
    {
        delete DS;
    }


    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        zxyItemsDet->initTracks(globalJsonConfObj);
        absenceObjPtr->init(globalJsonConfObj);


    }else
    {
        ANNIWOLOG(INFO) << "ZxyDetection::initTracks NOT SUPPORT on non-jiayouzhan mode";
    }

    std::unordered_set<int> setcamIDs ;
    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("zhuangxieyou") )
            {
                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "ZxyDetection::initTracks:reporthistory insert" <<"camID:"<<camID<<" ";
                reporthistoryArray.insert(std::pair<int, std::unordered_map<int, int >  >(camID,trackidhits) );
                thisTimeReportArray.insert(std::pair<int, bool >(camID,false) );
                iSStayConfigCheckOKArray.insert(std::pair<int, bool >(camID,false) );


                std::unordered_map<int, AnniwoTrackRecord > emptymp;
                trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecord >  >(camID,emptymp) );

                std::vector<Object> emptyObjArray;
                ANNIWOLOG(INFO) << "ZxyDetection::initTracks:allLast insert" <<"camID:"<<camID<<" ";
                allLastObjects.insert(std::pair<int, std::vector<Object>  >(camID,emptyObjArray) );

                setcamIDs.insert(camID);
                break;
            }
            else
            {
                continue;
            }
        }
    }

    std::vector<int> camIDs;

    /////内置一个跟踪
    for (auto& camID : setcamIDs)
    {
        camIDs.push_back(camID);
    }

    //人和车分开用reid,加油站情况。
    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        DS = new DeepSort(deepsort_model_file_path_model,&deepsort_model_file_path_model2, reidbatchsize, camIDs,globalINICONFObj.ANNIWO_NUM_INSTANCE_ZXY);
    }


}


static int isLight(cv::Mat src, int camID)
{
    cv::Mat gray;
    //转为灰度图片
    cv::cvtColor(src, gray, cv::COLOR_BGR2GRAY);
    float sum = 0;
    float avg = 0;
    cv::Scalar scalar;
    int ls[256];
    int size = gray.rows * gray.cols;
    for (int i = 0; i < 256; i++)
        ls[i] = 0;
    for (int i = 0; i < gray.rows; i++)
    {
        for (int j = 0; j < gray.cols; j++)
        {
            //scalar = cvGet2D(gray, i, j);
            scalar = gray.at<uchar>(i, j);
            sum += (scalar.val[0] - 128);
            int x = (int)scalar.val[0];
            ls[x]++;
        }
    }
    avg = sum / size;
    float total = 0;
    float mean = 0;
    for (int i = 0; i < 256; i++)
    {
        total += abs(float(i - 128) - avg) * ls[i];
    }
    mean = total / size;
    float cast = abs(avg / mean);
    ANNIWOLOG(INFO) <<  "light cast:" << cast << "camID:"<<camID;
    if (cast > 1)
    {
        if (avg > 0)
        {
            ANNIWOLOG(INFO) << "over light:" << avg << "camID:"<<camID;
            return 1;
        }
        else {
            ANNIWOLOG(INFO) << "over dark:" << avg << "camID:"<<camID;
            return -1;
        }
    }
    else
    {
        ANNIWOLOG(INFO) << "normal:" << "camID:"<<camID;
        return 0;
    }
}

//todo:polygonSafeArea
void ZxyDetection::detect(  int camID, int instanceID, cv::Mat img,const Polygon* polygonSafeArea_ptr) 
{    
    cv::Mat image = img;
    

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
        ANNIWOLOG(INFO) << "ZxyDetection: domain is jiayouzhan" <<"camID:"<<camID<<" ";

        /////////////////////////////////////////////////////////////opencv过滤过白坏图
        if(isLight(image,camID) != 0)
        {
            ANNIWOLOG(INFO) << "ZxyDetection: ignored by over light/dark." <<"camID:"<<camID<<" ";
            return;
        }

        /////////////////////////////////////////////////////////////




        std::vector<Object> itemsResults;
        zxyItemsDet->detect( camID,  instanceID, image, itemsResults );
        int img_w = image.cols;
        int img_h = image.rows;
        
        if(itemsResults.size() > 0)
        {
            thisTimeReportArray[camID]=false;  //正式判断前重置该值，这样只有当本次检测到tank_truck的时候才报警

            std::vector<DetectBox> track_results;
            for (size_t i = 0; i < itemsResults.size(); i++)
            {
                Object& obj = itemsResults[i];

                float x1=obj.rect.x;
                float y1 = obj.rect.y;
                float x2=(obj.rect.x+obj.rect.width) > img_w ? img_w : (obj.rect.x+obj.rect.width) ;
                float y2 =(obj.rect.y+obj.rect.height) > img_h ? img_h: (obj.rect.y+obj.rect.height);

                DetectBox detBoxObj;
                detBoxObj.x1 = x1; 
                detBoxObj.y1= y1; 
                detBoxObj.x2= x2; 
                detBoxObj.y2= y2;
                detBoxObj.confidence = obj.prob;

                //区分人，车。因为需要用不同的reid encoder.
                //0:为人，1为车
                //0:"person"
                if(    class_names_xieyouitems[obj.label]  == std::string("person")
                    // || class_names_xieyouitems[obj.label] == std::string("work_clothe_blue")
                    // || class_names_xieyouitems[obj.label] == std::string("work_clothe_yellow")
                )
                {
                    detBoxObj.classID = 0;
                }
                else
                {
                    detBoxObj.classID = 1;
                }
                
                uuid_generate_random(detBoxObj.uuid);
                track_results.push_back(detBoxObj);


                obj.trackID=-1;

                strncpy((char*)obj.uuid, (char*)detBoxObj.uuid, sizeof(uuid_t));

            }

            if(track_results.size() > 0)
            {
                if(DS)
                {
                    cv::Mat img_rgb;
                    cv::cvtColor(image, img_rgb, cv::COLOR_BGR2RGB);

                    DS->sort(img_rgb, track_results,camID,instanceID);
                }else
                {
                    ANNIWOLOG(INFO) <<"ZxyDetection::detect FATAL ERROR! DS is null!\n";
                }

            }

            //uuid匹配track与det框。
            for (auto & personvehicel_det : itemsResults) 
            {
                int trackID = -1;

                for (auto & box : track_results ) {
                    // if(box.uuid == personvehicel_det.uuid)
                    if(0 == strncmp( (char *)box.uuid,  (char *)personvehicel_det.uuid, sizeof(uuid_t)))
                    {
                        trackID = (int)box.trackID;
                        personvehicel_det.trackID = trackID;
                        
                    }
                }

                ANNIWOLOG(INFO) <<"ZxyDetection:detect:"<<class_names_xieyouitems[personvehicel_det.label].c_str()<<","<< personvehicel_det.prob<<","<< "tid:"<<trackID<<  "  x, y, w,  h:"<<personvehicel_det.rect.x<<","<<personvehicel_det.rect.y<<","<<personvehicel_det.rect.width<<","<<personvehicel_det.rect.height<<","<<" camID:"<<camID;

            }

            mainfuncZXY(camID,instanceID, image, itemsResults,polygonSafeArea_ptr);
        }
        else
        {
            ANNIWOLOG(INFO) << "ZxyDetection:no objects" <<"camID:"<<camID<<" ";
        }


    }else
    {
        ANNIWOLOG(INFO) << "ZxyDetection:NOT SUPPORT ON non-jiayouzhan mode" <<"camID:"<<camID<<" ";

    }



    ANNIWOLOG(INFO) << "ZxyDetection:exit detect()" <<"camID:"<<camID<<" ";
    
    return;
}
