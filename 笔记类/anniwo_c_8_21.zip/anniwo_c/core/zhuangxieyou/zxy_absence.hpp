#ifndef YOLOX_ZHUANGXIEYOU_ABSENCE_H
#define YOLOX_ZHUANGXIEYOU_ABSENCE_H
#include <opencv2/opencv.hpp>
#include "../utils/utils_intersection.hpp"
#include "../common/yolo/yolo_common.hpp"



class ZxyAbsence  {
    public:
        ZxyAbsence() ;
        ~ZxyAbsence() ;

        void init(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);

        static void startOrcheck(int camID, cv::Mat bgr, std::vector<Object>& offend_boxes_det);
        static void stop(int camID);
};

#endif 

