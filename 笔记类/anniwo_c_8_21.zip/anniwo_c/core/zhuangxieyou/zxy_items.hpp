#ifndef YOLOX_ZHUANGXIEYOU_ITEMS_H
#define YOLOX_ZHUANGXIEYOU_ITEMS_H
#include <opencv2/opencv.hpp>
#include "../utils/utils_intersection.hpp"

#include <unordered_set>
#include <unordered_map>

extern const std::vector<std::string> class_names_xieyouitems;

class ZxyItems  {
    public:
        ZxyItems() ;
        ~ZxyItems() ;

        void initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj);
        //todo:polygonSafeArea
        static void detect(  int camID,int instanceID, cv::Mat img, std::vector<Object>& objects);

    private:
        static  std::unordered_map<int, std::vector<float> >  m_input_datas;
        
};

#endif 

