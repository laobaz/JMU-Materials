#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include<set>

#include <opencv2/opencv.hpp>
#include <dirent.h>




#include "zxy_absence.hpp"
#include "zxy_items.hpp"

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "../common/mot/include/deepsort.h"

#include <uuid/uuid.h>
#include <unordered_map>
#include <sys/stat.h>




static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;

////////////
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoStay>  >* stay_conf_map_ptr;
static const std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >*  validtypes_map_ptr;


//临时记录结构，用于检查该trackid对应的目标停留时间是否已经达到阈值
// {camID,{trackid,stayStart}}

// //struct默认构造函数不行。动态分配的如cvMat需要手动写一个构造函数
// class AnniwoTrackRecordZxyAbsence
// {
// public:
//     AnniwoTrackRecordZxyAbsence(const Object& inResult, const  std::chrono::system_clock::time_point& inStartPoint, const  cv::Mat inImg)
//     {
//         detresult=inResult;
//         startPoint=inStartPoint;
//         img = inImg;
//     }    

//     ~AnniwoTrackRecordZxyAbsence()
//     {
//         img.release();
//         ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck destructor called." ;

//     }

//     AnniwoTrackRecordZxyAbsence& operator=(AnniwoTrackRecordZxyAbsence&& other)
//     {
//         std::swap(detresult,other.detresult);
//         std::swap(startPoint,other.startPoint);
//         img = other.img;

//         ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck operator= called." ;

//     }

//     AnniwoTrackRecordZxyAbsence(AnniwoTrackRecordZxyAbsence&& other): detresult(other.detresult), startPoint(other.startPoint),img(other.img)
//     {
//         ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck move constructor called." ;

//     }

//     //复制构造，入参需要为const.否则与stl::pair里边的对不上
//     AnniwoTrackRecordZxyAbsence(const AnniwoTrackRecordZxyAbsence& other): detresult(other.detresult), startPoint(other.startPoint),img(other.img)
//     {
//         ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck copy constructor called." ;

//     }

// public:
//     Object detresult; //
//     std::chrono::system_clock::time_point startPoint;  //stayStart时间
//     cv::Mat img;
// };


struct AnniwoTrackRecordZxyAbsence
{
    Object detresult; //
    std::chrono::system_clock::time_point startPoint;  //stayStart时间
    cv::Mat img;
};


static  std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecordZxyAbsence>  > trackStayMap;


// Default constructor
ZxyAbsence::ZxyAbsence () { 

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {
       
           struct stat st = {0};
           std::string onlineSavePath={"/var/anniwo/images//absence/"};
            //创建目录
            if (stat(onlineSavePath.c_str(), &st) == -1) {
                mkdir(onlineSavePath.c_str(), 0700);
            }
            //检查是否创建成功
            if (stat(onlineSavePath.c_str(), &st) == -1) {
                ANNIWOLOG(INFO) <<"Unable to create:"<<onlineSavePath;
                ANNIWOCHECK(false);
                exit(-1);
            }


    }else
    {
        ANNIWOLOG(INFO) << "ZxyAbsence():Not use zhuangxieyou in other than jiayouzhan domain!" ;
        ANNIWOCHECK(false);
    }
    
    
    ANNIWOLOG(INFO) << "ZxyAbsence(): Success initialized!" ;

}



// Destructor
ZxyAbsence::~ZxyAbsence () 
{

}


//objects是基于class_names_xieyouitems
//开始检测是否有离岗,此函数自行检测是否有离岗标志
//offend_boxes_det已经在zhuangxieyou主类里边通过了validArea过滤过了
void ZxyAbsence::startOrcheck(int camID, cv::Mat bgr, std::vector<Object>& offend_boxes_det)
{

    std::vector<Object> offendPersonVehicleObjects; //装关注类别的，比如蓝色工作服人员


	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    

    writer.StartArray();    

    int img_w = bgr.cols;
    int img_h = bgr.rows;


    //todo:以后优化这一块。
    std::set<std::string> concern_classes;
    std::set<std::string> exclude_classes;
    //取得关注类型
    //valid types
    //camId,{func,Vector<String>}
    std::unordered_map<int,std::unordered_map<std::string, AnniwoSafeEreaConcernTypes>  >::const_iterator got_id_func_cap = validtypes_map_ptr->find(camID);


    if (got_id_func_cap == validtypes_map_ptr->end())
    {
        ANNIWOLOG(INFO) << "ZxyAbsence:not set in validtypes_conf_map for camID:" <<camID<<"use default classes";
        //use default all
        concern_classes.insert("work_clothe_blue");
        concern_classes.insert("work_clothe_yellow");
    }
    else
    {
        const std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >& conf_map =got_id_func_cap->second;
        std::unordered_map<std::string, AnniwoSafeEreaConcernTypes >::const_iterator got_id_func_cap2 = conf_map.find("absence");
        if (got_id_func_cap2 == conf_map.end())
        {
            ANNIWOLOG(INFO) << "ZxyAbsence:not set safeErea in validtypes_conf_map for camID:" <<camID<<"use default classes";

            //use default all
        }
        else
        {
            const AnniwoSafeEreaConcernTypes& typesST = got_id_func_cap2->second;
            if(typesST.validtypes.size() == 0 )
            {
                ANNIWOLOG(INFO) << "ZxyAbsence:empty in validtypes_conf_map for camID:" <<camID<<"at least tank_truck should be there!";

            }
            else if(typesST.validtypes.size() >= 1)
            {

                ANNIWOLOG(INFO) << "ZxyAbsence:used concern_classes from config for camID:" <<camID ;


                concern_classes.clear();
                for(auto& onetype:typesST.validtypes)
                {
                    concern_classes.insert(onetype);
                }

                exclude_classes.clear();
                for(auto& onetype:typesST.excludeTypes)
                {
                    exclude_classes.insert(onetype);
                }

            }

        }
    }



    //日志打印
    for(auto& onetype:concern_classes)
    {
       ANNIWOLOG(INFO) << "ZxyAbsence:concern_classes for camID:" <<camID <<","<< onetype;
    }
    
    //absence exlude class不需要考虑?
    for(auto& onetype:exclude_classes)
    {
       ANNIWOLOG(INFO) << "ZxyAbsence:exclude_classes for camID:" <<camID <<","<< onetype;
    }
    
////////////////////////////////////////////////////////////////////////////////////


    bool foundConcernObj=false;//是否有关注类型存在
    bool isOilStartExsists=false;//加油牌是否存在

    for (size_t i = 0; i < offend_boxes_det.size(); i++) //查找里边有没有关注类型和牌子
    {
        const Object& obj = offend_boxes_det[i];

        
        ANNIWOLOG(INFO) <<
        "ZxyAbsence: detect. box:"<<obj.rect.x<<","<< obj.rect.y<<","
        <<obj.rect.width<<","<<obj.rect.height<<","
        << "score:"<<obj.prob<<"class:"<<class_names_xieyouitems[obj.label].c_str()<<","<<"trackid:"<<obj.trackID <<" camID:"<<camID;

        if( class_names_xieyouitems[obj.label] == std::string("Oil_start") )
        {
            isOilStartExsists = true;
        }

        foundConcernObj=false;
        //关注类别：即关注的离岗人员类别，这些类别没有的时候才报警
        for(auto& onetype:concern_classes)
        {
            if(onetype == class_names_xieyouitems[obj.label])
            {
                foundConcernObj=true;
                break;
            }

        }

        if(!foundConcernObj) //本obj不是关注类型，忽略。
        {
            continue;
        }
        
        Object objPerson;
        objPerson.rect.x=obj.rect.x;
        objPerson.rect.y=obj.rect.y;
        objPerson.rect.width =obj.rect.width;
        objPerson.rect.height=obj.rect.height;
        objPerson.trackID=obj.trackID;
        objPerson.prob= obj.prob;
        objPerson.label = obj.label;
        strncpy((char*)objPerson.uuid, (char*)obj.uuid, sizeof(uuid_t));


        offendPersonVehicleObjects.emplace_back(objPerson);//里边放关注类型


    }


    //关注类别，这些类别没有的时候才报警
    bool isThisTimeReport=false;

    std::chrono::system_clock::time_point absenceStartTP;

    cv::Mat img_s;

    if(offendPersonVehicleObjects.size() > 0 )
    {
        ANNIWOLOG(INFO) <<"ZxyAbsence:concern Person Objects cnt:"<<offendPersonVehicleObjects.size()<<"camID:"<<camID;

        //clear the absence track record.
        std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecordZxyAbsence>  >::iterator got_id_func_cap = trackStayMap.find(camID);

        if (got_id_func_cap == trackStayMap.end())
        {
            ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck WARN: cam not in trackStayMap,camID:" <<camID;
        }
        else
        {
            std::unordered_map<int, AnniwoTrackRecordZxyAbsence>& track_stay_map =got_id_func_cap->second;
            track_stay_map.clear(); 
        }

        return;
    }else if(isOilStartExsists) //有牌子并且没有关注的人
    {
        ANNIWOLOG(INFO) <<"ZxyAbsence:no concern Person Objects.Absence check"<<"camID:"<<camID<<" ";

        AnniwoStay stayconfig;
        stayconfig.isMotionless=false;
        stayconfig.staySec=-1;
        //取得离岗时间设置
        //stayconfig
        //camId,{func,<isMotionless,stay in seconds>}
        std::unordered_map<int,std::unordered_map<std::string, AnniwoStay> >::const_iterator got_id_func_cap = stay_conf_map_ptr->find(camID);

        if (got_id_func_cap == stay_conf_map_ptr->end())
        {
            ANNIWOLOG(INFO) << "not found in stay_conf_map,camID:" <<camID;
        }
        else
        {
            const std::unordered_map<std::string, AnniwoStay>& conf_map =got_id_func_cap->second;
            std::unordered_map<std::string, AnniwoStay>::const_iterator got_id_func_cap2 = conf_map.find("absence");
            if (got_id_func_cap2 == conf_map.end())
            {
                ANNIWOLOG(INFO) << "not found absence in stay_conf_map,camID:" <<camID;
            }
            else
            {
                stayconfig = got_id_func_cap2->second ;
            }
        }

        if (stayconfig.staySec <= 0) //停留时间:当无离岗时间配置的时候,只要无人就报警
        {
            isThisTimeReport=true;
        }else//检查离岗时间
        {
            std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecordZxyAbsence>  >::iterator got_id_func_cap = trackStayMap.find(camID);

            if (got_id_func_cap == trackStayMap.end())
            {
                ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck WARN: trackStayMap,camID:" <<camID;
            }
            else
            {
                std::unordered_map<int, AnniwoTrackRecordZxyAbsence>& track_stay_map =got_id_func_cap->second;
                //整图计时，虚拟一个tranckid:0
                int virtualtrackID=0;
                Object virtualobj; //虚拟一个空obj
                std::unordered_map<int, AnniwoTrackRecordZxyAbsence>::iterator got_id_func_cap2 = track_stay_map.find(virtualtrackID);
                if (got_id_func_cap2 == track_stay_map.end())
                {
                    //map中未记录该track_id
                    ANNIWOLOG(INFO) << "ZxyAbsence.startOrcheck not found in track_stay_map,new add trackID:"<<virtualtrackID<<"camID:" <<camID;
                    cv::Mat tmpMat =   bgr;
                    AnniwoTrackRecordZxyAbsence tmpRecord{virtualobj,std::chrono::system_clock::now(),tmpMat};
                    ANNIWOCHECK(tmpRecord.img.data != NULL);

                    //pair会调用forward,forward会选择使用移动构造或者拷贝构造
                    std::pair<int, AnniwoTrackRecordZxyAbsence> tmpPair(virtualtrackID,std::move(tmpRecord));


                    track_stay_map.insert( std::move(tmpPair) );
                    ANNIWOLOG(INFO) << "DEBUG ZxyAbsence.startOrcheck not found in track_stay_map,added success"<<virtualtrackID<<"camID:" <<camID;

                }
                else if(got_id_func_cap2->second.startPoint==std::chrono::system_clock::from_time_t(0))//报过一次，重新计时
                {
                    got_id_func_cap2->second.startPoint=std::chrono::system_clock::now();
                    got_id_func_cap2->second.img=bgr;
                }
                else
                {   
                    int durn=-1;
                    // got_id_func_cap2->second 是开始时间
                    //如果开始时间是设置的…0…值,是已经报过了则不报。
                    if(got_id_func_cap2->second.startPoint > std::chrono::system_clock::from_time_t(0))
                    {
                        if(stayconfig.isMotionless)//要检测到静止之后开始计时
                        {
                            //不存在
                        }else
                        {
                            durn = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now() - got_id_func_cap2->second.startPoint).count();
                        }

                        ANNIWOLOG(INFO) <<"ZxyAbsence.startOrcheck:isMotionless:"<<stayconfig.isMotionless<<" trackID "<<virtualtrackID<<" durn:"<<durn<<" camID:"<<camID;

                        if(durn > stayconfig.staySec)
                        {
                            isThisTimeReport=true;
                            absenceStartTP=got_id_func_cap2->second.startPoint;
                            img_s = got_id_func_cap2->second.img;
                            //报过一次之后，将其更新为0
                            got_id_func_cap2->second.startPoint=std::chrono::system_clock::from_time_t(0);
                            ANNIWOLOG(INFO) <<"ZxyAbsence.startOrcheck:isThisTimeReport triggered:"<<isThisTimeReport<<" virtualtrackID "<<virtualtrackID<<" durn:"<<durn<<" camID:"<<camID;

                        }

                    }

                }
            }

        }

    }else
    {
        //既无关注物，也无牌子
    }



    if(isThisTimeReport == true)
    {

        float x1=10;
        float y1 = 10;
        float x2=img_w;
        float y2 =img_h;


        writer.StartObject();               // Between StartObject()/EndObject(), 

        writer.Key("y1");                
        writer.Int(y1);            
        writer.Key("x1");                
        writer.Int(x1);  
        writer.Key("y2");                
        writer.Int(y2);  
        writer.Key("x2");                
        writer.Int(x2);  
        writer.Key("classItem");                // output a key,
        writer.String("absence"); 
        writer.EndObject();  


        writer.EndArray();


        std::string imagename=getRandomName("");
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/absence/" + imagename + ".jpg";

        ANNIWOCHECK(img_s.data != NULL);
        std::string imagenameS=imagename + std::string("_s") + ".jpg";
        std::string imgPathS = ANNIWO_LOG_IMAGES_PATH + "/absence/" + imagenameS;
        ANNIWOLOG(INFO) <<"ZxyAbsence:save _S file name drawed is:"<<"camID:"<<camID<<" "<<imagenameS;

        cv::imwrite(imgPathS,img_s);


        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/absence"};

        getTaskId(globalJsonConfObjPtr,camID,"absence",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"absence","/absence",submitUrl);

        ANNIWOLOG(INFO) <<"ZxyAbsence:save file name drawed is:"<<"camID:"<<camID<<" "<<imgPath;
        cv::Mat image = bgr;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,
        image,absenceStartTP,
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);
    }else
    {
        writer.EndArray();
        ANNIWOLOG(INFO) <<"ZxyAbsence:PersonCnt"<<offendPersonVehicleObjects.size()<<",camID:"<<camID<<" ";
        return;
    }
}


//卸油区没有检测到油罐车，停止检测是否有离岗
void ZxyAbsence::stop(int camID)
{
    std::unordered_map<int,std::unordered_map<int, AnniwoTrackRecordZxyAbsence>  >::iterator got_id_func_cap = trackStayMap.find(camID);

    if (got_id_func_cap == trackStayMap.end())
    {
        ANNIWOLOG(INFO) << "ZxyAbsence.stop WARN: trackStayMap,camID:" <<camID;
    }
    else
    {
        std::unordered_map<int, AnniwoTrackRecordZxyAbsence>& track_stay_map =got_id_func_cap->second;
        //整图计时，虚拟一个tranckid:0
        int virtualtrackID=0;
        Object virtualobj; //虚拟一个空obj
        std::unordered_map<int, AnniwoTrackRecordZxyAbsence>::iterator got_id_func_cap2 = track_stay_map.find(virtualtrackID);
        if (got_id_func_cap2 == track_stay_map.end())
        {
            //map中未记录该track_id,无需重置
        }
        else
        {   
            ANNIWOLOG(INFO) << "ZxyAbsence.stop DEBUG: trackStayMap, erase camID:" <<camID; 
            track_stay_map.erase(virtualtrackID);
        }
    }
    
}



void ZxyAbsence::init(
    const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    stay_conf_map_ptr=&globalJsonConfObj.stay_conf_map;
    validtypes_map_ptr=&globalJsonConfObj.validtypes_map;

    globalJsonConfObjPtr=&globalJsonConfObj;


    // static const std::unordered_map<int,std::unordered_map<int, std::chrono::system_clock::time_point>  > trackStayMap;
    trackStayMap.clear();

    if(globalINICONFObj.domain_config == ANNIWO_DOMANI_JIAYOUZHAN)
    {

    }else
    {
        ANNIWOLOG(INFO) << "ZxyAbsence::initTracks NOT SUPPORT on non-jiayouzhan mode";
    }

    std::unordered_set<int> setcamIDs ;
    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) 
    {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if (f == std::string("absence") )
            {
                //check absenceStartConition_conf_map
                std::unordered_map<int,std::unordered_map<std::string, std::string>  >::const_iterator got_id_func_cap = globalJsonConfObj.absenceStartConition_conf_map.find(camID);

                if (got_id_func_cap == globalJsonConfObj.absenceStartConition_conf_map.end())
                {
                 //ignore non-zxy absence   
                }else
                {
                    ANNIWOLOG(INFO) << "ZxyAbsence::initTracks:trackStayMap insert" <<"camID:"<<camID<<" ";

                    std::unordered_map<int, AnniwoTrackRecordZxyAbsence > emptymp;
                    trackStayMap.insert(std::pair<int,std::unordered_map<int, AnniwoTrackRecordZxyAbsence >  >(camID,emptymp) );
                }


                break;
            }
            else
            {
                continue;
            }
        }
    }

}

