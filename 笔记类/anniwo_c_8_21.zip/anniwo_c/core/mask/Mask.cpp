#include <fstream>
#include <iostream>
#include <sstream>
#include <numeric>
#include <chrono>
#include <vector>
#include <algorithm>
#include <opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>
#include <xtensor.hpp>
#include "Mask.hpp"

#include "../utils/httpUtil.hpp"

#include "../utils/rapidjson/writer.h"
#include "../utils/rapidjson/stringbuffer.h"
#include "../utils/subUtils.hpp"


#include "../common/yolo/yolo_common.hpp"
#include "../personbase/basePerson.hpp"


static const ANNIWO_JSON_CONF_CLASS* globalJsonConfObjPtr;

//camID, subfunc, trackID, timescnt
static std::unordered_map<int, std::unordered_map<std::string, std::unordered_map<int, int > > > reporthistoryArray ;


const static std::string mask_det_model_file={"../models/mask/best_mask_y4_sim.trt"};


static const int NUM_CLASSES = 2;
static const float BBOX_CONF_THRESH = 0.4;
static const int MAX_CLASS_NUM = 2;

//yolov4 ouput flat size 
static const int YOLO4_OUTPUT_SIZE = 1*7581*NUM_ANCHORS* (NUM_CLASSES + 5);

static const std::vector<std::string>  Maskclass_names = {
"mask_face",
"non_mask_face"
};


static nvinfer1::IRuntime* runtime{nullptr};
static nvinfer1::ICudaEngine* engine{nullptr};
static std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext>> executionContexts;
static std::unordered_map<int, std::unique_ptr<std::mutex> > contextlocks;
static int gpuNum=0;

const int batch_size = 1;
// static std::vector<int> input_shape = {batch_size, 3, INPUT_H, INPUT_W};  //yolox pytorch
static std::vector<int> input_shape = {batch_size, INPUT_H, INPUT_W, 3};    //yolov4 keras/tf

std::unordered_map<int, std::vector<float> >  MaskDetection::m_input_datas;


// Default constructor
MaskDetection::MaskDetection () { 
    ANNIWOLOG(INFO) << "MaskDetection(): call initInferContext!" ;

    gpuNum = initInferContext(
                    mask_det_model_file.c_str(), 
                    &runtime,
                    &engine);

    ANNIWOLOG(INFO) << "MaskDetection(): Success initialized!" ;
}

// Destructor
MaskDetection::~MaskDetection () {

    // destroy the engine
    delete engine;
    delete runtime;

}

static void PostProcessResults(int camID, cv::Mat bgr, const std::vector<Object>& objects, const Polygon* polygonSafeArea_ptr, const std::vector<std::string>& class_names)
{

    cv::Mat image = bgr;
    bgr.release();
	Polygon _inter;
    Polygon box_poly;
    
    rapidjson::StringBuffer jsonstrbuf;
    rapidjson::Writer<rapidjson::StringBuffer> writer(jsonstrbuf);
    
    int jsonObjCnt=0;
    writer.StartArray();  



    for (size_t i = 0; i < objects.size(); i++)
    {
        const Object& obj = objects[i];

        ANNIWOLOGF(INFO, "MaskDetection post:camID:%d, %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f\n  tid:%d",
        camID, 
        class_names[obj.label].c_str(), 
        obj.prob,obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height,obj.trackID);

        if(obj.label > MAX_CLASS_NUM)
        {
            continue;
        }

        //todo:DEBUG
        if( ( class_names[obj.label] == std::string("non_mask_face")  )  && obj.prob > BBOX_CONF_THRESH )
        {

            int x1=obj.rect.x;
            int y1 = obj.rect.y;
            int x2=(obj.rect.x+obj.rect.width) > image.cols ? image.cols : (obj.rect.x+obj.rect.width) ;
            int y2 =(obj.rect.y+obj.rect.height) > image.rows ? image.rows : (obj.rect.y+obj.rect.height);



            writer.StartObject();               // Between StartObject()/EndObject(), 

            writer.Key("y1");                
            writer.Int(y1);            
            writer.Key("x1");                
            writer.Int(x1);  
            writer.Key("y2");                
            writer.Int(y2);  
            writer.Key("x2");                
            writer.Int(x2);  
            writer.Key("classItem");                // output a key,
            writer.String(class_names[obj.label].c_str());             // follow by a value.
        

            writer.EndObject();


            if(obj.trackID == -1)
            {
                //此时报警但不记录
                jsonObjCnt++;

            }else
            {
                //记录已报警过的trackID
                std::unordered_map<int, std::unordered_map<std::string, std::unordered_map<int, int > > >::iterator got_it = reporthistoryArray.find(camID);

                std::unordered_map<std::string, std::unordered_map<int, int > >& perfuncCamIDhistory = got_it->second;
                for(auto& kv:perfuncCamIDhistory )
                {
                    std::unordered_map<int, int >& perCamIDhistory = kv.second;

                    std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(obj.trackID);
                    
                    if (got_it2 == perCamIDhistory.end())//new to this camID
                    {
                        perCamIDhistory.insert(std::pair<int,int>(obj.trackID,1) );
                        jsonObjCnt++;

                    }
                    else
                    {
                        got_it2->second++;
                        ANNIWOLOG(INFO) <<"MaskDetection: Warning:found reported.Ignored.trackID:"<<obj.trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<std::endl;
                    }



                }

                ///


            }



        }

#ifdef ANNIWO_INTERNAL_DEBUG

        //todo:Below is leave for debugging! 描绘部分!
        cv::Scalar color = cv::Scalar(color_list[obj.label][0], color_list[obj.label][1], color_list[obj.label][2]);
        float c_mean = cv::mean(color)[0];
        cv::Scalar txt_color;
        if (c_mean > 0.5){
            txt_color = cv::Scalar(0, 0, 0);
        }else{
            txt_color = cv::Scalar(255, 255, 255);
        }

        cv::rectangle(image, obj.rect, color * 255, 2);

        char text[256];
        sprintf(text, "%s %.1f%%", class_names[obj.label].c_str(), obj.prob * 100);

        int baseLine = 0;
        cv::Size label_size = cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, 0.4, 1, &baseLine);

        cv::Scalar txt_bk_color = color * 0.7 * 255;

        int x = obj.rect.x;
        int y = obj.rect.y + 1;
        if (y > image.rows)
            y = image.rows;

        cv::rectangle(image, cv::Rect(cv::Point(x, y), cv::Size(label_size.width, label_size.height + baseLine)),
                      txt_bk_color, -1);

        cv::putText(image, text, cv::Point(x, y + label_size.height),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, txt_color, 1);
#endif
    }




    writer.EndArray();



    if(jsonObjCnt > 0)
    {

        std::string imagename=getRandomName();
        std::string imgPath = ANNIWO_LOG_IMAGES_PATH + "/" + "mask" + "/" + imagename;

        std::string taskIdstr={"00000"};
        std::string submitUrl={"http://localhost:7008/safety-event-local/socketEvent/mask"};

        getTaskId(globalJsonConfObjPtr,camID,"mask",taskIdstr);
        getEventUrl(globalJsonConfObjPtr,camID,"mask","/mask",submitUrl);

        ANNIWOLOG(INFO) <<"MaskDetection:save file name  is:"<<"camID:"<<camID<<" "<<imgPath<<std::endl;
        pool->enqueue(saveImgAndPost,camID,taskIdstr,imgPath,image,std::chrono::system_clock::from_time_t(0),
        std::string(jsonstrbuf.GetString()),jsonstrbuf.GetLength(), submitUrl);

    }


}





void MaskDetection::initTracks(const ANNIWO_JSON_CONF_CLASS& globalJsonConfObj) 
{
    reporthistoryArray.clear();
    executionContexts.clear();
    contextlocks.clear();
    cudaSetDevice(gpuNum);


    for (auto iter = globalJsonConfObj.id_func_cap.begin(); iter != globalJsonConfObj.id_func_cap.end(); ++iter) {
        int camID= iter->first ;
        for(auto& f : iter->second)
        {
            if ( f == std::string("mask") )
            {
                std::unordered_map<int, int > trackidhits;
                ANNIWOLOG(INFO) << "MaskDetection::initTracks:history insert" <<" subfunc:"<<f<<" camID:"<<camID<<" ";


                std::unordered_map<int, std::unordered_map<std::string, std::unordered_map<int, int > > >::iterator got_it = reporthistoryArray.find(camID);

                if (got_it == reporthistoryArray.end())
                {
                    std::unordered_map<std::string, std::unordered_map<int, int > > functh;
                    functh.insert(std::pair<std::string, std::unordered_map<int, int >  >(f,trackidhits) );
                    reporthistoryArray.insert(std::pair<int, std::unordered_map<std::string, std::unordered_map<int, int >>  >(camID,functh) );
                }else
                {
                    std::unordered_map<std::string, std::unordered_map<int, int > >& perCamIDfunchistory = got_it->second;
                    perCamIDfunchistory.insert(std::pair<std::string, std::unordered_map<int, int > >(f,trackidhits));                    

                }

            }
            else
            {
                continue;
            }
        }
    }

    for(int i=0;i<globalINICONFObj.ANNIWO_NUM_INSTANCE_MASK;i++)
    {
        TrtSampleUniquePtr<nvinfer1::IExecutionContext>  context4thisCam(engine->createExecutionContext());
        std::pair<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> > tmpitem{i,std::move(context4thisCam)};

        executionContexts.insert(std::move(tmpitem));


        std::unique_ptr<std::mutex>    newmutexptr(new std::mutex);
        std::pair<int, std::unique_ptr<std::mutex> > tmplockitem{i,std::move(newmutexptr)};

        contextlocks.insert(std::move(tmplockitem));
    }


    int cntID=0;
    //只生成ANNIWO_NUM_INSTANCE_MASK个实例
    while(cntID < globalINICONFObj.ANNIWO_NUM_THREAD_MASK)
    {
        ANNIWOLOG(INFO) << "MaskDetection::initTracks insert instance" <<"cntID:"<<cntID<<" ";

        std::vector<float> input_data(batch_size * CHANNELS * INPUT_H * INPUT_W);
        std::pair<int, std::vector<float> > itempair2(cntID,std::move(input_data));
        m_input_datas.insert( std::move(itempair2) );

////////////////////////

        cntID++;
    }


    globalJsonConfObjPtr=&globalJsonConfObj;
}

//todo:polygonSafeArea
void MaskDetection::detect(  int camID, int instanceID, cv::Mat img, const Polygon* polygonSafeArea_ptr,const std::vector<Object>& in_person_results) 
{    
    int newpersonCnt=0;
    Polygon _inter;
    Polygon box_poly;
    std::vector<Object> person_det_resultsInside;
    ANNIWOLOG(INFO) <<"MaskDetection: entered."<<"camID:"<<camID<<std::endl;

    for (auto& obj : in_person_results) {

        if( ! isPerson(obj.label) )
            continue;
    
        int x1=obj.rect.x;
        int y1 = obj.rect.y;
        int x2=(obj.rect.x+obj.rect.width) > img.cols ? img.cols : (obj.rect.x+obj.rect.width) ;
        int y2 =(obj.rect.y+obj.rect.height) > img.rows ? img.rows : (obj.rect.y+obj.rect.height);

        if(polygonSafeArea_ptr && polygonSafeArea_ptr->size() >= 3)
        {
            box_poly.clear();
            box_poly.add(cv::Point(int(x1),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y1)));
            box_poly.add(cv::Point(int(x2),int(y2)));
            box_poly.add(cv::Point(int(x1),int(y2)));
            _inter.clear();
            intersectPolygonSHPC(box_poly,*polygonSafeArea_ptr,_inter);
            if( _inter.size() ) {
                float area = _inter.area();
                // cv::Point center = _inter.getCenter();
                // ANNIWOLOGF(INFO,"HelmetDetection: Area intersected = %0.1f \n",area);

                if(area <= 10.0)
                {
                    ANNIWOLOG(INFO) <<
                        "MaskDetection: detect.Ignored as not in valid area box:"<<obj.rect.x<<","<< obj.rect.y<<","
                        <<obj.rect.width<<","<<obj.rect.height<<","
                        << "score:"<<obj.prob<<"class:"<<getPersonCarbaseClassName(obj.label)<<","<<"area:"<<area<<"trackid:"<<obj.trackID <<" camID:"<<camID;
                    continue;

                }else
                {
                    person_det_resultsInside.push_back(obj);
                }



            }else
            {
                ANNIWOLOG(INFO) <<"MaskDetection: inter size none"<<"camID:"<<camID<<std::endl;
                //todo: May have error????
                break;

            }
        }else//use all
        {
            person_det_resultsInside.push_back(obj);
        }

        int trackID = (int)obj.trackID;
        if(trackID == -1)
        {
            newpersonCnt++;
        }else
        {
            std::unordered_map<int, std::unordered_map<std::string, std::unordered_map<int, int > > >::iterator got_it = reporthistoryArray.find(camID);

            if (got_it == reporthistoryArray.end())
            {
                ANNIWOLOG(INFO) <<"MaskDetection: Not in history map!!!"<<"camID:"<<camID<<std::endl;
                ANNIWOCHECK(false);
            }

            std::unordered_map<std::string, std::unordered_map<int, int > >& perCamIDfunchistory = got_it->second;
            for(auto& kv:perCamIDfunchistory )
            {
                std::unordered_map<int, int >& perCamIDhistory = kv.second;

                std::unordered_map<int, int >::iterator got_it2 = perCamIDhistory.find(obj.trackID);
                
                if (got_it2 == perCamIDhistory.end())//new to this camID
                {
                    newpersonCnt++;
                    break;
                }
                else
                {
                    ANNIWOLOG(INFO) <<"MaskDetection: found tracked&reported..trackID:"<<trackID<<"hit:"<<got_it2->second<<"camID:"<<camID<<" func:"<<kv.first<<std::endl;
                }

            }

        }
    }

    if(newpersonCnt <= 0 || person_det_resultsInside.size() <= 0 )
    {
        ANNIWOLOG(INFO) << "MaskDetection:exit no new person detect()" <<"camID:"<<camID;
        return;
    }

/////////////////////////////////////////////////////////////////////////////////
//先进行人脸和口罩检测
    std::vector<Object> facedetobjects;
    cudaSetDevice(gpuNum);

    int choiceIntVal = randIntWithinScale(globalINICONFObj.ANNIWO_NUM_INSTANCE_MASK);
    std::unordered_map<int, TrtSampleUniquePtr<nvinfer1::IExecutionContext> >::iterator iterCamInstance =  executionContexts.find(choiceIntVal);
    std::unordered_map<int, std::unique_ptr<std::mutex> >::iterator iterCamInstancelock =  contextlocks.find(choiceIntVal);
    
    if (iterCamInstance != executionContexts.end()) 
    {
        yolov4_detection_staff(m_input_datas,camID,instanceID,img,
            runtime,engine,
            iterCamInstance->second,//smart pointer context for this cam
            gpuNum,
            iterCamInstancelock->second,//smart pointer context LOCK for this func-cam
            YOLO4_OUTPUT_SIZE,INPUT_W,INPUT_H,facedetobjects,BBOX_CONF_THRESH,NUM_CLASSES,
            "MaskDetection");
    }else
    {
        ANNIWOLOG(INFO) <<"Not found the context for camId:"<<camID;
        ANNIWOCHECK(false);
    }
//////////////////////////////////////////////////////////////////////////////////
    
    int orig_img_w = img.cols;
    int orig_img_h = img.rows;

    std::vector<Object> overall_objectsMASK;

    for (size_t i = 0; i < person_det_resultsInside.size(); i++)
    {
        const Object& obj = person_det_resultsInside[i];
        
        if( ! isPerson(obj.label) )
            continue;

        
        ANNIWOLOGF(INFO, "MaskDetection::detect:camID:%d person_det_resultsInside %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f tid:%d\n",
        camID, getPersonCarbaseClassName(obj.label).c_str(), obj.prob,
            obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height,obj.trackID);


        int person_x = int(std::max(.0f, obj.rect.x));
        int person_y = int(std::max(.0f, obj.rect.y));
        int person_w = int(std::min(obj.rect.width, orig_img_w*1.0f));
        int person_h_up = int(std::min(obj.rect.height/4.0f, orig_img_h*1.0f));
        int person_trackID=obj.trackID;

        Object personUp;
        personUp.rect.x =  person_x ;
        personUp.rect.y =  person_y ;
        personUp.rect.width =  person_w;
        personUp.rect.height = person_h_up;


        bool isInsideP=false;
        Object& faceobj= facedetobjects[0]; 

        for(int idx=0;idx<facedetobjects.size();idx++)//找一个在人内部的人脸目标
        {
            faceobj = facedetobjects[idx];  

            //看看与人上1/4重合.
            // intersection over union
            float inter_area = intersection_area(faceobj, personUp);
            float chepaiobj_area = faceobj.rect.area();

            if( inter_area/chepaiobj_area > 0.9)
            {
                isInsideP=true;
                break;
            }

        }
        
        if(isInsideP)
        {
            //找到一个face在person内的
            // int face_x = faceobj.rect.x;
            // int face_y = faceobj.rect.y; 
            // int face_w = faceobj.rect.width;
            // int face_h = faceobj.rect.height;


            faceobj.trackID = person_trackID;

            ANNIWOLOGF(INFO, "MaskDetection::detect:camID:%d face: %s = confidence:%.5f at x:%.2f y:%.2f w:%.2f  h:%.2f tid:%d\n",
                camID, Maskclass_names[faceobj.label].c_str(), faceobj.prob,
                faceobj.rect.x, faceobj.rect.y, faceobj.rect.width, faceobj.rect.height,faceobj.trackID);

            // int x1 = face_x > person_x+person_w ? (person_x+person_w) : x1;
            // int y1 = face_y > person_y+person_h_up ? (person_y+person_h_up) : y1;
            
            // Object obj;

            // obj.rect.x =  x1 ;
            // obj.rect.y =  y1 ;
            // obj.rect.width =  face_w;
            // obj.rect.height = face_h;
            // obj.prob=faceobj.prob;
            // obj.label=faceobj.label;
                
            overall_objectsMASK.push_back(faceobj);


        }
        
    }



    if(overall_objectsMASK.size() > 0)
    {
        PostProcessResults(camID, img, overall_objectsMASK,polygonSafeArea_ptr,Maskclass_names);
    }
    else
    {
        ANNIWOLOG(INFO) << "MaskDetection:no objects for mask"<<"camID:"<<camID;
    }

    
    ANNIWOLOG(INFO) << "MaskDetection:exit detect()" <<"camID:"<<camID;

    return;
}
