import tkinter as tk
from tkinter import *
from tkinter import filedialog
from tkinter.ttk import *

from PIL import Image, ImageTk

from picture_change import *


class WinGUI(Tk):
    def __init__(self):
        super().__init__()
        self.scale = None
        self.y_offset = None
        self.x_offset = None
        self.new_cv_image = None
        # self.root.geometry('500X800')

        self.pil_image = None
        self.photo = None
        self.cv_image = None
        self.crop_mode = False
        self.start_corn = False
        self.point1 = None
        self.point2 = None
        self.__win()
        self.tk_button_read = self.__tk_button_read(self)
        self.tk_button_write = self.__tk_button_write(self)
        self.tk_button_confirm = self.__tk_button_confirm(self)
        self.tk_button_reduce = self.__tk_button_reduce(self)
        self.tk_tabs_tab = self.__tk_tabs_tab(self)
        self.tk_button_cut_button1 = self.__tk_button_cut_button1(self.tk_tabs_tab_0)
        self.tk_button_cut_button2 = self.__tk_button_cut_button2(self.tk_tabs_tab_0)
        self.rotate_scale = self.__tk_scale_rotate_scale(self.tk_tabs_tab_1)
        self.tk_label_rotate_label_not180 = self.__tk_label_rotate_label_not180(self.tk_tabs_tab_1)
        self.tk_label_rotate_label_180 = self.__tk_label_rotate_label_180(self.tk_tabs_tab_1)
        self.tk_label_rotate_label_0 = self.__tk_label_rotate_label_0(self.tk_tabs_tab_1)
        self.tk_button_histogram = self.__tk_button_histogram(self.tk_tabs_tab_5)
        self.tk_label_HSL_label1 = self.__tk_label_HSL_label1(self.tk_tabs_tab_6)
        self.tk_label_HSL_label2 = self.__tk_label_HSL_label2(self.tk_tabs_tab_6)
        self.tk_label_HSL_label3 = self.__tk_label_HSL_label3(self.tk_tabs_tab_6)
        self.HSL_scale_H = self.__tk_scale_HSL_scale_H(self.tk_tabs_tab_6)
        self.HSL_scale_S = self.__tk_scale_HSL_scale_S(self.tk_tabs_tab_6)
        self.HSL_scale_L = self.__tk_scale_HSL_scale_L(self.tk_tabs_tab_6)
        self.tk_label_Color_temperature_label1 = self.__tk_label_Color_temperature_label1(self.tk_tabs_tab_9)
        self.tk_label_Color_temperature_label2 = self.__tk_label_Color_temperature_label2(self.tk_tabs_tab_9)
        self.Color_temperature_scale_H = self.__tk_scale_Color_temperature_scale1(self.tk_tabs_tab_9)
        self.Color_temperature_scale_S = self.__tk_scale_Color_temperature_scale2(self.tk_tabs_tab_9)
        self.tk_canvas_draw = self.__tk_canvas_draw(self)

        self.exposure_scale = self.__tk_scale_exposure_scale(self.tk_tabs_tab_2)
        self.__tk_label_exposure_label_0(self.tk_tabs_tab_2)
        self.__tk_label_exposure_label_100(self.tk_tabs_tab_2)
        self.__tk_label_exposure_label_not100(self.tk_tabs_tab_2)

        self.contrast_ratio_scale = self.__tk_scale_contrast_ratio_scale(self.tk_tabs_tab_3)
        self.__tk_label_contrast_ratio_label_0(self.tk_tabs_tab_3)
        self.__tk_label_contrast_ratio_label_100(self.tk_tabs_tab_3)
        self.__tk_label_contrast_ratio_label_not100(self.tk_tabs_tab_3)

        self.Light_perception_scale = self.__tk_scale_Light_perception_scale(self.tk_tabs_tab_4)
        self.__tk_label_Light_perception_label_0(self.tk_tabs_tab_4)
        self.__tk_label_Light_perception_label_100(self.tk_tabs_tab_4)
        self.__tk_label_Light_perception_label_not100(self.tk_tabs_tab_4)

        self.sharpening_scale = self.__tk_scale_sharpening_scale(self.tk_tabs_tab_7)
        self.__tk_label_sharpening_label_0(self.tk_tabs_tab_7)
        self.__tk_label_sharpening_label_100(self.tk_tabs_tab_7)

        self.smooth_scale = self.__tk_scale_smooth_scale(self.tk_tabs_tab_8)
        self.__tk_label_smooth_label_0(self.tk_tabs_tab_8)
        self.__tk_label_smooth_label_100(self.tk_tabs_tab_8)

        self.Defogging_button = self.__tk_button_Defogging(self.tk_tabs_tab_10)

        self.__tk_label_work_label1(self.tk_tabs_tab_11)
        self.tk_button_word_button1 = self.__tk_button_word_button1(self.tk_tabs_tab_11)
        self.__tk_label_word_label2(self.tk_tabs_tab_11)
        self.word_entry = self.__tk_input_work_entry(self.tk_tabs_tab_11)
        self.tk_button_work_display = self.__tk_button_work_display(self.tk_tabs_tab_11)

    def __win(self):
        self.title("欢迎来到醒图app(bushi)")
        # 设置窗口大小、居中
        width = 596
        height = 750
        screenwidth = self.winfo_screenwidth()
        screenheight = self.winfo_screenheight()
        geometry = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        self.geometry(geometry)

        self.resizable(width=False, height=False)

    @staticmethod
    def scrollbar_autohide(vbar, hbar, widget):
        """自动隐藏滚动条"""

        def show():
            if vbar: vbar.lift(widget)
            if hbar: hbar.lift(widget)

        def hide():
            if vbar: vbar.lower(widget)
            if hbar: hbar.lower(widget)

        hide()
        widget.bind("<Enter>", lambda e: show())
        if vbar: vbar.bind("<Enter>", lambda e: show())
        if vbar: vbar.bind("<Leave>", lambda e: hide())
        if hbar: hbar.bind("<Enter>", lambda e: show())
        if hbar: hbar.bind("<Leave>", lambda e: hide())
        widget.bind("<Leave>", lambda e: hide())

    def v_scrollbar(self, vbar, widget, x, y, w, h, pw, ph):
        widget.configure(yscrollcommand=vbar.set)
        vbar.config(command=widget.yview)
        vbar.place(relx=(w + x) / pw, rely=y / ph, relheight=h / ph, anchor='ne')

    def h_scrollbar(self, hbar, widget, x, y, w, h, pw, ph):
        widget.configure(xscrollcommand=hbar.set)
        hbar.config(command=widget.xview)
        hbar.place(relx=x / pw, rely=(y + h) / ph, relwidth=w / pw, anchor='sw')

    def create_bar(self, master, widget, is_vbar, is_hbar, x, y, w, h, pw, ph):
        vbar, hbar = None, None
        if is_vbar:
            vbar = Scrollbar(master)
            self.v_scrollbar(vbar, widget, x, y, w, h, pw, ph)
        if is_hbar:
            hbar = Scrollbar(master, orient="horizontal")
            self.h_scrollbar(hbar, widget, x, y, w, h, pw, ph)
        self.scrollbar_autohide(vbar, hbar, widget)

    def __tk_button_read(self, parent):
        btn = Button(parent, text="读取文件", command=self.open_file_dialog)
        btn.place(x=22, y=13, width=68, height=34)
        return btn

    def __tk_button_write(self, parent):
        btn = Button(parent, text="保存文件", takefocus=False, command=self.save_image)
        btn.place(x=109, y=13, width=63, height=35)
        return btn

    def __tk_button_confirm(self, parent):
        btn = Button(parent, text="确认操作", takefocus=False, command=self.confirm_image)
        btn.place(x=412, y=18, width=76, height=36)
        return btn

    def __tk_button_reduce(self, parent):
        btn = Button(parent, text="撤回操作", takefocus=False, command=self.on_image_changed)
        btn.place(x=501, y=17, width=64, height=37)
        return btn

    def __tk_tabs_tab(self, parent):
        frame = Notebook(parent)
        self.tk_tabs_tab_0 = self.__tk_frame_tab_0(frame)
        frame.add(self.tk_tabs_tab_0, text="裁剪")
        self.tk_tabs_tab_1 = self.__tk_frame_tab_1(frame)
        frame.add(self.tk_tabs_tab_1, text="旋转")
        self.tk_tabs_tab_2 = self.__tk_frame_tab_2(frame)
        frame.add(self.tk_tabs_tab_2, text="曝光")
        self.tk_tabs_tab_3 = self.__tk_frame_tab_3(frame)
        frame.add(self.tk_tabs_tab_3, text="对比度")
        self.tk_tabs_tab_4 = self.__tk_frame_tab_4(frame)
        frame.add(self.tk_tabs_tab_4, text="光感")
        self.tk_tabs_tab_5 = self.__tk_frame_tab_5(frame)
        frame.add(self.tk_tabs_tab_5, text="均衡化")
        self.tk_tabs_tab_6 = self.__tk_frame_tab_6(frame)
        frame.add(self.tk_tabs_tab_6, text="HSL")
        self.tk_tabs_tab_7 = self.__tk_frame_tab_7(frame)
        frame.add(self.tk_tabs_tab_7, text="锐化")
        self.tk_tabs_tab_8 = self.__tk_frame_tab_8(frame)
        frame.add(self.tk_tabs_tab_8, text="平滑")
        self.tk_tabs_tab_9 = self.__tk_frame_tab_9(frame)
        frame.add(self.tk_tabs_tab_9, text="色温")
        self.tk_tabs_tab_10 = self.__tk_frame_tab_10(frame)
        frame.add(self.tk_tabs_tab_10, text="一键去雾")
        self.tk_tabs_tab_11 = self.__tk_frame_tab_11(frame)
        frame.add(self.tk_tabs_tab_11, text="文字")
        frame.place(x=0, y=586, width=596, height=182)
        frame.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        return frame

    def __tk_frame_tab_0(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_1(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_2(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_3(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_4(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_5(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_6(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_7(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_8(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_9(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_10(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    def __tk_frame_tab_11(self, parent):
        frame = Frame(parent)
        frame.place(x=0, y=586, width=596, height=112)
        return frame

    # 剪切
    def __tk_button_cut_button1(self, parent):
        btn = Button(parent, text="开始裁剪", takefocus=False, command=self.toggle_crop_mode)
        btn.place(x=196, y=30, width=56, height=33)
        return btn

    def __tk_button_cut_button2(self, parent):
        btn = Button(parent, text="确认裁剪", takefocus=False, command=self.toggle_crop_mode_confirm)
        btn.place(x=291, y=28, width=64, height=35)
        return btn

    # 旋转
    def __tk_scale_rotate_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=-180, to=180, command=self.update_rotate_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_rotate_label_not180(self, parent):
        label = Label(parent, text="-180%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_rotate_label_180(self, parent):
        label = Label(parent, text="180%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    def __tk_label_rotate_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=273, y=4, width=50, height=30)
        return label

    # 曝光
    def __tk_scale_exposure_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=-100, to=100, command=self.update_exposure_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_exposure_label_not100(self, parent):
        label = Label(parent, text="-100%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_exposure_label_100(self, parent):
        label = Label(parent, text="100%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    def __tk_label_exposure_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=273, y=4, width=50, height=30)
        return label

    def __tk_button_histogram(self, parent):
        btn = Button(parent, text="一键均匀化", takefocus=False, command=self.toggle_histogram_mode)
        btn.place(x=251, y=33, width=94, height=47)
        return btn

    def __tk_button_Defogging(self, parent):
        btn = Button(parent, text="一键去雾", takefocus=False, command=self.toggle_Defogging_mode)
        btn.place(x=251, y=33, width=94, height=47)
        return btn

    # 对比度
    def __tk_scale_contrast_ratio_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=-100, to=100, command=self.update_contrast_ratio_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_contrast_ratio_label_not100(self, parent):
        label = Label(parent, text="-100%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_contrast_ratio_label_100(self, parent):
        label = Label(parent, text="100%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    def __tk_label_contrast_ratio_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=273, y=4, width=50, height=30)
        return label

    # 光感
    def __tk_scale_Light_perception_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=-100, to=100, command=self.update_Light_perception_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_Light_perception_label_not100(self, parent):
        label = Label(parent, text="-100%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_Light_perception_label_100(self, parent):
        label = Label(parent, text="100%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    def __tk_label_Light_perception_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=273, y=4, width=50, height=30)
        return label

    # 锐化
    def __tk_scale_sharpening_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=0, to=100, command=self.update_sharpening_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_sharpening_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_sharpening_label_100(self, parent):
        label = Label(parent, text="100%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    # 光滑
    def __tk_scale_smooth_scale(self, parent):
        scale = tk.Scale(parent, orient=tk.HORIZONTAL, from_=0, to=100, command=self.update_smooth_image)
        scale.place(x=43, y=32, width=511, height=36)
        return scale

    def __tk_label_smooth_label_0(self, parent):
        label = Label(parent, text="0%", anchor="center", )
        label.place(x=28, y=4, width=50, height=30)
        return label

    def __tk_label_smooth_label_100(self, parent):
        label = Label(parent, text="100%", anchor="center", )
        label.place(x=524, y=5, width=50, height=30)
        return label

    def __tk_label_HSL_label1(self, parent):
        label = Label(parent, text="色相/色调", anchor="center", )
        label.place(x=19, y=0, width=65, height=32)
        return label

    def __tk_label_HSL_label2(self, parent):
        label = Label(parent, text="饱和度", anchor="center", )
        label.place(x=19, y=40, width=65, height=32)
        return label

    def __tk_label_HSL_label3(self, parent):
        label = Label(parent, text="亮度", anchor="center", )
        label.place(x=19, y=90, width=65, height=32)
        return label

    def __tk_scale_HSL_scale_H(self, parent):
        scale = tk.Scale(parent, from_=-100, to=100,
                         orient=tk.HORIZONTAL,
                         command=self.update_HSL_image)
        scale.place(x=103, y=0, width=443, height=40)
        return scale

    def __tk_scale_HSL_scale_S(self, parent):
        scale = tk.Scale(parent, from_=-100, to=100,
                         orient=tk.HORIZONTAL,
                         command=self.update_HSL_image)
        scale.place(x=103, y=40, width=443, height=40)
        return scale

    def __tk_scale_HSL_scale_L(self, parent):
        scale = tk.Scale(parent, from_=-100, to=100,
                         orient=tk.HORIZONTAL,
                         command=self.update_HSL_image)
        scale.place(x=103, y=89, width=443, height=40)
        return scale

    # 色温
    def __tk_label_Color_temperature_label1(self, parent):
        label = Label(parent, text="色相/色调", anchor="center", )
        label.place(x=30, y=3, width=79, height=34)
        return label

    def __tk_label_Color_temperature_label2(self, parent):
        label = Label(parent, text="饱和度", anchor="center", )
        label.place(x=32, y=90, width=76, height=33)
        return label

    def __tk_scale_Color_temperature_scale1(self, parent):
        scale = tk.Scale(parent, from_=-100, to=100,
                         orient=tk.HORIZONTAL,
                         command=self.update_Color_temperature_image)
        scale.place(x=133, y=7, width=422, height=40)
        return scale

    def __tk_scale_Color_temperature_scale2(self, parent):
        scale = tk.Scale(parent, from_=-100, to=100,
                         orient=tk.HORIZONTAL,
                         command=self.update_Color_temperature_image)
        scale.place(x=132, y=80, width=426, height=40)
        return scale

    def __tk_canvas_draw(self, parent):
        tk_canvas_draw = Canvas(parent, bg="white", width=594, height=513)
        tk_canvas_draw.place(x=0, y=67, width=594, height=513)
        tk_canvas_draw.bind("<Button-1>", self.on_canvas_click)
        return tk_canvas_draw

    def __tk_label_work_label1(self, parent):
        label = Label(parent, text="在图中框选范围，输入文字。", anchor="center", )
        label.place(x=31, y=7, width=200, height=30)
        return label

    def __tk_button_word_button1(self, parent):
        btn = Button(parent, text="选择区域", takefocus=False, command=self.toggle_crop_mode)
        btn.place(x=206, y=5, width=70, height=31)
        return btn

    def __tk_label_word_label2(self, parent):
        label = Label(parent, text="输入文字:", anchor="center", )
        label.place(x=47, y=50, width=50, height=30)
        return label

    def __tk_input_work_entry(self, parent):
        ipt = Entry(parent, )
        ipt.place(x=114, y=49, width=220, height=30)
        return ipt

    def __tk_button_work_display(self, parent):
        btn = Button(parent, text="显示文字", takefocus=False, command=self.update_word_mode)
        btn.place(x=446, y=24, width=97, height=49)
        return btn

    def open_file_dialog(self, *args):
        file_path = filedialog.askopenfilename(title="选择图片文件",
                                               filetypes=[("Image files", "*.png;*.gif;*.ppm;*.pgm"
                                                                          ";*.jpg")])
        if file_path:
            self.pil_image = Image.open(file_path)
            numpy_array = np.array(self.pil_image)
            self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
            self.show_image()

    def save_image(self):
        # 弹出文件对话框以获取保存路径
        if self.pil_image:
            file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                     filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"),
                                                                ("All files", "*.*")])

            if file_path:
                # 使用Image对象的save方法保存图像
                self.pil_image.save(file_path)
                print("Image saved successfully.")

    def show_image(self):
        # 获取Canvas的宽度和高度
        canvas_width = self.tk_canvas_draw.winfo_reqwidth()
        canvas_height = self.tk_canvas_draw.winfo_reqheight()

        # 获取图像的原始宽度和高度
        image_width, image_height = self.pil_image.size

        # 计算缩放比例，使图像铺满Canvas
        self.scale = min(canvas_width / image_width, canvas_height / image_height)

        # 缩放图片
        resized_image = self.pil_image.resize((int(image_width * self.scale), int(image_height * self.scale)),
                                              Image.ADAPTIVE)

        self.photo = ImageTk.PhotoImage(resized_image)
        # 如果需要在多个地方引用该图片对象，确保将其存储为实例变量，
        # 以防止垃圾回收将其清除导致图片不显示
        self.tk_canvas_draw.img = self.photo

        # 在Canvas上显示图片，居中显示
        self.x_offset = (canvas_width - int(image_width * self.scale)) // 2
        self.y_offset = (canvas_height - int(image_height * self.scale)) // 2
        self.tk_canvas_draw.create_image(self.x_offset, self.y_offset, anchor=NW, image=self.photo)

        # 裁剪操作

    def toggle_crop_mode(self):
        # 切换裁剪模式的状态
        self.crop_mode = True

    def toggle_crop_mode_reduction(self):
        self.cv_image = self.new_cv_image
        self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
        self.show_image()

    def toggle_crop_mode_confirm(self):
        if self.crop_mode:
            self.new_cv_image = self.cv_image
            self.cv_image = cut(self.cv_image,
                                int((self.point1[0] - self.x_offset) / self.scale),
                                int((self.point1[1] - self.y_offset) / self.scale),
                                int((self.point2[0] - self.x_offset) / self.scale),
                                int((self.point2[1] - self.y_offset) / self.scale))
            # temp=
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.show_image()
            self.tk_canvas_draw.delete("rectangle")
            # 重置两个点，以便下一次点击
            self.point1 = None
            self.point2 = None
            # 如果两个点都已经选择，清除之前的矩形框
            self.crop_mode = False

    def on_canvas_click(self, event):
        # 获取点击的坐标
        if self.crop_mode:
            x, y = event.x, event.y

            if self.point1 and self.point2:
                self.tk_canvas_draw.delete("rectangle")
                self.point1 = None
                self.point2 = None

            # 记录两个点击点的坐标
            if self.point1 is None:
                self.point1 = (x, y)
            else:
                self.point2 = (x, y)
                # 在两个点之间绘制矩形框
                self.tk_canvas_draw.create_rectangle(self.point1[0], self.point1[1], self.point2[0], self.point2[1],
                                                     outline="red",
                                                     width=1, tags="rectangle")

        # 旋转

    def update_rotate_image(self, *args):
        if self.pil_image is not None:
            value = self.rotate_scale.get() / 1.0
            self.new_cv_image = spin(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))

            self.show_image()

        # 亮度

        # def update_light_image(self, *args):
        #     if self.pil_image is not None:
        #         value = self.light_scale.get() / 1.0
        #         self.new_cv_image = lightness(self.cv_image, value)
        #         # 更新显示
        #         self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
        #         self.show_image()

        # 曝光

    def update_exposure_image(self, *args):
        if self.pil_image is not None:
            value = self.exposure_scale.get() / 1.0
            self.new_cv_image = exposure(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 对比度

    def update_contrast_ratio_image(self, *args):
        if self.pil_image is not None:
            value = int(self.contrast_ratio_scale.get())
            self.new_cv_image = adjust_contrast(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 光感

    def update_Light_perception_image(self, *args):
        if self.pil_image is not None:
            value = int(self.Light_perception_scale.get())
            self.new_cv_image = lightSense(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 直方图均衡化

    def toggle_histogram_mode(self):
        self.new_cv_image = equalization(self.cv_image)
        # 更新显示
        self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
        self.show_image()

        # 饱和度
        # def update_saturation_image(self, *args):
        #     if self.pil_image is not None:
        #         value = self.saturation_scale.get() / 2.0
        #         self.new_cv_image = Saturation_modification(self.cv_image, value)
        #         # 更新显示
        #         self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
        #         self.show_image()

        # HSL

    def update_HSL_image(self, *args):
        if self.pil_image is not None:
            value_H = self.HSL_scale_H.get()
            value_S = self.HSL_scale_S.get()
            value_L = self.HSL_scale_L.get()
            self.new_cv_image = new_HSL(self.cv_image, value_H, value_S, value_L)
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 色温

    def update_Color_temperature_image(self, *args):
        if self.pil_image is not None:
            value_H = self.Color_temperature_scale_H.get()
            value_S = self.Color_temperature_scale_S.get()

            self.new_cv_image = new_HSL(self.cv_image, value_H, value_S, 0)
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 锐化

    def update_sharpening_image(self, *args):
        if self.pil_image is not None:
            value = self.sharpening_scale.get()
            self.new_cv_image = Crisp_Enhancement(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 平滑

    def update_smooth_image(self, *args):
        if self.pil_image is not None:
            value = self.smooth_scale.get()
            self.new_cv_image = Smooth_processing(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

        # 去雾

    def toggle_Defogging_mode(self, *args):
        deHaze(self.cv_image)
        self.pil_image = Image.open("temp.jpg")
        # numpy_array = np.array(self.pil_image)
        # self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
        self.show_image()
        # 更新显示

        # 文字

    def update_word_mode(self):
        if self.crop_mode:
            word_entry = self.word_entry.get()
            self.new_cv_image = Add_Text(self.cv_image, word_entry,
                                         int((self.point1[0] - self.x_offset) / self.scale),
                                         int((self.point1[1] - self.y_offset) / self.scale)
                                         )
            # temp=
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()
            self.tk_canvas_draw.delete("rectangle")
            # 重置两个点，以便下一次点击
            self.point1 = None
            self.point2 = None
            # 如果两个点都已经选择，清除之前的矩形框
            self.crop_mode = False

        # tab还原

    def on_tab_changed(self, event):
        if self.pil_image:
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.rotate_scale.set(0)
            # self.saturation_scale.set(0)
            # self.light_scale.set(0)
            self.exposure_scale.set(0)
            self.contrast_ratio_scale.set(0)
            self.HSL_scale_H.set(0)
            self.HSL_scale_L.set(0)
            self.HSL_scale_S.set(0)
            self.Light_perception_scale.set(0)
            self.smooth_scale.set(0)
            self.show_image()

    def on_image_changed(self):
        if self.pil_image:
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.rotate_scale.set(0)
            # self.saturation_scale.set(0)
            # self.light_scale.set(0)
            self.Color_temperature_scale_S.set(0)
            self.Color_temperature_scale_H.set(0)
            self.exposure_scale.set(0)
            self.contrast_ratio_scale.set(0)
            self.HSL_scale_H.set(0)
            self.HSL_scale_L.set(0)
            self.HSL_scale_S.set(0)
            self.Light_perception_scale.set(0)
            self.sharpening_scale.set(0)
            self.show_image()

    def confirm_image(self):
        if self.pil_image:
            numpy_array = np.array(self.pil_image)
            self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
        self.on_image_changed()


class Win(WinGUI):
    def __init__(self):
        super().__init__()
        self.__event_bind()

    def __event_bind(self):
        pass


if __name__ == "__main__":
    win = Win()
    win.mainloop()
