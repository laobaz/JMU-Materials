from time import sleep

import numpy as np
import cv2 as cv


def move(img, tx, ty):  # 平移
    # 要移动的图形xy移动的平移量
    rows, cols, channels = img.shape  # 赋值
    move = np.float32([[1, 0, tx], [0, 1, ty]])
    # 平移矩阵M =  [1,0,tx]
    #            [0,1,ty]
    dst = cv.warpAffine(img, move, (cols, rows))
    return dst


def spin(img, yaw):  # 逆时针旋转
    rows, cols, channels = img.shape
    # getRotationMatrix2D有三个参数，第一个为旋转中心，第二个为旋转角度，第三个为缩放比例
    M = cv.getRotationMatrix2D((cols / 2, rows / 2), yaw, 1)
    dst = cv.warpAffine(img, M, (cols, rows))
    return dst


def cut(img, x_lt, y_lt, x_rb, y_rb):  # 剪裁
    # 剪裁后的x坐标点和y坐标点
    return img[y_lt:y_rb, x_lt:x_rb]


def zoom(img, k):  # 缩放
    # 长宽都放大k倍
    if k < 1:
        # 缩小
        dst = cv.resize(img, (int(k * img.shape[1]), int(k * img.shape[0])), interpolation=cv.INTER_AREA)
    else:
        # 放大
        dst = cv.resize(img, (int(k * img.shape[1]), int(k * img.shape[0])), interpolation=cv.INTER_LINEAR)
    return dst


def adjust_contrast(img, contrast_factor):
    contrast_factor = np.float32(contrast_factor + 50) / 50.0
    table = np.array([(i - 74) * contrast_factor + 74 for i in range(0, 256)]).clip(0, 255).astype('uint8')
    if img.shape[2] == 1:
        return cv.LUT(img, table)[:, :, np.newaxis]
    else:
        return cv.LUT(img, table)


# 亮度调节 参数 b: -100~100
def lightness(img, b):  # b越大越亮
    img_t = cv.cvtColor(img, cv.COLOR_BGR2HSV)  # BGR->HSV
    h, s, v = cv.split(img_t)  # 分离hsv
    v1 = np.clip(cv.add(1 * v, b), 0, 255)
    img1 = np.uint8(cv.merge((h, s, v1)))
    img1 = cv.cvtColor(img1, cv.COLOR_HSV2BGR)
    return img1


# 曝光度调节 参数 b: -50~50
def exposure(img, b):
    # b ∈ [0, 100] -> [-1, 1]
    b = np.float32(b) / 100.0
    res = img.astype(np.float32)
    res = res * pow(2, b)
    res = np.where(res > 255, 255, res)
    res = res.astype(np.uint8)
    return res


def lightSense(img, light):  # 光感（高光
    assert -100 <= light <= 100  # 确定light的取值范围
    max_v = 4
    bright = (light / 100.0) / max_v  # 过渡区设置
    mid = 1.0 + max_v * bright
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY).astype(np.float32) / 255.0  # 灰度图
    thresh = gray * gray  # 确定高光区
    t = np.mean(thresh)  # 取平均值作为阈值
    mask = np.where(thresh > t, 255, 0).astype(np.float32)  # 得到掩膜
    brightrate = np.where(mask == 255.0, bright, (1.0 / t * thresh) * bright)
    mask = np.where(mask == 255.0, mid, (mid - 1.0) / t * thresh + 1.0)
    img = img / 255.0
    img = np.power(img, 1.0 / mask[:, :, np.newaxis]) * (1.0 / (1.0 - brightrate[:, :, np.newaxis]))
    img = np.clip(img, 0, 1.0) * 255.0
    return img.astype(np.uint8)


def equalization(img):  # 直方图均衡化
    (b, g, r) = cv.split(img)  # 通道分解
    bH = cv.equalizeHist(b)
    gH = cv.equalizeHist(g)
    rH = cv.equalizeHist(r)
    result = cv.merge((bH, gH, rH), )  # 通道合成
    return result


# 直方图均衡化
def equalize(img):
    dst = img.copy()
    rows, cols, channels = dst.shape
    for i in range(channels):
        dst[:, :, i] = cv.equalizeHist(dst[:, :, i])
    return dst


# def curvelig(img, x):  # 整体曲线调节亮度,值0-255
#     y = x  # y是y轴上x在曲线上对应的值，不一定=x
#     img1 = lightness(img, y)  # 调节亮度
#     return img1
#
#
# def curver(img, rx):  # 红色曲线
#     r1 = rx  # r1是y轴上rx在曲线上对应的值，不一定=rx
#     (b, g, r) = cv.split(img)
#     img1 = cv.merge((b, g, r1), )
#     return img1
#
#
# def curveb(img, bx):  # 蓝色曲线
#     b1 = bx  # b1是y轴上bx在曲线上对应的值，不一定=bx
#     (b, g, r) = cv.split(img)
#     img1 = cv.merge((b1, g, r), )
#     return img1
#
#
# def curveg(img, gx):  # 蓝色曲线
#     g1 = gx  # g1是y轴上gx在曲线上对应的值，不一定=gx
#     (b, g, r) = cv.split(img)
#     img1 = cv.merge((b, g1, r), )
#     return img1


# 实现饱和度调整

#
# - 调整参数nparameter,取值范围为[-100, 100],对其归一化后为`increment∈[-1,1]`。
#
#   rgbMax = max(max(R[i,j], G[i,j]), B[i,j])
#
#   rgbMin = min(min(R[i,j], G[i,j]), B[i,j])
#
#   delta = (rgbMax - rgbMin) / 255
#
#   if delta = 0: 不调整 continue
#
#   val = (rgbMax + rgbMin) / 255
#
#   L = val / 2	(HSL中的L, 亮度)
#
#   饱和度 S = delta / val	(L<0.5)
#
#           delta / (2 - val) (L>=0.5)
#
#   if increment>=0:
# if increment+S>=1: alpha = S
#
#   	else: alpha = 1-increment
#
#   	alpha = 1/alpha-1
#
#   	newRGB[i,j] = RGB[i,j] + (RGB[i,j] - L * 255) * alpha
#
#   else:
#
#   	alpha = increment
#
#   	newRGB[i,j] = L * 255 + (RGB[i,j] - L * 255) * (1+alpha)
def Saturation_modification(img, parameter):
    # 输入参数为[-50，50],进行归一后为[-1,1]
    increment = np.float32(parameter) / 50.0
    res = img.astype(np.float64)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            val_max = max(res[i, j, 0], max(res[i, j, 1], res[i, j, 2]))
            val_min = min(res[i, j, 0], min(res[i, j, 1], res[i, j, 2]))
            delta = (val_max - val_min) / 255
            if delta == 0:
                continue
            val = (val_max + val_min) / 255
            L = val / 2
            if L < 0.5:
                S = delta / val
            else:
                S = delta / (2 - val)

            if increment >= 0:
                if increment + S > 1:
                    alpha = S
                else:
                    alpha = 1 - increment
                alpha = 1 / alpha - 1
                res[i, j, 2] = res[i, j, 2] + (res[i, j, 2] - L * 255) * alpha
                res[i, j, 1] = res[i, j, 1] + (res[i, j, 1] - L * 255) * alpha
                res[i, j, 0] = res[i, j, 0] + (res[i, j, 0] - L * 255) * alpha
            else:
                alpha = increment
                res[i, j, 2] = L * 255 + (res[i, j, 2] - L * 255) * (1 + alpha)
                res[i, j, 1] = L * 255 + (res[i, j, 1] - L * 255) * (1 + alpha)
                res[i, j, 0] = L * 255 + (res[i, j, 0] - L * 255) * (1 + alpha)
    res = res.astype(np.uint8)

    return res


# HSL(色相，饱和度,亮度)调节

# 图像HSL调节(色调调节)
# cf_h 范围[0, 200] 对应[0, 2]
# cf_s, cf_l 范围[0, 200] 对应 [0, 2]
# 整个调用过程：
# 对于一个img
#   1. hslImg = convertToHSL(img)
#   2. dst = HSL(hslImg, cf_h, cf_s, cf_l)
#   3. dst = convertToBGR(dst)


def new_HSL(img, H, S, L):
    hls_image = cv.cvtColor(img, cv.COLOR_BGR2HLS)
    H = np.float64(H / 5)
    S = np.float64(S / 2)
    L = np.float64(L / 2)

    # 调整HSL
    hls_image[:, :, 0] = (hls_image[:, :, 0] + H) % 180
    hls_image[:, :, 1] = np.clip(hls_image[:, :, 1] + L, 0, 255)
    hls_image[:, :, 2] = np.clip(hls_image[:, :, 2] + S, 0, 255)

    result_image = cv.cvtColor(hls_image, cv.COLOR_HLS2BGR)

    return result_image


# 锐化处理

# 拉普拉斯算子可以通过以下步骤进行图像锐化：
#
# 将原图像转换为灰度图像，仅保留亮度信息。
#
# 对灰度图像应用拉普拉斯算子卷积核，得到一个新的图像。
#
# 将产生的图像与原始图像相减，得到一个得到一个用于增强图像细节的高通滤波图像。
def LaplaceFilter(img, parameter):
    # parameter 为[0,100]归一化为[0,3]
    res = cv.Laplacian(img, ddepth=cv.CV_64F)
    res = np.maximum(0, res)
    res = np.uint8(res)
    return res


def Crisp_Enhancement(img, parameter):
    # laplace算子
    parameter = np.float64(parameter / 70)
    img_laplace = LaplaceFilter(img, parameter)

    # 锐化图像=原始图像+(原始图像-模糊图像)
    Crisp_enhancements = cv.convertScaleAbs(img - img_laplace * parameter)
    return Crisp_enhancements


# 平滑处理

# 使用均值滤波方法
# 均值滤波是指用当前像素点周围 NxN 个像素值的均值来代替当前像素值。
# 使用该方法遍历图像内每一个像素点，便可以完成整幅图像的均值滤波。
# 在进行均值滤波时，首先要考虑对周围多少个像素点取平均值，通常情况是以当前像素点为中心，
# 对行数和列数相等的一块区域内的所有像素点的像素值求平均值。选定的区域一般被称作滤波核或卷积核。


# 控制滤波器的范围： 高斯函数的标准差决定了滤波器的大小。
# 较大的标准差会导致更广泛的权重分布，从而使得滤波器覆盖更大的区域。
# 这意味着，较大的标准差将导致更强的平滑效果，但可能损失一些图像细节。
#
#
# 控制滤波器的形状： 标准差越小，高斯函数越尖锐，滤波器的形状越窄。
# 这可以保留更多的图像细节，但可能对噪声更敏感。
# 较小的标准差通常用于边缘保留的平滑操作。
def Smooth_processing(img, parameter):
    # 取值范围[0,100]
    # parameter=parameter*100
    dst = cv.GaussianBlur(img, (7, 7), parameter)
    return dst


# 色温
# 色温的调节通常涉及改变图像的色调和饱和度。
# 色调（Hue）是指图像的颜色类型，
# 而饱和度（Saturation）是指颜色的纯度。


def Add_Text(img, str, x, y):
    res = img.copy()
    cv.putText(res, str, (x, y), cv.FONT_HERSHEY_SIMPLEX, 2,
               (0, 0, 0), 1, cv.LINE_AA)
    return res





def new_Defogging(image, omega=0.95, t0=0.1, p=0.1):
        # 计算图像的暗通道
        dark_channel = np.min( image, axis=2)

        # 计算全局大气光值
        top_percent = int(image.size * (1 - omega))
        dark_channel_flat = dark_channel.flatten()
        indices = np.argpartition(dark_channel_flat, top_percent)[:top_percent]
        global_atmosphere = np.max(image.reshape(-1, 3)[indices],axis=0)

        #global_atmosphere_expanded = np.expand_dims(global_atmosphere, axis=(1))
        # 估计透射率
        transmission = 1 - p * dark_channel / global_atmosphere

        # 限制透射率范围
        transmission = np.maximum(t0, transmission)

        # 估计场景辐射值
        scene_radiance = (image - global_atmosphere) / transmission + global_atmosphere

        # 限制像素值范围
        scene_radiance = np.clip(scene_radiance, 0, 255).astype(np.uint8)

        return scene_radiance, transmission



#https://www.jianshu.com/p/df9c963a392a
def zmMinFilterGray(src, r=7):
    '''最小值滤波，r是滤波器半径'''
    return cv.erode(src, np.ones((2 * r + 1, 2 * r + 1)))


def guidedfilter(I, p, r, eps):
    height, width = I.shape
    m_I = cv.boxFilter(I, -1, (r, r))
    m_p = cv.boxFilter(p, -1, (r, r))
    m_Ip = cv.boxFilter(I * p, -1, (r, r))
    cov_Ip = m_Ip - m_I * m_p

    m_II = cv.boxFilter(I * I, -1, (r, r))
    var_I = m_II - m_I * m_I

    a = cov_Ip / (var_I + eps)
    b = m_p - a * m_I

    m_a = cv.boxFilter(a, -1, (r, r))
    m_b = cv.boxFilter(b, -1, (r, r))
    return m_a * I + m_b


def Defog(m, r, eps, w, maxV1):                 # 输入rgb图像，值范围[0,1]
    '''计算大气遮罩图像V1和光照值A, V1 = 1-t/A'''
    V1 = np.min(m, 2)                           # 得到暗通道图像
    Dark_Channel = zmMinFilterGray(V1, 7)
    #cv.imshow('20190708_Dark',Dark_Channel)    # 查看暗通道
    cv.waitKey(0)
    cv.destroyAllWindows()

    V1 = guidedfilter(V1, Dark_Channel, r, eps)  # 使用引导滤波优化
    bins = 2000
    ht = np.histogram(V1, bins)                  # 计算大气光照A
    d = np.cumsum(ht[0]) / float(V1.size)
    for lmax in range(bins - 1, 0, -1):
        if d[lmax] <= 0.999:
            break
    A = np.mean(m, 2)[V1 >= ht[1][lmax]].max()
    V1 = np.minimum(V1 * w, maxV1)               # 对值范围进行限制
    return V1, A


def deHaze(m, r=81, eps=0.001, w=0.95, maxV1=0.80, bGamma=False):
    m=m/255.0
    Y = np.zeros(m.shape)
    Mask_img, A = Defog(m, r, eps, w, maxV1)             # 得到遮罩图像和大气光照

    for k in range(3):
        Y[:,:,k] = (m[:,:,k] - Mask_img)/(1-Mask_img/A)  # 颜色校正
    Y = np.clip(Y, 0, 1)
    if bGamma:
        Y = Y ** (np.log(0.5) / np.log(Y.mean()))       # gamma校正,默认不进行该操作
    Y=Y*255
    cv.imwrite("temp.jpg",Y)




if __name__ == '__main__':
    img = cv.imread("demo2.jpg")

    # res=Saturation_modification(img,10)
    # cv.imshow("new",img)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
    # res=convertToBGR(HSL(convertToHSL(img),10,10,10))
    # res=Crisp_Enhancement(img,30)
    # res=Smooth_processing(img,parameter=10)
    # res=Color_temperature_treatment(img,50)
    # res=Tone_correction(img)
    # res=Add_Text(img,"hello",100,100)

    # res=Saturation_modification(img,100)
    #
    #
    # res=Saturation_modification(img,50)
    # cv.imshow("new2", res)
    # res = spin(img, 10)
    res= deHaze(img/255.0)*255
    cv.imwrite('demo3.jpg', res)
    cv.imshow("dw",res)

    res=cv.imread("demo3.jpg")
    cv.imshow("noe",res)

    cv.waitKey(0)
    cv.destroyAllWindows()
