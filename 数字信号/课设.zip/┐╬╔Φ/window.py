import tkinter as tk
from tkinter import filedialog, ttk

from PIL import Image, ImageTk

from picture_change import *


# root.title("欢迎来到醒图app(bushi)")
# root.geometry('800x400')
# button = tk.Button(root, text="选择图片文件", command=open_file_dialog)
# button.pack(pady=10)
# label = tk.Label(root)
# label.pack()

class ImageEditorApp:
    def __init__(self, root):
        self.scale = None
        self.y_offset = None
        self.x_offset = None
        self.new_cv_image = None
        self.root = root
        self.root.title("欢迎来到醒图app(bushi)")
        # self.root.geometry('500X800')

        self.pil_image = None
        self.photo = None
        self.cv_image = None
        self.crop_mode = False
        self.start_corn = False

        # 创建按钮，点击按钮时打开文件对话框
        self.button = tk.Button(root, text="选择图片文件", command=self.open_file_dialog)
        self.button.pack(pady=10)
        self.button = tk.Button(root, text="保存图片文件", command=self.save_image)
        self.button.pack(pady=10)

        # 创建用于显示图片的标签
        self.label = tk.Label(root)
        self.label.pack()

        self.canvas = tk.Canvas(root, bg="white", width=600, height=600)
        self.canvas.pack()

        # 用于存储鼠标拖动的起始坐标
        # self.start_x = None
        # self.start_y = None
        # self.end_x = None
        # self.end_y = None
        self.point1 = None
        self.point2 = None

        # 绑定Canvas的鼠标事件
        # self.canvas.bind("<Button-1>", self.draw_rect_start)
        self.canvas.bind("<Button-1>", self.on_canvas_click)

        self.notebook = ttk.Notebook(root)
        self.notebook.pack(expand=True, fill="both")

        # 裁剪
        self.crop_tab = tk.Frame(self.notebook)
        self.notebook.add(self.crop_tab, text="裁剪")

        self.crop_button = tk.Button(self.crop_tab, text="裁剪", command=self.toggle_crop_mode)
        self.crop_button.pack()
        self.crop_button_confirm = tk.Button(self.crop_tab, text="确认", command=self.toggle_crop_mode_confirm)
        self.crop_button_confirm.pack()
        self.crop_button_reduction = tk.Button(self.crop_tab, text="还原", command=self.toggle_crop_mode_reduction)

        self.crop_button_reduction.pack()

        # 旋转
        self.rotate_tab = tk.Frame(self.notebook)
        self.notebook.add(self.rotate_tab, text="旋转")
        self.rotate_label = tk.Label(self.rotate_tab, text="旋转")
        self.rotate_label.pack(side=tk.TOP)
        self.rotate_scale = tk.Scale(self.rotate_tab, from_=-180, to=180, length=500, orient=tk.HORIZONTAL,
                                     command=self.update_rotate_image)
        self.rotate_scale.pack()
        self.rotate_button = tk.Button(self.rotate_tab, text="确认", command=self.confirm_image)
        self.rotate_button.pack(side=tk.RIGHT)
        self.rotate_button_redution = tk.Button(self.rotate_tab, text="还原", command=self.on_image_changed)
        self.rotate_button_redution.pack(side=tk.LEFT)

        # 亮度
        # self.light_tab = tk.Frame(self.notebook)
        # self.notebook.add(self.light_tab, text="亮度")
        # self.light_label = tk.Label(self.light_tab, text="亮度")
        # self.light_label.pack(side=tk.TOP)
        # self.light_scale = tk.Scale(self.light_tab, from_=-100, to=100, length=500, orient=tk.HORIZONTAL,
        #                             command=self.update_light_image)
        # self.light_scale.pack()
        # self.light_button = tk.Button(self.light_tab, text="确认", command=self.confirm_image)
        # self.light_button.pack(side=tk.RIGHT)
        # self.light_button_Reduction = tk.Button(self.light_tab, text="还原", command=self.on_image_changed)
        # self.light_button_Reduction.pack(side=tk.LEFT)

        # 曝光
        self.exposure_tab = tk.Frame(self.notebook)
        self.notebook.add(self.exposure_tab, text="曝光")
        self.exposure_label = tk.Label(self.exposure_tab, text="曝光度")
        self.exposure_label.pack(side=tk.TOP)
        self.exposure_scale = tk.Scale(self.exposure_tab, from_=-100, to=100, length=500, orient=tk.HORIZONTAL,
                                       command=self.update_exposure_image)
        self.exposure_scale.pack()
        self.exposure_button = tk.Button(self.exposure_tab, text="确认", command=self.confirm_image)
        self.exposure_button.pack(side=tk.RIGHT)
        self.exposure_button_reduction = tk.Button(self.exposure_tab, text="还原", command=self.on_image_changed)
        self.exposure_button_reduction.pack(side=tk.LEFT)

        # 对比度
        self.contrast_ratio_tab = tk.Frame(self.notebook)
        self.notebook.add(self.contrast_ratio_tab, text="对比度")
        self.contrast_ratio_label = tk.Label(self.contrast_ratio_tab, text="对比度")
        self.contrast_ratio_label.pack(side=tk.TOP)
        self.contrast_ratio_scale = tk.Scale(self.contrast_ratio_tab, from_=-100, to=100, length=500,
                                             orient=tk.HORIZONTAL,
                                             command=self.update_contrast_ratio_image)
        self.contrast_ratio_scale.pack()
        self.contrast_ratio_button = tk.Button(self.contrast_ratio_tab, text="确认",
                                               command=self.confirm_image)
        self.contrast_ratio_button.pack(side=tk.RIGHT)
        self.contrast_ratio_button_reduction = tk.Button(self.contrast_ratio_tab, text="还原",
                                                         command=self.on_image_changed)
        self.contrast_ratio_button_reduction.pack(side=tk.LEFT)

        # 光感
        self.Light_perception_tab = tk.Frame(self.notebook)
        self.notebook.add(self.Light_perception_tab, text="光感")
        self.Light_perception_label = tk.Label(self.Light_perception_tab, text="光感")
        self.Light_perception_label.pack(side=tk.TOP)
        self.Light_perception_scale = tk.Scale(self.Light_perception_tab, from_=-100, to=100, length=500,
                                               orient=tk.HORIZONTAL,
                                               command=self.update_Light_perception_image)
        self.Light_perception_scale.pack()
        self.Light_perception_button = tk.Button(self.Light_perception_tab, text="确认",
                                                 command=self.confirm_image)
        self.Light_perception_button.pack(side=tk.RIGHT)
        self.Light_perception_button_reduction = tk.Button(self.Light_perception_tab, text="还原",
                                                           command=self.on_image_changed)
        self.Light_perception_button_reduction.pack(side=tk.LEFT)

        # 直方图均衡化
        self.histogram_tab = tk.Frame(self.notebook)
        self.notebook.add(self.histogram_tab, text="均衡化")
        self.histogram_button = tk.Button(self.histogram_tab, text="均衡化", command=self.toggle_histogram_mode)
        self.histogram_button.pack()
        self.histogram_button_confirm = tk.Button(self.histogram_tab, text="确认",
                                                  command=self.confirm_image)
        self.histogram_button_confirm.pack()
        self.histogram_button_reduction = tk.Button(self.histogram_tab, text="还原", command=self.on_image_changed)
        self.histogram_button_reduction.pack()

        # # 创建饱和度调整滑块
        # self.saturation_tab = tk.Frame(self.notebook)
        # self.notebook.add(self.saturation_tab, text="饱和度")
        # self.saturation_label = tk.Label(self.saturation_tab, text="饱和度")
        # self.saturation_label.pack(side=tk.TOP)
        # self.saturation_scale = tk.Scale(self.saturation_tab, from_=-100, to=100, length=500,
        #                                  orient=tk.HORIZONTAL)
        # self.saturation_scale.pack()
        # self.saturation_scale.bind("<ButtonRelease>", self.update_saturation_image)
        # self.saturation_button = tk.Button(self.saturation_tab, text="确认",
        #                                    command=self.confirm_image)
        # self.saturation_button.pack(side=tk.RIGHT)
        # self.saturation_button_reduction = tk.Button(self.saturation_tab, text="还原",
        #                                              command=self.on_image_changed)
        # self.saturation_button_reduction.pack(side=tk.LEFT)

        # HSL

        self.HSL_tab = tk.Frame(self.notebook)
        self.notebook.add(self.HSL_tab, text="HSL")
        self.HSL_label = tk.Label(self.HSL_tab, text="色相/色调")
        self.HSL_label.pack()
        self.HSL_scale_H = tk.Scale(self.HSL_tab, from_=-100, to=100, length=500, orient=tk.HORIZONTAL,
                                    command=self.update_HSL_image)
        self.HSL_scale_H.pack()
        self.HSL_label_S = tk.Label(self.HSL_tab, text="饱和度")
        self.HSL_label_S.pack()
        self.HSL_scale_S = tk.Scale(self.HSL_tab, from_=-100, to=100, length=500, orient=tk.HORIZONTAL,
                                    command=self.update_HSL_image)
        self.HSL_scale_S.pack()

        self.HSL_label_L = tk.Label(self.HSL_tab, text="亮度")
        self.HSL_label_L.pack()
        self.HSL_scale_L = tk.Scale(self.HSL_tab, from_=-100, to=100, length=500, orient=tk.HORIZONTAL,
                                    command=self.update_HSL_image)
        self.HSL_scale_L.pack()

        self.HSL_button = tk.Button(self.HSL_tab, text="确认", command=self.confirm_image)
        self.HSL_button.pack(side=tk.RIGHT)
        self.HSL_button_reduction = tk.Button(self.HSL_tab, text="还原", command=self.on_image_changed)
        self.HSL_button_reduction.pack(side=tk.LEFT)

        # 锐化
        self.sharpening_tab = tk.Frame(self.notebook)
        self.notebook.add(self.sharpening_tab, text="锐化")
        self.sharpening_label = tk.Label(self.sharpening_tab, text="锐化度")
        self.sharpening_label.pack(side=tk.TOP)
        self.sharpening_scale = tk.Scale(self.sharpening_tab, from_=0, to=100, length=500,
                                         orient=tk.HORIZONTAL,
                                         command=self.update_sharpening_image)
        self.sharpening_scale.pack()
        self.sharpening_button = tk.Button(self.sharpening_tab, text="确认",
                                           command=self.confirm_image)
        self.sharpening_button.pack(side=tk.RIGHT)
        self.sharpening_button_reduction = tk.Button(self.sharpening_tab, text="还原",
                                                     command=self.on_image_changed)
        self.sharpening_button_reduction.pack(side=tk.LEFT)

        # 平滑
        self.smooth_tab = tk.Frame(self.notebook)
        self.notebook.add(self.smooth_tab, text="平滑")
        self.smooth_label = tk.Label(self.smooth_tab, text="平滑度")
        self.smooth_label.pack(side=tk.TOP)
        self.smooth_scale = tk.Scale(self.smooth_tab, from_=0, to=100, length=500,
                                     orient=tk.HORIZONTAL,
                                     command=self.update_smooth_image)
        self.smooth_scale.pack()
        self.smooth_button = tk.Button(self.smooth_tab, text="确认",
                                       command=self.confirm_image)
        self.smooth_button.pack(side=tk.RIGHT)
        self.smooth_button_reduction = tk.Button(self.smooth_tab, text="还原",
                                                 command=self.on_image_changed)
        self.smooth_button_reduction.pack(side=tk.LEFT)

        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

        # 色温
        self.Color_temperature_tab = tk.Frame(self.notebook)
        self.notebook.add(self.Color_temperature_tab, text="色温")
        self.Color_temperature_label = tk.Label(self.Color_temperature_tab, text="色温度(通过修改色调和饱和度获得)")
        self.Color_temperature_label.pack()
        self.Color_temperature_label1 = tk.Label(self.Color_temperature_tab, text="色相/色调")
        self.Color_temperature_label1.pack()
        self.Color_temperature_scale_H = tk.Scale(self.Color_temperature_tab, from_=-100, to=100, length=500,
                                                  orient=tk.HORIZONTAL,
                                                  command=self.update_Color_temperature_image)
        self.Color_temperature_scale_H.pack()
        self.Color_temperature_label2 = tk.Label(self.Color_temperature_tab, text="饱和度")
        self.Color_temperature_label2.pack()
        self.Color_temperature_scale_S = tk.Scale(self.Color_temperature_tab, from_=-100, to=100, length=500,
                                                  orient=tk.HORIZONTAL,
                                                  command=self.update_Color_temperature_image)
        self.Color_temperature_scale_S.pack()
        self.Color_temperature_button = tk.Button(self.Color_temperature_tab, text="确认",
                                                  command=self.confirm_image)
        self.Color_temperature_button.pack(side=tk.RIGHT)
        self.Color_temperature_button_reduction = tk.Button(self.Color_temperature_tab, text="还原",
                                                            command=self.on_image_changed)
        self.Color_temperature_button_reduction.pack(side=tk.LEFT)

        # 去雾

        self.Defogging_tab = tk.Frame(self.notebook)
        self.notebook.add(self.Defogging_tab, text="一键去雾")
        self.Defogging_button = tk.Button(self.Defogging_tab, text="一键去雾", command=self.toggle_Defogging_mode)
        self.Defogging_button.pack()
        self.Defogging_button_confirm = tk.Button(self.Defogging_tab, text="确认去雾",
                                                  command=self.confirm_image)
        self.Defogging_button_confirm.pack()
        self.Defogging_button_reduction = tk.Button(self.Defogging_tab, text="一键还原", command=self.on_image_changed)
        self.Defogging_button_reduction.pack()

        # 文字
        self.word_tab = tk.Frame(self.notebook)
        self.notebook.add(self.word_tab, text="文字")
        self.word_label = tk.Label(self.word_tab, text="在图中框选范围，输入文字。")
        self.word_label.pack()
        self.word_button = tk.Button(self.word_tab, text="选择区域", command=self.toggle_crop_mode)
        self.word_button.pack()

        self.word_label = tk.Label(self.word_tab, text="输入文字:")
        self.word_label.pack()
        self.word_entry = tk.Entry(self.word_tab, width=30)
        self.word_entry.pack(pady=10)
        self.word_button1 = tk.Button(self.word_tab, text="显示", command=self.update_word_mode)
        self.word_button1.pack(pady=10)
        self.word_button_confirm = tk.Button(self.word_tab, text="确认输入",
                                             command=self.confirm_image)
        self.word_button_confirm.pack(side=tk.RIGHT)
        self.word_button_reduction = tk.Button(self.word_tab, text="还原", command=self.on_image_changed)
        self.word_button_reduction.pack(side=tk.LEFT)

        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def open_file_dialog(self):
        file_path = filedialog.askopenfilename(title="选择图片文件",
                                               filetypes=[("Image files", "*.png;*.gif;*.ppm;*.pgm"
                                                                          ";*.jpg")])
        if file_path:
            self.pil_image = Image.open(file_path)
            numpy_array = np.array(self.pil_image)
            self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
            self.show_image()

    def save_image(self):
        # 弹出文件对话框以获取保存路径
        if self.pil_image:
            file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                     filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg"),
                                                                ("All files", "*.*")])

            if file_path:
                # 使用Image对象的save方法保存图像
                self.pil_image.save(file_path)
                print("Image saved successfully.")

    def show_image(self):
        # 获取Canvas的宽度和高度
        canvas_width = self.canvas.winfo_reqwidth()
        canvas_height = self.canvas.winfo_reqheight()

        # 获取图像的原始宽度和高度
        image_width, image_height = self.pil_image.size

        # 计算缩放比例，使图像铺满Canvas
        self.scale = min(canvas_width / image_width, canvas_height / image_height)

        # 缩放图片
        resized_image = self.pil_image.resize((int(image_width * self.scale), int(image_height * self.scale)),
                                              Image.ADAPTIVE)

        self.photo = ImageTk.PhotoImage(resized_image)
        # 如果需要在多个地方引用该图片对象，确保将其存储为实例变量，
        # 以防止垃圾回收将其清除导致图片不显示
        self.canvas.img = self.photo

        # 在Canvas上显示图片，居中显示
        self.x_offset = (canvas_width - int(image_width * self.scale)) // 2
        self.y_offset = (canvas_height - int(image_height * self.scale)) // 2
        self.canvas.create_image(self.x_offset, self.y_offset, anchor=tk.NW, image=self.photo)

    # 裁剪操作
    def toggle_crop_mode(self):
        # 切换裁剪模式的状态
        self.crop_mode = True

    def toggle_crop_mode_reduction(self):
        self.cv_image = self.new_cv_image
        self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
        self.show_image()

    def toggle_crop_mode_confirm(self):
        if self.crop_mode:
            self.new_cv_image = self.cv_image
            self.cv_image = cut(self.cv_image,
                                int((self.point1[0] - self.x_offset) / self.scale),
                                int((self.point1[1] - self.y_offset) / self.scale),
                                int((self.point2[0] - self.x_offset) / self.scale),
                                int((self.point2[1] - self.y_offset) / self.scale))
            # temp=
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.show_image()
            self.canvas.delete("rectangle")
            # 重置两个点，以便下一次点击
            self.point1 = None
            self.point2 = None
            # 如果两个点都已经选择，清除之前的矩形框
            self.crop_mode = False

    def on_canvas_click(self, event):
        # 获取点击的坐标
        if self.crop_mode:
            x, y = event.x, event.y

            if self.point1 and self.point2:
                self.canvas.delete("rectangle")
                self.point1 = None
                self.point2 = None

            # 记录两个点击点的坐标
            if self.point1 is None:
                self.point1 = (x, y)
            else:
                self.point2 = (x, y)
                # 在两个点之间绘制矩形框
                self.canvas.create_rectangle(self.point1[0], self.point1[1], self.point2[0], self.point2[1],
                                             outline="red",
                                             width=1, tags="rectangle")

    # 旋转
    def update_rotate_image(self, *args):
        if self.pil_image is not None:
            value = self.rotate_scale.get() / 1.0
            self.new_cv_image = spin(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))

            self.show_image()

    # 亮度

    # def update_light_image(self, *args):
    #     if self.pil_image is not None:
    #         value = self.light_scale.get() / 1.0
    #         self.new_cv_image = lightness(self.cv_image, value)
    #         # 更新显示
    #         self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
    #         self.show_image()

    # 曝光

    def update_exposure_image(self, *args):
        if self.pil_image is not None:
            value = self.exposure_scale.get() / 1.0
            self.new_cv_image = exposure(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 对比度

    def update_contrast_ratio_image(self, *args):
        if self.pil_image is not None:
            value = int(self.contrast_ratio_scale.get())
            self.new_cv_image = adjust_contrast(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 光感

    def update_Light_perception_image(self, *args):
        if self.pil_image is not None:
            value = int(self.Light_perception_scale.get())
            self.new_cv_image = lightSense(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 直方图均衡化
    def toggle_histogram_mode(self):
        self.new_cv_image = equalization(self.cv_image)
        # 更新显示
        self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
        self.show_image()

    # 饱和度
    # def update_saturation_image(self, *args):
    #     if self.pil_image is not None:
    #         value = self.saturation_scale.get() / 2.0
    #         self.new_cv_image = Saturation_modification(self.cv_image, value)
    #         # 更新显示
    #         self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
    #         self.show_image()

    # HSL

    def update_HSL_image(self, *args):
        if self.pil_image is not None:
            value_H = self.HSL_scale_H.get()
            value_S = self.HSL_scale_S.get()
            value_L = self.HSL_scale_L.get()
            self.new_cv_image = new_HSL(self.cv_image, value_H, value_S, value_L)
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 色温
    def update_Color_temperature_image(self, *args):
        if self.pil_image is not None:
            value_H = self.Color_temperature_scale_H.get()
            value_S = self.Color_temperature_scale_S.get()

            self.new_cv_image = new_HSL(self.cv_image, value_H, value_S, 0)
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 锐化
    def update_sharpening_image(self, *args):
        if self.pil_image is not None:
            value = self.sharpening_scale.get()
            self.new_cv_image = Crisp_Enhancement(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 平滑
    def update_smooth_image(self, *args):
        if self.pil_image is not None:
            value = self.smooth_scale.get()
            self.new_cv_image = Smooth_processing(self.cv_image, value)
            # 更新显示
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()

    # 去雾
    def toggle_Defogging_mode(self, *args):
        deHaze(self.cv_image)
        self.pil_image = Image.open("temp.jpg")
        # numpy_array = np.array(self.pil_image)
        # self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
        self.show_image()
        # 更新显示

    # 文字
    def update_word_mode(self):
        if self.crop_mode:
            word_entry = self.word_entry.get()
            self.new_cv_image = Add_Text(self.cv_image, word_entry,
                                         int((self.point1[0] - self.x_offset) / self.scale),
                                         int((self.point1[1] - self.y_offset) / self.scale)
                                         )
            # temp=
            self.pil_image = Image.fromarray(cv.cvtColor(self.new_cv_image, cv.COLOR_BGR2RGB))
            self.show_image()
            self.canvas.delete("rectangle")
            # 重置两个点，以便下一次点击
            self.point1 = None
            self.point2 = None
            # 如果两个点都已经选择，清除之前的矩形框
            self.crop_mode = False

    # tab还原
    def on_tab_changed(self, event):
        if self.pil_image:
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.rotate_scale.set(0)
            # self.saturation_scale.set(0)
            # self.light_scale.set(0)
            self.exposure_scale.set(0)
            self.contrast_ratio_scale.set(0)
            self.HSL_scale_H.set(0)
            self.HSL_scale_L.set(0)
            self.HSL_scale_S.set(0)
            self.Light_perception_scale.set(0)
            self.smooth_scale.set(0)
            self.show_image()

    def on_image_changed(self):
        if self.pil_image:
            self.pil_image = Image.fromarray(cv.cvtColor(self.cv_image, cv.COLOR_BGR2RGB))
            self.rotate_scale.set(0)
            # self.saturation_scale.set(0)
            # self.light_scale.set(0)
            self.Color_temperature_scale_S.set(0)
            self.Color_temperature_scale_H.set(0)
            self.exposure_scale.set(0)
            self.contrast_ratio_scale.set(0)
            self.HSL_scale_H.set(0)
            self.HSL_scale_L.set(0)
            self.HSL_scale_S.set(0)
            self.Light_perception_scale.set(0)
            self.sharpening_scale.set(0)
            self.show_image()

    def confirm_image(self):
        if self.pil_image:
            numpy_array = np.array(self.pil_image)
            self.cv_image = cv.cvtColor(numpy_array, cv.COLOR_RGB2BGR)
        self.on_image_changed()


if __name__ == '__main__':
    root = tk.Tk()
    app = ImageEditorApp(root)

    root.mainloop()
